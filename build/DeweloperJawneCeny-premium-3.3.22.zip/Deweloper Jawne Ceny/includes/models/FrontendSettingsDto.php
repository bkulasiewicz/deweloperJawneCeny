<?php

if (!defined('ABSPATH')) {
    exit;
}

/**
 * Frontend settings model for widget configuration
 * Uses PropertyType enums and ResourceDto constants for type safety
 */
class FrontendSettingsDto {
    
    // Generator shortcode - using PropertyType enums
    public readonly array $selected_types;          // [PropertyType::RESIDENTIAL_UNIT, PropertyType::PARKING_SPACE]
    public readonly string $primary_color;          // '#007cba'
    
    // Using ResourceDto field constants for database consistency
    public readonly array $visible_columns;         // [ResourceDto::FIELD_NR_LOKALU, ResourceDto::FIELD_POWIERZCHNIA_UZYTKOWA]
    
    // Column names mapping - ResourceDto constants to custom display names
    public readonly array $column_names;            // [ResourceDto::FIELD_NR_LOKALU => 'Numer', ResourceDto::FIELD_POWIERZCHNIA_UZYTKOWA => 'Powierzchnia']
    
    public function __construct(
        array $selected_types = [],
        string $primary_color = '#007cba',
        array $visible_columns = [],
        array $column_names = []
    ) {
        // Set default selected types if empty
        if (empty($selected_types)) {
            $selected_types = [PropertyType::RESIDENTIAL_UNIT];
        }
        
        // Set default visible columns if empty
        if (empty($visible_columns)) {
            $visible_columns = [
                ResourceDto::FIELD_NR_LOKALU,
                ResourceDto::FIELD_RODZAJ_NIERUCHOMOSCI,
                ResourceDto::FIELD_POWIERZCHNIA_UZYTKOWA,
                PriceHistoryDto::FIELD_CENA_CALKOWITA, // From PriceHistory
                ResourceDto::FIELD_STATUS,
                ResourcesListShortcode::COLUMN_HISTORIA_CEN // Special functional column
            ];
        }
        
        // Set default column names if empty
        if (empty($column_names)) {
            $column_names = self::getDefaultColumnNames();
        }
        
        $this->selected_types = $selected_types;
        $this->primary_color = $primary_color;
        $this->visible_columns = $visible_columns;
        $this->column_names = $column_names;
    }
    
    /**
     * Get all available columns for configuration
     */
    public static function getAllAvailableColumns(): array {
        return [
            // Basic information from ResourceDto
            ResourceDto::FIELD_NR_LOKALU,
            ResourceDto::FIELD_RODZAJ_NIERUCHOMOSCI,
            ResourceDto::FIELD_POWIERZCHNIA_UZYTKOWA,
            ResourceDto::FIELD_STATUS,
            
            // Prices from PriceHistory
            PriceHistoryDto::FIELD_CENA_M2,
            PriceHistoryDto::FIELD_CENA_CALKOWITA,
            PriceHistoryDto::FIELD_CENA_Z_DODATKAMI,
            
            // Marketing fields from ResourceDto
            ResourceDto::FIELD_FLOOR_NUMBER,
            ResourceDto::FIELD_ROOM_COUNT,
            ResourceDto::FIELD_ADDITIONAL_DESCRIPTION,
            ResourceDto::FIELD_GARDEN_AREA,
            ResourceDto::FIELD_FLOOR_PLAN_PDF,
            
            // Functional
            ResourcesListShortcode::COLUMN_HISTORIA_CEN
        ];
    }
    
    /**
     * Get default column names for display
     */
    public static function getDefaultColumnNames(): array {
        return [
            ResourceDto::FIELD_NR_LOKALU => 'Numer',
            ResourceDto::FIELD_RODZAJ_NIERUCHOMOSCI => 'Typ',
            ResourceDto::FIELD_POWIERZCHNIA_UZYTKOWA => 'Powierzchnia',
            ResourceDto::FIELD_STATUS => 'Status',
            PriceHistoryDto::FIELD_CENA_M2 => 'Cena za m²',
            PriceHistoryDto::FIELD_CENA_CALKOWITA => 'Cena lokalu',
            PriceHistoryDto::FIELD_CENA_Z_DODATKAMI => 'Cena pełna',
            ResourceDto::FIELD_FLOOR_NUMBER => 'Piętro',
            ResourceDto::FIELD_ROOM_COUNT => 'Liczba pokoi',
            ResourceDto::FIELD_ADDITIONAL_DESCRIPTION => 'Opis',
            ResourceDto::FIELD_GARDEN_AREA => 'Ogród',
            ResourceDto::FIELD_FLOOR_PLAN_PDF => 'Plan',
            ResourcesListShortcode::COLUMN_HISTORIA_CEN => 'Historia cen'
        ];
    }
    
    /**
     * Get selected types as string values for shortcode generation
     */
    public function getSelectedTypesAsStrings(): array {
        return array_map(fn(PropertyType $type) => $type->value, $this->selected_types);
    }
    
    /**
     * Generate shortcode string based on current settings
     */
    public function generateShortcode(): string {
        $types_string = implode(',', $this->getSelectedTypesAsStrings());
        $columns_string = implode(',', $this->visible_columns);
        
        $shortcode = "[resources_list types=\"{$types_string}\"";
        
        if (!empty($columns_string)) {
            $shortcode .= " columns=\"{$columns_string}\"";
        }
        
        if ($this->primary_color !== '#007cba') {
            $shortcode .= " color=\"{$this->primary_color}\"";
        }
        
        $shortcode .= "]";
        
        return $shortcode;
    }
    
    /**
     * Convert to array for storage/serialization
     */
    public function toArray(): array {
        return [
            'selected_types' => $this->getSelectedTypesAsStrings(),
            'primary_color' => $this->primary_color,
            'visible_columns' => $this->visible_columns,
            'column_names' => $this->column_names
        ];
    }
    
    /**
     * Create instance from array data
     */
    public static function fromArray(array $data): self {
        // Convert string type values back to PropertyType enums
        $selected_types = [];
        if (isset($data['selected_types'])) {
            foreach ($data['selected_types'] as $type_string) {
                try {
                    $selected_types[] = PropertyType::from($type_string);
                } catch (ValueError $e) {
                    // Skip invalid enum values
                    Logger::error("Invalid PropertyType value: {$type_string}");
                }
            }
        }
        
        return new self(
            selected_types: $selected_types,
            primary_color: $data['primary_color'] ?? '#007cba',
            visible_columns: $data['visible_columns'] ?? [],
            column_names: $data['column_names'] ?? []
        );
    }
}