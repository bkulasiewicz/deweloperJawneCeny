/**
 * Frontend JavaScript for clickable rows in resources_list shortcode
 * Handles row clicks with fallback for popup blockers
 */
(function() {
    'use strict';

    // Send logs to WordPress via AJAX to use Logger class
    function ujcLog(message) {
        // Send to backend Logger via AJAX
        if (window.jQuery && window.ujc_ajax) {
            jQuery.ajax({
                url: ujc_ajax.ajax_url,
                type: 'POST',
                data: {
                    action: 'ujc_frontend_log',
                    message: 'Frontend Clickable Rows: ' + message,
                    nonce: ujc_ajax.nonce
                }
            });
        }

        // Also log to console for immediate debugging
        console.log('UJC Frontend: ' + message);
    }

    function ujcError(message) {
        // Send to backend Logger via AJAX
        if (window.jQuery && window.ujc_ajax) {
            jQuery.ajax({
                url: ujc_ajax.ajax_url,
                type: 'POST',
                data: {
                    action: 'ujc_frontend_error',
                    message: 'Frontend Clickable Rows Error: ' + message,
                    nonce: ujc_ajax.nonce
                }
            });
        }

        // Also log to console for immediate debugging
        console.error('UJC Frontend Error: ' + message);
    }

    function initClickableRows() {
        ujcLog('Initializing clickable rows...');

        // Find all clickable rows with improved selector
        const clickableRows = document.querySelectorAll('.clickable-row[data-detail-url]');
        ujcLog('Found ' + clickableRows.length + ' clickable rows');

        clickableRows.forEach(function(row, index) {
            ujcLog('Setting up row ' + index + ' with URL: ' + row.getAttribute('data-detail-url'));

            row.addEventListener('click', function(e) {
                ujcLog('Row clicked, target: ' + e.target.tagName);

                // Don't trigger row click if clicking on buttons or links
                if (e.target.tagName === 'BUTTON' ||
                    e.target.closest('button') ||
                    e.target.tagName === 'A' ||
                    e.target.closest('a')) {
                    ujcLog('Click on button/link ignored');
                    return;
                }

                // Get the detail URL from data attribute
                const detailUrl = this.getAttribute('data-detail-url');
                if (!detailUrl) {
                    ujcError('No detail URL found on row');
                    return;
                }

                ujcLog('Opening URL: ' + detailUrl);

                // Try to open in new tab with fallback
                try {
                    const newWindow = window.open(detailUrl, '_blank');

                    // Check if popup was blocked
                    if (!newWindow || newWindow.closed || typeof newWindow.closed === 'undefined') {
                        ujcLog('Popup blocked, using fallback');
                        // Fallback: ask user if they want to navigate
                        if (confirm('Otwórz stronę szczegółów w nowej karcie?\n\n' + detailUrl)) {
                            window.location.href = detailUrl;
                        }
                    } else {
                        ujcLog('Successfully opened new tab');
                    }
                } catch (error) {
                    ujcError('Error opening URL: ' + error.message);
                    // Ultimate fallback
                    if (confirm('Nie można otworzyć nowej karty. Przejść do strony?\n\n' + detailUrl)) {
                        window.location.href = detailUrl;
                    }
                }
            });

            // Add visual feedback for clickable rows
            row.style.cursor = 'pointer';
        });
    }

    // Initialize when DOM is ready
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', initClickableRows);
    } else {
        // DOM already loaded
        initClickableRows();
    }

    // Also try to initialize on window load as backup
    window.addEventListener('load', function() {
        // Only run if not already initialized
        if (document.querySelectorAll('.clickable-row[data-detail-url]').length > 0) {
            ujcLog('Re-checking clickable rows on window load');
            initClickableRows();
        }
    });

})();