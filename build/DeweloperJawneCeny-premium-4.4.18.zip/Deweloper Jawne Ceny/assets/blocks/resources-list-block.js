(function() {
    const { registerBlockType } = wp.blocks;
    const { createElement: el, Fragment } = wp.element;
    const { InspectorControls } = wp.blockEditor;
    const { PanelBody, CheckboxControl, ColorPicker, TextControl, SelectControl } = wp.components;

    // Available columns with their default names - keys match PHP DTO constants
    const AVAILABLE_COLUMNS = {
        // ResourceDto fields
        'unit_number': 'Numer lokalu',                    // ResourceDto::FIELD_NR_LOKALU
        'property_type': 'Typ nieruchomości',             // ResourceDto::FIELD_RODZAJ_NIERUCHOMOSCI
        'usable_area': 'Powierzchnia',                    // ResourceDto::FIELD_POWIERZCHNIA_UZYTKOWA
        'status': 'Status',                               // ResourceDto::FIELD_STATUS
        'floor_number': 'Piętro',                         // ResourceDto::FIELD_FLOOR_NUMBER
        'room_count': 'Pokoje',                           // ResourceDto::FIELD_ROOM_COUNT
        'additional_description': 'Opis',                 // ResourceDto::FIELD_ADDITIONAL_DESCRIPTION
        'garden_area': 'Ogród',                           // ResourceDto::FIELD_GARDEN_AREA
        'floor_plan_pdf': 'Plan',                         // ResourceDto::FIELD_FLOOR_PLAN_PDF

        // PriceHistoryDto fields
        'price_per_m2': 'Cena za m²',                     // PriceHistoryDto::FIELD_CENA_M2
        'total_price': 'Cena całkowita',                  // PriceHistoryDto::FIELD_CENA_CALKOWITA
        'price_with_extras': 'Cena z dodatkami',          // PriceHistoryDto::FIELD_CENA_Z_DODATKAMI

        // Functional columns
        'historia_cen': 'Historia cen'                     // ResourceTableRenderer::COLUMN_HISTORIA_CEN
    };

    // Available property types
    const PROPERTY_TYPES = {
        'residential_unit': 'Lokale mieszkalne',
        'single_family_house': 'Domy jednorodzinne',
        'service_premises': 'Lokale usługowe',
        'parking_space': 'Miejsca postojowe',
        'storage_room': 'Komórki lokatorskie',
        'garage': 'Garaże'
    };

    // Font options
    const FONT_OPTIONS = [
        { label: 'Domyślna', value: 'inherit' },
        { label: 'Arial', value: 'Arial, sans-serif' },
        { label: 'Helvetica', value: 'Helvetica, sans-serif' },
        { label: 'Georgia', value: 'Georgia, serif' },
        { label: 'Times New Roman', value: '"Times New Roman", serif' },
        { label: 'Verdana', value: 'Verdana, sans-serif' }
    ];

    registerBlockType('jawne-ceny/resources-list', {
        title: 'Lista Zasobów',
        description: 'Wyświetla listę mieszkań/zasobów z cenami - z pełną personalizacją',
        category: 'widgets',
        icon: 'list-view',
        keywords: ['mieszkania', 'zasoby', 'ceny', 'lista', 'nieruchomości'],

        attributes: {
            // Column configuration
            visibleColumns: {
                type: 'array',
                default: ['unit_number', 'property_type', 'usable_area', 'total_price', 'status', 'historia_cen']
            },
            columnOrder: {
                type: 'array',
                default: ['unit_number', 'property_type', 'usable_area', 'total_price', 'status', 'historia_cen']
            },
            columnNames: {
                type: 'object',
                default: {}
            },

            // Property type filtering
            selectedTypes: {
                type: 'array',
                default: ['residential_unit']
            },

            // Styling options
            headerBgColor: {
                type: 'string',
                default: '#f9f9f9'
            },
            headerTextColor: {
                type: 'string',
                default: '#333333'
            },
            textColor: {
                type: 'string',
                default: '#333333'
            },
            hoverBgColor: {
                type: 'string',
                default: '#f5f5f5'
            },
            headerFontFamily: {
                type: 'string',
                default: 'inherit'
            },
            contentFontFamily: {
                type: 'string',
                default: 'inherit'
            },

            // Interactive options
            detailPageUrl: {
                type: 'string',
                default: ''
            },

            // Button customization
            historiaBtnText: {
                type: 'string',
                default: 'Historia'
            },
            historiaBtnBgColor: {
                type: 'string',
                default: '#007cba'
            },
            historiaBtnTextColor: {
                type: 'string',
                default: '#ffffff'
            },

            kartaBtnText: {
                type: 'string',
                default: 'Karta lokalu'
            },
            kartaBtnBgColor: {
                type: 'string',
                default: '#007cba'
            },
            kartaBtnTextColor: {
                type: 'string',
                default: '#ffffff'
            }
        },

        edit: function(props) {
            const { attributes, setAttributes } = props;

            // Helper function to handle property type selection
            const togglePropertyType = function(type, checked) {
                const newTypes = checked
                    ? [...attributes.selectedTypes, type]
                    : attributes.selectedTypes.filter(t => t !== type);

                setAttributes({ selectedTypes: newTypes });
            };

            // Helper function to add column to the end of visible list
            const addColumn = function(column) {
                if (!attributes.visibleColumns.includes(column)) {
                    const newColumns = [...attributes.visibleColumns, column];
                    const newOrder = [...attributes.columnOrder.filter(col => newColumns.includes(col)), column];

                    setAttributes({
                        visibleColumns: newColumns,
                        columnOrder: newOrder
                    });
                }
            };

            // Helper function to remove column from visible list
            const removeColumn = function(column) {
                const newColumns = attributes.visibleColumns.filter(col => col !== column);
                const newOrder = attributes.columnOrder.filter(col => newColumns.includes(col));

                // Also remove custom name if exists
                const newNames = { ...attributes.columnNames };
                delete newNames[column];

                setAttributes({
                    visibleColumns: newColumns,
                    columnOrder: newOrder,
                    columnNames: newNames
                });
            };

            // Function for updating column names - immediate updates for smooth UX
            const updateColumnName = function(column, newName) {
                const newNames = { ...attributes.columnNames };

                if (newName && newName.trim() !== '' && newName !== AVAILABLE_COLUMNS[column]) {
                    // Save custom name
                    newNames[column] = newName.trim();
                } else {
                    // Remove custom name (use default)
                    delete newNames[column];
                }

                setAttributes({ columnNames: newNames });
            };

            // Drag & Drop handlers for column reordering
            const handleDragStart = function(e, draggedColumn) {
                e.dataTransfer.setData('text/plain', draggedColumn);
                e.dataTransfer.effectAllowed = 'move';

                // Add dragging class for styling
                e.target.classList.add('dragging');
            };

            const handleDragEnd = function(e) {
                // Remove dragging class
                e.target.classList.remove('dragging');
            };

            const handleDragOver = function(e) {
                e.preventDefault(); // Allow drop
                e.dataTransfer.dropEffect = 'move';

                // Add visual feedback
                e.currentTarget.classList.add('drag-over');
            };

            const handleDragLeave = function(e) {
                // Remove visual feedback
                e.currentTarget.classList.remove('drag-over');
            };

            const handleDrop = function(e, dropTarget) {
                e.preventDefault();

                // Remove visual feedback
                e.currentTarget.classList.remove('drag-over');

                const draggedColumn = e.dataTransfer.getData('text/plain');
                if (!draggedColumn || draggedColumn === dropTarget) {
                    return; // No change needed
                }

                // Create new column order
                const currentOrder = [...attributes.columnOrder];
                const draggedIndex = currentOrder.indexOf(draggedColumn);
                const dropIndex = currentOrder.indexOf(dropTarget);

                if (draggedIndex === -1 || dropIndex === -1) {
                    return; // Invalid indexes
                }

                // Remove dragged item and insert at new position
                currentOrder.splice(draggedIndex, 1);
                currentOrder.splice(dropIndex, 0, draggedColumn);

                setAttributes({ columnOrder: currentOrder });
            };

            return el(Fragment, {},
                // Inspector Controls (sidebar panel)
                el(InspectorControls, {},

                    // Property Types Panel
                    el(PanelBody, {
                        title: 'Typy nieruchomości',
                        initialOpen: true
                    },
                        Object.entries(PROPERTY_TYPES).map(([value, label]) =>
                            el(CheckboxControl, {
                                key: value,
                                label: label,
                                checked: attributes.selectedTypes.includes(value),
                                onChange: (checked) => togglePropertyType(value, checked)
                            })
                        )
                    ),

                    // Column Order Panel
                    el(PanelBody, {
                        title: 'Kolejność i nazwy kolumn',
                        initialOpen: true
                    },
                        el('div', {
                            style: {
                                marginBottom: '16px'
                            }
                        },
                            el('p', {
                                style: {
                                    margin: '0 0 12px',
                                    fontSize: '13px',
                                    color: '#666'
                                }
                            }, 'Przeciągnij kolumny aby zmienić kolejność. Kliknij ✕ aby usunąć.'),

                            // Visible columns list with drag&drop
                            attributes.visibleColumns.length > 0 ?
                                attributes.columnOrder
                                    .filter(col => attributes.visibleColumns.includes(col))
                                    .map((column, index) => {
                                        const defaultName = AVAILABLE_COLUMNS[column] || column;
                                        const customName = attributes.columnNames[column] || '';

                                        return el('div', {
                                            key: column,
                                            className: 'column-item',
                                            style: {
                                                display: 'flex',
                                                alignItems: 'center',
                                                marginBottom: '8px',
                                                padding: '8px',
                                                backgroundColor: '#f9f9f9',
                                                border: '1px solid #ddd',
                                                borderRadius: '4px',
                                                cursor: 'move'
                                            },
                                            draggable: true,
                                            onDragStart: (e) => handleDragStart(e, column),
                                            onDragEnd: handleDragEnd,
                                            onDragOver: handleDragOver,
                                            onDragLeave: handleDragLeave,
                                            onDrop: (e) => handleDrop(e, column)
                                        },
                                            // Drag handle
                                            el('span', {
                                                style: {
                                                    marginRight: '8px',
                                                    color: '#666',
                                                    fontSize: '14px',
                                                    cursor: 'grab'
                                                }
                                            }, '≡≡'),

                                            // Column number
                                            el('span', {
                                                style: {
                                                    marginRight: '8px',
                                                    minWidth: '20px',
                                                    fontSize: '12px',
                                                    color: '#666',
                                                    fontWeight: 'bold'
                                                }
                                            }, (index + 1) + '.'),

                                            // Column name input
                                            el('input', {
                                                type: 'text',
                                                placeholder: defaultName,
                                                value: customName,
                                                onChange: (e) => updateColumnName(column, e.target.value),
                                                style: {
                                                    flex: '1',
                                                    padding: '4px 6px',
                                                    border: '1px solid #ccd0d4',
                                                    borderRadius: '3px',
                                                    fontSize: '13px'
                                                }
                                            }),

                                            // Remove button
                                            el('button', {
                                                type: 'button',
                                                onClick: () => removeColumn(column),
                                                style: {
                                                    marginLeft: '8px',
                                                    padding: '4px 6px',
                                                    backgroundColor: '#dc3232',
                                                    color: 'white',
                                                    border: 'none',
                                                    borderRadius: '3px',
                                                    fontSize: '11px',
                                                    cursor: 'pointer'
                                                },
                                                title: 'Usuń kolumnę'
                                            }, '✕')
                                        );
                                    }) :
                                el('p', {
                                    style: {
                                        color: '#666',
                                        fontStyle: 'italic',
                                        margin: '0'
                                    }
                                }, 'Brak widocznych kolumn. Dodaj kolumny poniżej.')
                        )
                    ),

                    // Available Columns Panel
                    el(PanelBody, {
                        title: 'Dostępne kolumny',
                        initialOpen: false
                    },
                        el('div', {
                            style: {
                                display: 'grid',
                                gridTemplateColumns: '1fr 1fr',
                                gap: '8px'
                            }
                        },
                            Object.entries(AVAILABLE_COLUMNS)
                                .filter(([column]) => !attributes.visibleColumns.includes(column))
                                .map(([column, defaultName]) =>
                                    el('button', {
                                        key: column,
                                        type: 'button',
                                        onClick: () => addColumn(column),
                                        style: {
                                            padding: '6px 8px',
                                            backgroundColor: '#f0f0f1',
                                            border: '1px solid #c3c4c7',
                                            borderRadius: '3px',
                                            fontSize: '12px',
                                            cursor: 'pointer',
                                            textAlign: 'left'
                                        },
                                        title: 'Dodaj kolumnę'
                                    }, '+ ' + defaultName)
                                )
                        ),
                        Object.entries(AVAILABLE_COLUMNS).filter(([column]) => !attributes.visibleColumns.includes(column)).length === 0 &&
                        el('p', {
                            style: {
                                color: '#666',
                                fontStyle: 'italic',
                                margin: '0'
                            }
                        }, 'Wszystkie kolumny są już dodane.')
                    ),

                    // Styling Panel
                    el(PanelBody, {
                        title: 'Stylizacja tabeli',
                        initialOpen: false
                    },
                        el('div', { style: { marginBottom: '16px' } },
                            el('label', { style: { display: 'block', marginBottom: '8px', fontWeight: 'bold' } }, 'Kolor tła nagłówka'),
                            el(ColorPicker, {
                                color: attributes.headerBgColor,
                                onChangeComplete: (color) => setAttributes({ headerBgColor: color.hex }),
                                disableAlpha: true
                            })
                        ),
                        el('div', { style: { marginBottom: '16px' } },
                            el('label', { style: { display: 'block', marginBottom: '8px', fontWeight: 'bold' } }, 'Kolor tekstu nagłówka'),
                            el(ColorPicker, {
                                color: attributes.headerTextColor,
                                onChangeComplete: (color) => setAttributes({ headerTextColor: color.hex }),
                                disableAlpha: true
                            })
                        ),
                        el('div', { style: { marginBottom: '16px' } },
                            el('label', { style: { display: 'block', marginBottom: '8px', fontWeight: 'bold' } }, 'Kolor tekstu treści'),
                            el(ColorPicker, {
                                color: attributes.textColor,
                                onChangeComplete: (color) => setAttributes({ textColor: color.hex }),
                                disableAlpha: true
                            })
                        ),
                        el('div', { style: { marginBottom: '16px' } },
                            el('label', { style: { display: 'block', marginBottom: '8px', fontWeight: 'bold' } }, 'Kolor hover'),
                            el(ColorPicker, {
                                color: attributes.hoverBgColor,
                                onChangeComplete: (color) => setAttributes({ hoverBgColor: color.hex }),
                                disableAlpha: true
                            })
                        ),
                        el(SelectControl, {
                            label: 'Czcionka nagłówków',
                            value: attributes.headerFontFamily,
                            options: FONT_OPTIONS,
                            onChange: (value) => setAttributes({ headerFontFamily: value })
                        }),
                        el(SelectControl, {
                            label: 'Czcionka treści',
                            value: attributes.contentFontFamily,
                            options: FONT_OPTIONS,
                            onChange: (value) => setAttributes({ contentFontFamily: value })
                        })
                    ),

                    // Interactive Features Panel
                    el(PanelBody, {
                        title: 'Funkcje interaktywne',
                        initialOpen: false
                    },
                        el(TextControl, {
                            label: 'URL strony szczegółów',
                            placeholder: '/mieszkania/',
                            value: attributes.detailPageUrl,
                            onChange: (value) => setAttributes({ detailPageUrl: value }),
                            help: 'Gdy ustawione, wiersze będą klikaln'
                        }),
                        el('hr'),
                        el('h4', { style: { margin: '16px 0 8px' } }, 'Przycisk Historia Cen'),
                        el(TextControl, {
                            label: 'Tekst przycisku',
                            value: attributes.historiaBtnText,
                            onChange: (value) => setAttributes({ historiaBtnText: value })
                        }),
                        el('div', { style: { marginBottom: '12px' } },
                            el('label', { style: { display: 'block', marginBottom: '4px' } }, 'Kolor tła'),
                            el(ColorPicker, {
                                color: attributes.historiaBtnBgColor,
                                onChangeComplete: (color) => setAttributes({ historiaBtnBgColor: color.hex }),
                                disableAlpha: true
                            })
                        ),
                        el('div', { style: { marginBottom: '16px' } },
                            el('label', { style: { display: 'block', marginBottom: '4px' } }, 'Kolor tekstu'),
                            el(ColorPicker, {
                                color: attributes.historiaBtnTextColor,
                                onChangeComplete: (color) => setAttributes({ historiaBtnTextColor: color.hex }),
                                disableAlpha: true
                            })
                        ),
                        el('hr'),
                        el('h4', { style: { margin: '16px 0 8px' } }, 'Przycisk Karta Lokalu'),
                        el(TextControl, {
                            label: 'Tekst przycisku',
                            value: attributes.kartaBtnText,
                            onChange: (value) => setAttributes({ kartaBtnText: value })
                        }),
                        el('div', { style: { marginBottom: '12px' } },
                            el('label', { style: { display: 'block', marginBottom: '4px' } }, 'Kolor tła'),
                            el(ColorPicker, {
                                color: attributes.kartaBtnBgColor,
                                onChangeComplete: (color) => setAttributes({ kartaBtnBgColor: color.hex }),
                                disableAlpha: true
                            })
                        ),
                        el('div', { style: { marginBottom: '16px' } },
                            el('label', { style: { display: 'block', marginBottom: '4px' } }, 'Kolor tekstu'),
                            el(ColorPicker, {
                                color: attributes.kartaBtnTextColor,
                                onChangeComplete: (color) => setAttributes({ kartaBtnTextColor: color.hex }),
                                disableAlpha: true
                            })
                        )
                    )
                ),

                // Block preview in editor
                el('div', {
                    className: 'resources-list-block-placeholder',
                    style: {
                        padding: '20px',
                        textAlign: 'center',
                        border: '2px dashed #ccc',
                        borderRadius: '4px',
                        backgroundColor: '#f9f9f9',
                        position: 'relative'
                    }
                },
                    el('div', {
                        style: {
                            fontSize: '24px',
                            marginBottom: '8px'
                        }
                    }, '📋'),
                    el('h3', {
                        style: {
                            margin: '0 0 8px',
                            color: '#666',
                            fontSize: '18px'
                        }
                    }, 'Lista Zasobów'),
                    el('p', {
                        style: {
                            margin: '0 0 16px',
                            color: '#999',
                            fontSize: '14px'
                        }
                    }, 'Spersonalizowana tabela z nieruchomościami'),

                    // Configuration summary
                    el('div', {
                        style: {
                            backgroundColor: 'white',
                            border: '1px solid #ddd',
                            borderRadius: '4px',
                            padding: '12px',
                            textAlign: 'left',
                            fontSize: '12px',
                            color: '#666'
                        }
                    },
                        el('div', { style: { marginBottom: '4px' } },
                            '🏠 Typy: ', attributes.selectedTypes.length,
                            attributes.selectedTypes.length === 1 ? ' typ' : ' typy'
                        ),
                        el('div', { style: { marginBottom: '4px' } },
                            '📊 Kolumny: ', attributes.visibleColumns.length,
                            attributes.visibleColumns.length === 1 ? ' kolumna' : ' kolumn'
                        ),
                        el('div', {},
                            '🎨 Kolory: ',
                            attributes.headerBgColor !== '#f9f9f9' ||
                            attributes.headerTextColor !== '#333333' ||
                            attributes.textColor !== '#333333' ? 'Spersonalizowane' : 'Domyślne'
                        )
                    )
                )
            );
        },

        save: function() {
            // Return null since we're using server-side rendering
            return null;
        }
    });
})();