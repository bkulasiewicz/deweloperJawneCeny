(function() {
    const { registerBlockType } = wp.blocks;
    const { createElement: el, Fragment } = wp.element;
    const { InspectorControls } = wp.blockEditor;
    const { PanelBody, CheckboxControl, TextControl, SelectControl, ColorPicker, __experimentalNumberControl: NumberControl } = wp.components;

    // Available database fields
    const DATABASE_FIELDS = [
        { label: 'Cena całkowita', value: 'total_price' },
        { label: 'Cena za m²', value: 'price_per_m2' },
        { label: 'Powierzchnia użytkowa', value: 'usable_area' },
        { label: 'Powierzchnia ogrodu', value: 'garden_area' },
        { label: 'Liczba pokoi', value: 'room_count' },
        { label: 'Piętro', value: 'floor_number' },
        { label: 'Status', value: 'status' },
        { label: 'Typ nieruchomości', value: 'property_type' },
        { label: 'Numer lokalu', value: 'unit_number' }
    ];

    // Filter type options
    const FILTER_TYPES = [
        { label: 'Zakres (od-do)', value: 'range' },
        { label: 'Minimum (powyżej)', value: 'min' },
        { label: 'Maximum (poniżej)', value: 'max' },
        { label: 'Dokładna wartość', value: 'exact' },
        { label: 'Lista wartości', value: 'list' }
    ];

    registerBlockType('jawne-ceny/resources-filters', {
        title: 'Filtry Zasobów',
        description: 'Widget do filtrowania listy zasobów/mieszkań',
        category: 'widgets',
        icon: 'filter',
        keywords: ['filtry', 'zasoby', 'mieszkania', 'filtrowanie'],

        attributes: {
            filterGroups: {
                type: 'array',
                default: [
                    {
                        id: 'price_300_500',
                        enabled: false,
                        label: 'Cena 300.000 - 500.000 PLN',
                        field: 'total_price',
                        filterType: 'range',
                        conditions: {
                            min: 300000,
                            max: 500000
                        }
                    },
                    {
                        id: 'area_above_60',
                        enabled: false,
                        label: 'Powierzchnia powyżej 60m²',
                        field: 'usable_area',
                        filterType: 'min',
                        conditions: {
                            min: 60
                        }
                    },
                    {
                        id: 'rooms_2_3',
                        enabled: false,
                        label: '2-3 pokoje',
                        field: 'room_count',
                        filterType: 'list',
                        conditions: {
                            values: ['2', '3']
                        }
                    },
                    {
                        id: 'ground_floor',
                        enabled: false,
                        label: 'Parter',
                        field: 'floor_number',
                        filterType: 'exact',
                        conditions: {
                            value: '0'
                        }
                    }
                ]
            },

            // Styling options
            headerBgColor: {
                type: 'string',
                default: '#ffffff'
            },
            headerTextColor: {
                type: 'string',
                default: '#333'
            },
            borderColor: {
                type: 'string',
                default: '#e1e5e9'
            },
            groupBgColor: {
                type: 'string',
                default: '#fafafa'
            },
            groupHoverBgColor: {
                type: 'string',
                default: '#f8f9fa'
            },
            textColor: {
                type: 'string',
                default: '#333'
            },
            applyBtnBgColor: {
                type: 'string',
                default: '#007cba'
            },
            applyBtnTextColor: {
                type: 'string',
                default: '#ffffff'
            },
            clearBtnBgColor: {
                type: 'string',
                default: '#f6f7f7'
            },
            clearBtnTextColor: {
                type: 'string',
                default: '#50575e'
            },
            headerFontFamily: {
                type: 'string',
                default: 'inherit'
            },
            contentFontFamily: {
                type: 'string',
                default: 'inherit'
            },

            // Button text customization
            applyBtnText: {
                type: 'string',
                default: 'Zastosuj filtry'
            },
            clearBtnText: {
                type: 'string',
                default: 'Wyczyść'
            },
            widgetTitle: {
                type: 'string',
                default: 'Filtry'
            }
        },

        edit: function(props) {
            const { attributes, setAttributes } = props;

            // Helper functions
            const updateFilterGroup = function(groupIndex, property, value) {
                const newGroups = [...attributes.filterGroups];
                newGroups[groupIndex] = {
                    ...newGroups[groupIndex],
                    [property]: value
                };
                setAttributes({ filterGroups: newGroups });
            };

            const updateCondition = function(groupIndex, conditionKey, value) {
                const newGroups = [...attributes.filterGroups];
                newGroups[groupIndex] = {
                    ...newGroups[groupIndex],
                    conditions: {
                        ...newGroups[groupIndex].conditions,
                        [conditionKey]: value
                    }
                };
                setAttributes({ filterGroups: newGroups });
            };

            const removeFilter = function(groupIndex) {
                const newGroups = attributes.filterGroups.filter((_, index) => index !== groupIndex);
                setAttributes({ filterGroups: newGroups });
            };

            const addNewFilter = function() {
                const newFilter = {
                    id: 'filter_' + Date.now(),
                    enabled: false,
                    label: 'Nowy filtr',
                    field: 'total_price',
                    filterType: 'range',
                    conditions: {
                        min: 0,
                        max: 1000000
                    }
                };
                setAttributes({
                    filterGroups: [...attributes.filterGroups, newFilter]
                });
            };

            const generateId = function(label) {
                return label.toLowerCase()
                    .replace(/[^a-z0-9]/g, '_')
                    .replace(/_+/g, '_')
                    .replace(/^_|_$/g, '');
            };

            return el(Fragment, {},
                el(InspectorControls, {},
                    el(PanelBody, {
                        title: 'Instrukcje',
                        initialOpen: true
                    },
                        el('p', {}, 'Skonfiguruj filtry, które będą dostępne dla użytkowników. Admin definiuje warunki filtrowania, a użytkownicy mogą tylko zaznaczać checkboxy.'),
                        el('p', { style: { fontSize: '12px', color: '#666' } }, 'Pamiętaj: Aby filtry działały, dodaj do strony również blok "Lista Zasobów" z włączoną opcją czytania filtrów z URL.')
                    ),

                    // Filter groups panels
                    attributes.filterGroups.map((filterGroup, groupIndex) =>
                        el(PanelBody, {
                            key: filterGroup.id || groupIndex,
                            title: filterGroup.label || `Filtr ${groupIndex + 1}`,
                            initialOpen: false
                        },
                            el(CheckboxControl, {
                                label: 'Włącz ten filtr',
                                checked: filterGroup.enabled,
                                onChange: (checked) => updateFilterGroup(groupIndex, 'enabled', checked)
                            }),

                            filterGroup.enabled && el(Fragment, {},
                                el(TextControl, {
                                    label: 'Etykieta filtru (co widzi użytkownik)',
                                    value: filterGroup.label,
                                    onChange: (value) => {
                                        updateFilterGroup(groupIndex, 'label', value);
                                        // Auto-generate ID from label
                                        updateFilterGroup(groupIndex, 'id', generateId(value));
                                    },
                                    placeholder: 'np. Cena 300k-500k'
                                }),

                                el(SelectControl, {
                                    label: 'Pole z bazy danych',
                                    value: filterGroup.field,
                                    options: DATABASE_FIELDS,
                                    onChange: (value) => updateFilterGroup(groupIndex, 'field', value)
                                }),

                                el(SelectControl, {
                                    label: 'Typ filtrowania',
                                    value: filterGroup.filterType,
                                    options: FILTER_TYPES,
                                    onChange: (value) => updateFilterGroup(groupIndex, 'filterType', value)
                                }),

                                // Conditional configuration based on filter type
                                filterGroup.filterType === 'range' && el(Fragment, {},
                                    el('h4', { style: { margin: '16px 0 8px' } }, 'Zakres wartości:'),
                                    el('div', { style: { display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '12px' } },
                                        el(NumberControl, {
                                            label: 'Od',
                                            value: filterGroup.conditions?.min || 0,
                                            onChange: (value) => updateCondition(groupIndex, 'min', parseFloat(value) || 0)
                                        }),
                                        el(NumberControl, {
                                            label: 'Do',
                                            value: filterGroup.conditions?.max || 0,
                                            onChange: (value) => updateCondition(groupIndex, 'max', parseFloat(value) || 0)
                                        })
                                    )
                                ),

                                filterGroup.filterType === 'min' && el(NumberControl, {
                                    label: 'Wartość minimalna',
                                    value: filterGroup.conditions?.min || 0,
                                    onChange: (value) => updateCondition(groupIndex, 'min', parseFloat(value) || 0)
                                }),

                                filterGroup.filterType === 'max' && el(NumberControl, {
                                    label: 'Wartość maksymalna',
                                    value: filterGroup.conditions?.max || 0,
                                    onChange: (value) => updateCondition(groupIndex, 'max', parseFloat(value) || 0)
                                }),

                                filterGroup.filterType === 'exact' && el(TextControl, {
                                    label: 'Dokładna wartość',
                                    value: filterGroup.conditions?.value || '',
                                    onChange: (value) => updateCondition(groupIndex, 'value', value)
                                }),

                                filterGroup.filterType === 'list' && el(Fragment, {},
                                    el('h4', { style: { margin: '16px 0 8px' } }, 'Lista wartości:'),
                                    el(TextControl, {
                                        label: 'Wartości (oddzielone przecinkami)',
                                        value: Array.isArray(filterGroup.conditions?.values) ? filterGroup.conditions.values.join(', ') : '',
                                        onChange: (value) => {
                                            const values = value.split(',').map(v => v.trim()).filter(v => v);
                                            updateCondition(groupIndex, 'values', values);
                                        },
                                        placeholder: '1, 2, 3',
                                        help: 'Wprowadź wartości oddzielone przecinkami'
                                    })
                                ),

                                el('hr'),
                                el('div', { style: { textAlign: 'center' } },
                                    el('button', {
                                        type: 'button',
                                        onClick: () => removeFilter(groupIndex),
                                        className: 'button',
                                        style: { color: '#d63638' }
                                    }, 'Usuń ten filtr')
                                )
                            )
                        )
                    ),

                    // Add new filter button
                    el(PanelBody, {
                        title: 'Dodaj nowy filtr',
                        initialOpen: false
                    },
                        el('div', { style: { textAlign: 'center' } },
                            el('button', {
                                type: 'button',
                                onClick: addNewFilter,
                                className: 'button button-primary'
                            }, 'Dodaj nowy filtr')
                        )
                    ),

                    // Styling panel
                    el(PanelBody, {
                        title: 'Stylizacja widgetu',
                        initialOpen: false
                    },
                        el(TextControl, {
                            label: 'Tytuł widgetu',
                            value: attributes.widgetTitle,
                            onChange: (value) => setAttributes({ widgetTitle: value })
                        }),
                        el('hr'),
                        el('h4', { style: { margin: '16px 0 8px' } }, 'Kolory podstawowe'),
                        el('div', { style: { marginBottom: '12px' } },
                            el('label', { style: { display: 'block', marginBottom: '4px' } }, 'Tło nagłówka'),
                            el(ColorPicker, {
                                color: attributes.headerBgColor,
                                onChangeComplete: (color) => setAttributes({ headerBgColor: color.hex }),
                                disableAlpha: true
                            })
                        ),
                        el('div', { style: { marginBottom: '12px' } },
                            el('label', { style: { display: 'block', marginBottom: '4px' } }, 'Tekst nagłówka'),
                            el(ColorPicker, {
                                color: attributes.headerTextColor,
                                onChangeComplete: (color) => setAttributes({ headerTextColor: color.hex }),
                                disableAlpha: true
                            })
                        ),
                        el('div', { style: { marginBottom: '12px' } },
                            el('label', { style: { display: 'block', marginBottom: '4px' } }, 'Kolor ramki'),
                            el(ColorPicker, {
                                color: attributes.borderColor,
                                onChangeComplete: (color) => setAttributes({ borderColor: color.hex }),
                                disableAlpha: true
                            })
                        ),
                        el('div', { style: { marginBottom: '12px' } },
                            el('label', { style: { display: 'block', marginBottom: '4px' } }, 'Tło grup filtrów'),
                            el(ColorPicker, {
                                color: attributes.groupBgColor,
                                onChangeComplete: (color) => setAttributes({ groupBgColor: color.hex }),
                                disableAlpha: true
                            })
                        ),
                        el('div', { style: { marginBottom: '16px' } },
                            el('label', { style: { display: 'block', marginBottom: '4px' } }, 'Tekst filtrów'),
                            el(ColorPicker, {
                                color: attributes.textColor,
                                onChangeComplete: (color) => setAttributes({ textColor: color.hex }),
                                disableAlpha: true
                            })
                        ),

                        el('hr'),
                        el('h4', { style: { margin: '16px 0 8px' } }, 'Przycisk "Zastosuj"'),
                        el(TextControl, {
                            label: 'Tekst przycisku',
                            value: attributes.applyBtnText,
                            onChange: (value) => setAttributes({ applyBtnText: value })
                        }),
                        el('div', { style: { marginBottom: '12px' } },
                            el('label', { style: { display: 'block', marginBottom: '4px' } }, 'Tło przycisku'),
                            el(ColorPicker, {
                                color: attributes.applyBtnBgColor,
                                onChangeComplete: (color) => setAttributes({ applyBtnBgColor: color.hex }),
                                disableAlpha: true
                            })
                        ),
                        el('div', { style: { marginBottom: '16px' } },
                            el('label', { style: { display: 'block', marginBottom: '4px' } }, 'Tekst przycisku'),
                            el(ColorPicker, {
                                color: attributes.applyBtnTextColor,
                                onChangeComplete: (color) => setAttributes({ applyBtnTextColor: color.hex }),
                                disableAlpha: true
                            })
                        ),

                        el('hr'),
                        el('h4', { style: { margin: '16px 0 8px' } }, 'Przycisk "Wyczyść"'),
                        el(TextControl, {
                            label: 'Tekst przycisku',
                            value: attributes.clearBtnText,
                            onChange: (value) => setAttributes({ clearBtnText: value })
                        }),
                        el('div', { style: { marginBottom: '12px' } },
                            el('label', { style: { display: 'block', marginBottom: '4px' } }, 'Tło przycisku'),
                            el(ColorPicker, {
                                color: attributes.clearBtnBgColor,
                                onChangeComplete: (color) => setAttributes({ clearBtnBgColor: color.hex }),
                                disableAlpha: true
                            })
                        ),
                        el('div', { style: { marginBottom: '16px' } },
                            el('label', { style: { display: 'block', marginBottom: '4px' } }, 'Tekst przycisku'),
                            el(ColorPicker, {
                                color: attributes.clearBtnTextColor,
                                onChangeComplete: (color) => setAttributes({ clearBtnTextColor: color.hex }),
                                disableAlpha: true
                            })
                        ),

                        el('hr'),
                        el('h4', { style: { margin: '16px 0 8px' } }, 'Czcionki'),
                        el(SelectControl, {
                            label: 'Czcionka nagłówka',
                            value: attributes.headerFontFamily,
                            options: [
                                { label: 'Domyślna', value: 'inherit' },
                                { label: 'Arial', value: 'Arial, sans-serif' },
                                { label: 'Helvetica', value: 'Helvetica, sans-serif' },
                                { label: 'Georgia', value: 'Georgia, serif' },
                                { label: 'Times New Roman', value: '"Times New Roman", serif' },
                                { label: 'Verdana', value: 'Verdana, sans-serif' }
                            ],
                            onChange: (value) => setAttributes({ headerFontFamily: value })
                        }),
                        el(SelectControl, {
                            label: 'Czcionka treści',
                            value: attributes.contentFontFamily,
                            options: [
                                { label: 'Domyślna', value: 'inherit' },
                                { label: 'Arial', value: 'Arial, sans-serif' },
                                { label: 'Helvetica', value: 'Helvetica, sans-serif' },
                                { label: 'Georgia', value: 'Georgia, serif' },
                                { label: 'Times New Roman', value: '"Times New Roman", serif' },
                                { label: 'Verdana', value: 'Verdana, sans-serif' }
                            ],
                            onChange: (value) => setAttributes({ contentFontFamily: value })
                        })
                    )
                ),

                // Block preview in editor
                el('div', {
                    className: 'resources-filters-block-placeholder',
                    style: {
                        padding: '20px',
                        border: '2px dashed #ddd',
                        borderRadius: '8px',
                        textAlign: 'center',
                        backgroundColor: '#f9f9f9'
                    }
                },
                    el('h3', { style: { margin: '0 0 16px' } }, 'Filtry Zasobów'),

                    // Show enabled filters preview
                    attributes.filterGroups.filter(group => group.enabled).length > 0 ?
                        el('div', { style: { textAlign: 'left' } },
                            el('h4', {}, 'Włączone filtry:'),
                            el('ul', {},
                                attributes.filterGroups
                                    .filter(group => group.enabled)
                                    .map(group =>
                                        el('li', { key: group.id }, group.label)
                                    )
                            )
                        ) :
                        el('p', { style: { color: '#666', fontStyle: 'italic' } },
                            'Brak włączonych filtrów. Skonfiguruj filtry w panelu po prawej.'
                        ),

                    el('p', { style: { fontSize: '12px', color: '#666', marginTop: '16px' } },
                        'Ten widget będzie wyświetlał formularz z checkboxami dla skonfigurowanych filtrów.'
                    )
                )
            );
        },

        save: function() {
            // Dynamic block - rendered in PHP
            return null;
        }
    });
})();