<?php

if (!defined('ABSPATH')) {
    exit;
}

/**
 * Resource Table Renderer Helper
 * Shared logic for rendering resource tables between shortcode and Gutenberg block
 */
class ResourceTableRenderer {

    // Functional column constants
    public const COLUMN_HISTORIA_CEN = 'historia_cen';

    /**
     * Default column configuration
     */
    public static function getDefaultColumns(): array {
        return [
            ResourceDto::FIELD_NR_LOKALU,
            ResourceDto::FIELD_RODZAJ_NIERUCHOMOSCI,
            ResourceDto::FIELD_POWIERZCHNIA_UZYTKOWA,
            PriceHistoryDto::FIELD_CENA_CALKOWITA,
            ResourceDto::FIELD_STATUS,
            self::COLUMN_HISTORIA_CEN
        ];
    }

    /**
     * Get all available columns for configuration
     */
    public static function getAvailableColumns(): array {
        return [
            // Basic information from ResourceDto
            ResourceDto::FIELD_NR_LOKALU,
            ResourceDto::FIELD_RODZAJ_NIERUCHOMOSCI,
            ResourceDto::FIELD_POWIERZCHNIA_UZYTKOWA,
            ResourceDto::FIELD_STATUS,

            // Prices from PriceHistory
            PriceHistoryDto::FIELD_CENA_M2,
            PriceHistoryDto::FIELD_CENA_CALKOWITA,
            PriceHistoryDto::FIELD_CENA_Z_DODATKAMI,

            // Marketing fields from ResourceDto
            ResourceDto::FIELD_FLOOR_NUMBER,
            ResourceDto::FIELD_ROOM_COUNT,
            ResourceDto::FIELD_ADDITIONAL_DESCRIPTION,
            ResourceDto::FIELD_GARDEN_AREA,
            ResourceDto::FIELD_FLOOR_PLAN_PDF,

            // Functional
            self::COLUMN_HISTORIA_CEN
        ];
    }

    /**
     * Get default column names for display
     */
    public static function getDefaultColumnNames(): array {
        return [
            ResourceDto::FIELD_NR_LOKALU => 'Numer',
            ResourceDto::FIELD_RODZAJ_NIERUCHOMOSCI => 'Typ',
            ResourceDto::FIELD_POWIERZCHNIA_UZYTKOWA => 'Powierzchnia',
            ResourceDto::FIELD_STATUS => 'Status',
            PriceHistoryDto::FIELD_CENA_M2 => 'Cena za m²',
            PriceHistoryDto::FIELD_CENA_CALKOWITA => 'Cena całkowita',
            PriceHistoryDto::FIELD_CENA_Z_DODATKAMI => 'Cena z dodatkami',
            ResourceDto::FIELD_FLOOR_NUMBER => 'Piętro',
            ResourceDto::FIELD_ROOM_COUNT => 'Pokoje',
            ResourceDto::FIELD_ADDITIONAL_DESCRIPTION => 'Opis',
            ResourceDto::FIELD_GARDEN_AREA => 'Ogród',
            ResourceDto::FIELD_FLOOR_PLAN_PDF => 'Plan',
            self::COLUMN_HISTORIA_CEN => 'Historia cen'
        ];
    }

    /**
     * Render resources table with full customization
     */
    public static function renderTable(
        array $resources,
        array $visible_columns,
        array $column_names,
        array $styling_options = [],
        string $detail_page_url = '',
        string $container_class = 'ujc-shortcode-resources-list'
    ): string {

        if (empty($resources)) {
            return '<div class="ujc-no-resources">Brak zasobów do wyświetlenia.</div>';
        }

        // Start output buffering
        ob_start();

        // Ensure CSS is loaded
        wp_enqueue_style(
            'ujc-resources-list-css',
            PLUGIN_URL . 'assets/blocks/resources-list-block.css',
            [],
            VERSION
        );

        // Generate dynamic CSS
        self::renderDynamicCSS($styling_options, !empty($detail_page_url));

        ?>
        <div class="<?php echo esc_attr($container_class); ?>">
            <table class="resources-table">
                <thead>
                    <tr>
                        <?php foreach ($visible_columns as $column): ?>
                            <th><?php echo esc_html($column_names[$column] ?? ucfirst($column)); ?></th>
                        <?php endforeach; ?>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($resources as $resource): ?>
                        <?php
                        $row_classes = [];
                        $row_attributes = [];

                        // Make row clickable if detail_page_url is provided
                        if (!empty($detail_page_url)) {
                            $row_classes[] = 'clickable-row';
                            $detail_url = rtrim($detail_page_url, '/') . '/' . urlencode($resource->nr_lokalu);
                            $row_attributes[] = 'data-detail-url="' . esc_attr($detail_url) . '"';
                        }

                        $class_attr = !empty($row_classes) ? ' class="' . esc_attr(implode(' ', $row_classes)) . '"' : '';
                        $data_attrs = !empty($row_attributes) ? ' ' . implode(' ', $row_attributes) : '';
                        ?>
                        <tr<?php echo $class_attr . $data_attrs; ?>>
                            <?php foreach ($visible_columns as $column): ?>
                                <td><?php echo self::renderColumnValue($resource, $column, $styling_options); ?></td>
                            <?php endforeach; ?>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>

            <!-- Price History Modal -->
            <div id="price-history-modal" class="price-history-modal" style="display: none;">
                <div class="modal-content">
                    <div class="modal-header">
                        <h3>Historia cen - <span id="modal-resource-name"></span></h3>
                        <button class="modal-close">&times;</button>
                    </div>
                    <div class="modal-body">
                        <div id="history-loading">Ładowanie...</div>
                        <div id="history-content"></div>
                    </div>
                </div>
            </div>
        </div>

        <?php
        // Enqueue JavaScript for modals and interactions
        self::enqueueTableAssets(!empty($detail_page_url));

        return ob_get_clean();
    }

    /**
     * Render individual column value
     */
    public static function renderColumnValue($resource, string $column, array $styling_options = []): string {
        switch ($column) {
            case ResourceDto::FIELD_NR_LOKALU:
                return esc_html($resource->nr_lokalu);

            case ResourceDto::FIELD_RODZAJ_NIERUCHOMOSCI:
                try {
                    $propertyType = PropertyType::from($resource->rodzaj_nieruchomosci);
                    return esc_html($propertyType->getDisplayText());
                } catch (ValueError $e) {
                    return esc_html($resource->rodzaj_nieruchomosci);
                }

            case ResourceDto::FIELD_POWIERZCHNIA_UZYTKOWA:
                // Hide surface area for parking spaces
                if ($resource->rodzaj_nieruchomosci === PropertyType::PARKING_SPACE->value) {
                    return '—';
                }
                if ($resource->powierzchnia_uzytkowa !== null && $resource->powierzchnia_uzytkowa > 0) {
                    return esc_html(number_format($resource->powierzchnia_uzytkowa, 2, ',', ' ')) . ' m²';
                }
                return '—';

            case ResourceDto::FIELD_STATUS:
                try {
                    $status = ResourceStatus::from($resource->status);
                    $status_value = $resource->status;
                    $status_text = $status->getDisplayText();

                    // Get display style
                    $display_style = $styling_options['status_display_style'] ?? 'badge';

                    // Build CSS classes
                    $css_classes = ['ujc-status-' . $status_value];
                    if (!empty($display_style)) {
                        $css_classes[] = 'ujc-status-style-' . $display_style;
                    }

                    return '<span class="' . esc_attr(implode(' ', $css_classes)) . '">' . esc_html($status_text) . '</span>';
                } catch (ValueError $e) {
                    return esc_html($resource->status);
                }

            case PriceHistoryDto::FIELD_CENA_M2:
                // Hide price per m2 for parking spaces
                if ($resource->rodzaj_nieruchomosci === PropertyType::PARKING_SPACE->value) {
                    return '—';
                }
                if ($resource->cena_m2 !== null && $resource->cena_m2 > 0) {
                    return esc_html(number_format($resource->cena_m2, 2, ',', ' ')) . ' zł';
                }
                return '—';

            case PriceHistoryDto::FIELD_CENA_CALKOWITA:
                if ($resource->cena_calkowita) {
                    return esc_html(number_format($resource->cena_calkowita, 2, ',', ' ')) . ' zł';
                }
                return '—';

            case PriceHistoryDto::FIELD_CENA_Z_DODATKAMI:
                if ($resource->cena_z_dodatkami) {
                    return esc_html(number_format($resource->cena_z_dodatkami, 2, ',', ' ')) . ' zł';
                }
                return '—';

            case self::COLUMN_HISTORIA_CEN:
                $btn_text = !empty($styling_options['historia_btn_text']) ? $styling_options['historia_btn_text'] : 'Historia';
                $css_classes = ['ujc-historia-btn'];

                return '<button class="' . esc_attr(implode(' ', $css_classes)) . '" data-resource-id="' . esc_attr($resource->id) . '" data-resource-name="' . esc_attr($resource->nr_lokalu) . '">' . esc_html($btn_text) . '</button>';

            // Marketing fields
            case ResourceDto::FIELD_FLOOR_NUMBER:
                return $resource->floor_number ? esc_html($resource->floor_number) : '—';

            case ResourceDto::FIELD_ROOM_COUNT:
                return $resource->room_count ? esc_html($resource->room_count) : '—';

            case ResourceDto::FIELD_ADDITIONAL_DESCRIPTION:
                return $resource->additional_description ? esc_html(wp_trim_words($resource->additional_description, 10)) : '—';

            case ResourceDto::FIELD_GARDEN_AREA:
                return $resource->garden_area ? esc_html(number_format($resource->garden_area, 2, ',', ' ')) . ' m²' : '—';

            case ResourceDto::FIELD_FLOOR_PLAN_PDF:
                if ($resource->floor_plan_pdf) {
                    $filename = basename($resource->floor_plan_pdf);
                    $btn_text = !empty($styling_options['karta_btn_text']) ? $styling_options['karta_btn_text'] : 'Karta lokalu';
                    $css_classes = ['download-floorplan-btn', 'ujc-karta-btn'];

                    return '<button class="' . esc_attr(implode(' ', $css_classes)) . '" data-filename="' . esc_attr($filename) . '">' . esc_html($btn_text) . '</button>';
                }
                return '—';

            default:
                return '—';
        }
    }

    /**
     * Render CSS variables for styling
     */
    public static function renderDynamicCSS(array $styling_options, bool $has_clickable_rows = false): void {
        ?>
        <style>
        /* CSS Custom Properties for resource table styling */
        :root {
            --header-bg-color: <?php echo esc_attr($styling_options['header_bg_color'] ?? '#f9f9f9'); ?>;
            --header-text-color: <?php echo esc_attr($styling_options['header_text_color'] ?? '#333333'); ?>;
            --text-color: <?php echo esc_attr($styling_options['text_color'] ?? '#333333'); ?>;
            --hover-bg-color: <?php echo esc_attr($styling_options['hover_bg_color'] ?? '#f5f5f5'); ?>;
            --header-font-family: <?php echo esc_attr($styling_options['header_font_family'] ?? 'inherit'); ?>;
            --content-font-family: <?php echo esc_attr($styling_options['content_font_family'] ?? 'inherit'); ?>;
            --historia-btn-bg-color: <?php echo esc_attr($styling_options['historia_btn_bg_color'] ?? '#007cba'); ?>;
            --historia-btn-text-color: <?php echo esc_attr($styling_options['historia_btn_text_color'] ?? '#ffffff'); ?>;
            --karta-btn-bg-color: <?php echo esc_attr($styling_options['karta_btn_bg_color'] ?? '#007cba'); ?>;
            --karta-btn-text-color: <?php echo esc_attr($styling_options['karta_btn_text_color'] ?? '#ffffff'); ?>;
            --status-available-bg: <?php echo esc_attr($styling_options['status_available_bg_color'] ?? '#28a745'); ?>;
            --status-available-color: <?php echo esc_attr($styling_options['status_available_text_color'] ?? '#ffffff'); ?>;
            --status-sold-bg: <?php echo esc_attr($styling_options['status_sold_bg_color'] ?? '#dc3545'); ?>;
            --status-sold-color: <?php echo esc_attr($styling_options['status_sold_text_color'] ?? '#ffffff'); ?>;
            --status-reserved-bg: <?php echo esc_attr($styling_options['status_reserved_bg_color'] ?? '#ffc107'); ?>;
            --status-reserved-color: <?php echo esc_attr($styling_options['status_reserved_text_color'] ?? '#000000'); ?>;
            --status-font-size: <?php echo esc_attr($styling_options['status_font_size'] ?? '0.875em'); ?>;
            --status-padding: <?php echo esc_attr($styling_options['status_padding'] ?? '4px 8px'); ?>;
            --status-border-radius: <?php echo esc_attr($styling_options['status_border_radius'] ?? '4px'); ?>;
            --status-font-weight: <?php echo esc_attr($styling_options['status_font_weight'] ?? 'normal'); ?>;
        }
        </style>
        <?php
    }

    /**
     * Enqueue necessary JavaScript and CSS assets
     */
    private static function enqueueTableAssets(bool $has_clickable_rows = false): void {
        // Always enqueue the resources widget JavaScript for modal functionality
        wp_enqueue_script(
            'ujc-resources-widget',
            plugins_url('assets/blocks/resources-list-widget.js', dirname(dirname(__DIR__)) . '/ustawa-jawnosci-cen.php'),
            ['jquery'],
            VERSION,
            true
        );

        wp_localize_script('ujc-resources-widget', 'resourcesListAjax', [
            'ajax_url' => admin_url('admin-ajax.php'),
            'nonce' => wp_create_nonce('resources_list_nonce'),
            'strings' => [
                'loading' => 'Ładowanie...',
                'error' => 'Wystąpił błąd podczas ładowania historii cen.',
                'no_history' => 'Brak historii cen dla tego zasobu.'
            ]
        ]);

        // Enqueue clickable rows JavaScript if needed
        if ($has_clickable_rows) {
            wp_enqueue_script(
                'ujc-clickable-rows',
                plugins_url('assets/frontend-clickable-rows.js', dirname(dirname(__DIR__)) . '/ustawa-jawnosci-cen.php'),
                ['jquery'],
                '1.0.1',
                true
            );
        }
    }
}