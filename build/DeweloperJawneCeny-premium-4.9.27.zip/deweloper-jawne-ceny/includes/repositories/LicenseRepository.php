<?php

namespace JawneCeny;

if (!defined('ABSPATH')) {
	exit;
}

/**
 * License Repository
 *
 * Handles storage and retrieval of license data from wp_options.
 * Implements strict validation with auto-clear on domain mismatch.
 */
class LicenseRepository {

	/**
	 * Option key for license data storage
	 */
	const LICENSE_DATA = 'jawneceny_license_data';

	/**
	 * Saves license data to wp_options
	 *
	 * @param array $data License data (key, status, domain, activated_at, last_checked, last_api_status, expires_at).
	 * @return bool True if successfully saved.
	 */
	public function save( array $data ) {
		return update_option( self::LICENSE_DATA, $data );
	}

	/**
	 * Gets license data from wp_options
	 *
	 * @return array|null License data or null if not found.
	 */
	public function get() {
		$data = get_option( self::LICENSE_DATA, null );

		if (empty( $data ) || ! is_array( $data )) {
			return null;
		}

		return $data;
	}

	/**
	 * Clears license data from wp_options
	 *
	 * @return bool True if successfully cleared.
	 */
	public function clear() {
		return delete_option( self::LICENSE_DATA );
	}

	/**
	 * Checks if license is valid
	 *
	 * Validates:
	 * 1. License data exists
	 * 2. Status is 'active'
	 * 3. Domain matches current domain (strict check, auto-clear on mismatch)
	 * 4. License hasn't expired (if expires_at is set)
	 * 5. Last API validation didn't fail (no grace period)
	 *
	 * @return bool True if license is valid.
	 */
	public function isValid() {
		// 1. Check if license data exists.
		$license_data = $this->get();

		if (null === $license_data) {
			return false;
		}

		// 2. Check status.
		if (! isset( $license_data['status'] ) || 'active' !== $license_data['status']) {
			return false;
		}

		// 3. STRICT DOMAIN CHECK - detect migration.
		$current_domain = $this->getDomain();
		$saved_domain   = $license_data['domain'] ?? '';

		if ($current_domain !== $saved_domain) {
			// Domain mismatch detected - clear license data.
			$this->clear();
			return false;
		}

		// 4. Check expiration (lifetime licenses have expires_at = null).
		if (isset( $license_data['expires_at'] ) && null !== $license_data['expires_at']) {
			if (time() > $license_data['expires_at']) {
				// License expired - clear data.
				$this->clear();
				return false;
			}
		}

		// 5. NO GRACE PERIOD - check last API validation status.
		$last_api_status = $license_data['last_api_status'] ?? 'unknown';

		if (in_array( $last_api_status, array( 'failed', 'invalid' ), true )) {
			// Last API validation failed - clear data.
			$this->clear();
			return false;
		}

		// All checks passed.
		return true;
	}

	/**
	 * Gets current domain from WordPress home_url
	 *
	 * @return string Current domain (e.g., 'example.com').
	 */
	public function getDomain() {
		$home_url = home_url();
		$parsed   = wp_parse_url( $home_url );

		return $parsed['host'] ?? '';
	}

	/**
	 * Updates last checked timestamp and API status
	 *
	 * @param string $api_status API validation result: 'success', 'failed', 'invalid'.
	 * @return bool True if successfully updated.
	 */
	public function updateLastCheck( $api_status ) {
		$license_data = $this->get();

		if (null === $license_data) {
			return false;
		}

		$license_data['last_checked']    = time();
		$license_data['last_api_status'] = $api_status;

		return $this->save( $license_data );
	}

	/**
	 * Updates license status
	 *
	 * @param string $status New status: 'active', 'invalid', 'expired'.
	 * @return bool True if successfully updated.
	 */
	public function updateStatus( $status ) {
		$license_data = $this->get();

		if (null === $license_data) {
			return false;
		}

		$license_data['status'] = $status;

		return $this->save( $license_data );
	}
}
