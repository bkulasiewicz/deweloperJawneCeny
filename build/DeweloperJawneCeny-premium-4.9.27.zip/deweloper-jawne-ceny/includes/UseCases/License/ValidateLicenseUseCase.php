<?php

namespace JawneCeny;

if (!defined('ABSPATH')) {
	exit;
}

/**
 * Validate License Use Case
 *
 * Handles periodic license validation through LMFWC API.
 * Called by WP Cron daily to verify license status.
 * Clears license data if validation fails (no grace period).
 */
class ValidateLicenseUseCase {

	/**
	 * License validator service
	 *
	 * @var LicenseValidator
	 */
	private $validator;

	/**
	 * License repository
	 *
	 * @var LicenseRepository
	 */
	private $repository;

	/**
	 * Constructor
	 *
	 * @param LicenseValidator  $validator  License validator service.
	 * @param LicenseRepository $repository License repository.
	 */
	public function __construct( LicenseValidator $validator, LicenseRepository $repository ) {
		$this->validator  = $validator;
		$this->repository = $repository;
	}

	/**
	 * Executes license validation
	 *
	 * Called by WP Cron or manually to validate existing license.
	 * NO GRACE PERIOD - immediately clears license data if validation fails.
	 *
	 * @return Result Success or failure with message.
	 */
	public function execute() {
		// Get existing license data.
		$license_data = $this->repository->get();

		if (null === $license_data) {
			// No license to validate - silent return.
			return Result::failure( __( 'Brak licencji do walidacji.', 'ustawa-jawnosci-cen' ) );
		}

		$license_key = $license_data['key'] ?? '';

		if (empty( $license_key )) {
			// Invalid license data - clear it.
			$this->repository->clear();
			return Result::failure( __( 'Nieprawidłowe dane licencji.', 'ustawa-jawnosci-cen' ) );
		}

		// Call LMFWC validation API.
		$api_response = $this->validator->validate( $license_key );

		if (! $api_response['success']) {
			// Validation failed - clear license data (NO GRACE PERIOD).
			$this->repository->updateLastCheck( 'failed' );
			$this->repository->clear();

			return Result::failure(
				sprintf(
					/* translators: %s: API error message */
					__( 'Walidacja licencji nie powiodła się: %s', 'ustawa-jawnosci-cen' ),
					$api_response['message']
				)
			);
		}

		// Validation successful - update last check.
		$this->repository->updateLastCheck( 'success' );

		return Result::success( __( 'Licencja została pomyślnie zwalidowana.', 'ustawa-jawnosci-cen' ) );
	}
}
