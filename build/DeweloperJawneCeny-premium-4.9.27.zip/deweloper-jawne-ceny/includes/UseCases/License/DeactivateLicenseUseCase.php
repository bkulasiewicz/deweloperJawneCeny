<?php

namespace JawneCeny;

if (!defined('ABSPATH')) {
	exit;
}

/**
 * Deactivate License Use Case
 *
 * Handles license deactivation by clearing local license data.
 * Note: Does not call LMFWC API deactivate endpoint (no transfer allowed).
 */
class DeactivateLicenseUseCase {

	/**
	 * License repository
	 *
	 * @var LicenseRepository
	 */
	private $repository;

	/**
	 * Constructor
	 *
	 * @param LicenseRepository $repository License repository.
	 */
	public function __construct( LicenseRepository $repository ) {
		$this->repository = $repository;
	}

	/**
	 * Executes license deactivation
	 *
	 * Clears license data from wp_options.
	 * Does NOT call API deactivate endpoint (license transfers not allowed).
	 *
	 * @return Result Success or failure with message.
	 */
	public function execute() {
		// Check if license exists.
		$license_data = $this->repository->get();

		if (null === $license_data) {
			return Result::failure( __( 'Brak licencji do dezaktywacji.', 'ustawa-jawnosci-cen' ) );
		}

		// Clear license data.
		$cleared = $this->repository->clear();

		if (! $cleared) {
			return Result::failure( __( 'Błąd podczas dezaktywacji licencji. Spróbuj ponownie.', 'ustawa-jawnosci-cen' ) );
		}

		return Result::success( __( 'Licencja została pomyślnie dezaktywowana.', 'ustawa-jawnosci-cen' ) );
	}
}
