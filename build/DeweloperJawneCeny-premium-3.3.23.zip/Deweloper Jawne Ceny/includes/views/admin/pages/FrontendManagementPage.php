<?php

if (!defined('ABSPATH')) {
    exit;
}

/**
 * Frontend Management Admin Page
 * Simple shortcode generator without backend storage
 */
class FrontendManagementPage {
    
    public function __construct() {
        Logger::info('FrontendManagementPage constructor started');
        
        // Add AJAX handlers  
        add_action('wp_ajax_ujc_reset_frontend_settings', [$this, 'ajax_reset_settings']);
        
        Logger::info('FrontendManagementPage constructor completed');
    }
    
    /**
     * Render the frontend management page
     */
    public function render() {
        // Use default settings for display
        $settings = $this->getDefaultSettings();
        
        ?>
        <div class="wrap">
            <h1>Warstwa Frontendowa</h1>
            
            <div class="notice notice-info">
                <p><strong>Konfiguracja widgetów frontendowych</strong></p>
                <p>Skonfiguruj sposób wyświetlania nieruchomości na stronie internetowej i wygeneruj shortcode.</p>
            </div>
            
            <form id="frontend-settings-form" method="post">
                <?php wp_nonce_field('ujc_frontend_settings_nonce', 'nonce'); ?>
                
                <!-- Generator Shortcode Section -->
                <div class="postbox">
                    <div class="postbox-header">
                        <h2>Generator Shortcode</h2>
                    </div>
                    <div class="inside">
                        <!-- 3-Column Layout -->
                        <div class="shortcode-generator-grid">
                            <!-- Column 1: Basic Settings -->
                            <div class="column-basic-settings">
                                <h4>Podstawowe ustawienia</h4>
                                
                                <div class="setting-group">
                                    <label>Typy nieruchomości</label>
                                    <?php $this->render_property_types_checkboxes($settings); ?>
                                    <p class="description">Wybierz które typy nieruchomości mają być wyświetlane.</p>
                                </div>
                                
                                <div class="setting-group">
                                    <label for="primary-color">Kolor przewodni</label>
                                    <input type="color" 
                                           id="primary-color" 
                                           name="primary_color" 
                                           value="<?php echo esc_attr($settings['primary_color']); ?>" 
                                           class="color-picker">
                                    <p class="description">Kolor dla przycisków, hover effects i elementów tabeli.</p>
                                </div>
                                
                                <!-- Generated Shortcode Display -->
                                <div class="shortcode-preview">
                                    <h4>Wygenerowany shortcode:</h4>
                                    <div class="shortcode-display">
                                        <code id="generated-shortcode"><?php echo esc_html($this->generateShortcode($settings)); ?></code>
                                        <button type="button" class="button button-secondary" id="copy-shortcode">Kopiuj</button>
                                    </div>
                                </div>
                            </div>
                            
                            <!-- Column 2: Visible Columns -->
                            <div class="column-visible-columns">
                                <h4>Widoczne kolumny</h4>
                                
                                <div class="setting-group">
                                    <?php $this->render_visible_columns_checkboxes($settings); ?>
                                    <p class="description">Zaznacz kolumny które mają być wyświetlane w tabeli.</p>
                                </div>
                            </div>
                            
                            <!-- Column 3: Column Names (Dynamic) -->
                            <div class="column-names">
                                <h4>Nazwy kolumn</h4>
                                
                                <div class="setting-group">
                                    <?php $this->render_dynamic_column_names_inputs($settings); ?>
                                    <p class="description">Dostosuj nazwy dla zaznaczonych kolumn.</p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                
                <!-- Instructions Section -->
                <div class="postbox">
                    <div class="postbox-header">
                        <h2>Instrukcje użycia</h2>
                    </div>
                    <div class="inside">
                        <h4>Jak dodać widget na stronę:</h4>
                        <ol>
                            <li><strong>W edytorze Gutenberg:</strong> Dodaj blok "Shortcode" i wklej powyższy kod</li>
                            <li><strong>W widżetach:</strong> Dodaj widget "Tekst" lub "HTML" i wklej shortcode</li>
                            <li><strong>W szablonie PHP:</strong> Użyj <code>&lt;?php echo do_shortcode('[shortcode_tutaj]'); ?&gt;</code></li>
                        </ol>
                        
                        <h4>Przykłady użycia:</h4>
                        <ul>
                            <li><code>[resources_list]</code> - wszystkie typy z domyślnymi ustawieniami</li>
                            <li><code>[resources_list types="residential_unit"]</code> - tylko mieszkania</li>
                            <li><code>[resources_list types="parking_space" color="#ff6600"]</code> - miejsca postojowe z własnym kolorem</li>
                        </ul>
                        
                        <div class="notice notice-warning inline">
                            <p><strong>Uwaga:</strong> Po zapisaniu ustawień sprawdź efekt na stronie. Zmiany będą widoczne po odświeżeniu strony z widgetem.</p>
                        </div>
                    </div>
                </div>
                
                <!-- Action Buttons -->
                <div class="submit-section">
                    <button type="button" class="button button-secondary" id="reset-settings">
                        <span class="dashicons dashicons-undo"></span>
                        Przywróć domyślne
                    </button>
                </div>
            </form>
        </div>
        
        <?php $this->render_scripts_and_styles(); ?>
        <?php
    }
    
    /**
     * Render property types checkboxes
     */
    private function render_property_types_checkboxes(array $settings) {
        $selected_values = array_map(fn($type) => $type->value, $settings['selected_types']);
        
        echo '<div class="property-types-checkboxes">';
        foreach (PropertyType::cases() as $type) {
            $checked = in_array($type->value, $selected_values) ? 'checked' : '';
            echo '<label>';
            echo '<input type="checkbox" name="selected_types[]" value="' . esc_attr($type->value) . '" ' . $checked . '>';
            echo '<span>' . esc_html($type->getDisplayText()) . '</span>';
            echo '</label><br>';
        }
        echo '</div>';
    }
    
    /**
     * Render visible columns checkboxes
     */
    private function render_visible_columns_checkboxes(array $settings) {
        $available_columns = [
            // Basic information from ResourceDto
            ResourceDto::FIELD_NR_LOKALU,
            ResourceDto::FIELD_RODZAJ_NIERUCHOMOSCI,
            ResourceDto::FIELD_POWIERZCHNIA_UZYTKOWA,
            ResourceDto::FIELD_STATUS,
            
            // Prices from PriceHistory
            PriceHistoryDto::FIELD_CENA_M2,
            PriceHistoryDto::FIELD_CENA_CALKOWITA,
            PriceHistoryDto::FIELD_CENA_Z_DODATKAMI,
            
            // Marketing fields from ResourceDto
            ResourceDto::FIELD_FLOOR_NUMBER,
            ResourceDto::FIELD_ROOM_COUNT,
            ResourceDto::FIELD_ADDITIONAL_DESCRIPTION,
            ResourceDto::FIELD_GARDEN_AREA,
            ResourceDto::FIELD_FLOOR_PLAN_PDF,
            
            // Functional
            ResourcesListShortcode::COLUMN_HISTORIA_CEN
        ];
        
        echo '<div class="visible-columns-checkboxes">';
        foreach ($available_columns as $column) {
            $checked = in_array($column, $settings['visible_columns']) ? 'checked' : '';
            $display_name = $settings['column_names'][$column] ?? ucfirst($column);
            
            echo '<label>';
            echo '<input type="checkbox" name="visible_columns[]" value="' . esc_attr($column) . '" ' . $checked . '>';
            echo '<span>' . esc_html($display_name) . '</span>';
            echo '</label><br>';
        }
        echo '</div>';
    }
    
    /**
     * Render column names input fields (original - for old section)
     */
    private function render_column_names_inputs(array $settings) {
        $available_columns = [
            // Basic information from ResourceDto
            ResourceDto::FIELD_NR_LOKALU,
            ResourceDto::FIELD_RODZAJ_NIERUCHOMOSCI,
            ResourceDto::FIELD_POWIERZCHNIA_UZYTKOWA,
            ResourceDto::FIELD_STATUS,
            
            // Prices from PriceHistory
            PriceHistoryDto::FIELD_CENA_M2,
            PriceHistoryDto::FIELD_CENA_CALKOWITA,
            PriceHistoryDto::FIELD_CENA_Z_DODATKAMI,
            
            // Marketing fields from ResourceDto
            ResourceDto::FIELD_FLOOR_NUMBER,
            ResourceDto::FIELD_ROOM_COUNT,
            ResourceDto::FIELD_ADDITIONAL_DESCRIPTION,
            ResourceDto::FIELD_GARDEN_AREA,
            ResourceDto::FIELD_FLOOR_PLAN_PDF,
            
            // Functional
            ResourcesListShortcode::COLUMN_HISTORIA_CEN
        ];
        
        foreach ($available_columns as $column) {
            $current_name = $settings['column_names'][$column] ?? ucfirst($column);
            
            echo '<tr>';
            echo '<th scope="row">';
            echo '<label for="column_name_' . esc_attr($column) . '">' . esc_html(ucfirst($column)) . '</label>';
            echo '</th>';
            echo '<td>';
            echo '<input type="text" id="column_name_' . esc_attr($column) . '" name="column_names[' . esc_attr($column) . ']" value="' . esc_attr($current_name) . '" class="regular-text">';
            echo '</td>';
            echo '</tr>';
        }
    }
    
    /**
     * Render dynamic column names inputs - only for selected columns
     */
    private function render_dynamic_column_names_inputs(array $settings) {
        $available_columns = [
            // Basic information from ResourceDto
            ResourceDto::FIELD_NR_LOKALU,
            ResourceDto::FIELD_RODZAJ_NIERUCHOMOSCI,
            ResourceDto::FIELD_POWIERZCHNIA_UZYTKOWA,
            ResourceDto::FIELD_STATUS,
            
            // Prices from PriceHistory
            PriceHistoryDto::FIELD_CENA_M2,
            PriceHistoryDto::FIELD_CENA_CALKOWITA,
            PriceHistoryDto::FIELD_CENA_Z_DODATKAMI,
            
            // Marketing fields from ResourceDto
            ResourceDto::FIELD_FLOOR_NUMBER,
            ResourceDto::FIELD_ROOM_COUNT,
            ResourceDto::FIELD_ADDITIONAL_DESCRIPTION,
            ResourceDto::FIELD_GARDEN_AREA,
            ResourceDto::FIELD_FLOOR_PLAN_PDF,
            
            // Functional
            ResourcesListShortcode::COLUMN_HISTORIA_CEN
        ];
        $default_names = $this->getDefaultColumnNames();
        
        echo '<div class="dynamic-column-names">';
        
        foreach ($available_columns as $column) {
            $current_name = $settings['column_names'][$column] ?? ($default_names[$column] ?? ucfirst($column));
            $is_visible = in_array($column, $settings['visible_columns']);
            $display_name = $default_names[$column] ?? ucfirst($column);
            
            echo '<div class="column-name-input" data-column="' . esc_attr($column) . '" style="' . ($is_visible ? '' : 'display: none;') . '">';
            echo '<label for="dynamic_column_name_' . esc_attr($column) . '">Nazwa dla kolumny: <strong>' . esc_html($display_name) . '</strong></label>';
            echo '<input type="text" id="dynamic_column_name_' . esc_attr($column) . '" name="column_names[' . esc_attr($column) . ']" value="' . esc_attr($current_name) . '" class="regular-text" placeholder="Wprowadź własną nazwę">';
            echo '</div>';
        }
        
        echo '</div>';
    }
    
    
    /**
     * AJAX handler for resetting settings
     */
    public function ajax_reset_settings() {
        check_ajax_referer('ujc_frontend_settings_nonce', 'nonce');
        
        if (!current_user_can('manage_options')) {
            wp_send_json_error('Brak uprawnień');
        }
        
        // Reset to defaults by reloading page with default values
        wp_send_json_success([
            'message' => 'Ustawienia zostały zresetowane do domyślnych',
            'reload' => true
        ]);
    }
    
    /**
     * Get default settings for the form
     */
    private function getDefaultSettings() {
        return [
            'selected_types' => [PropertyType::RESIDENTIAL_UNIT],
            'primary_color' => '#007cba',
            'visible_columns' => [
                ResourceDto::FIELD_NR_LOKALU,
                ResourceDto::FIELD_RODZAJ_NIERUCHOMOSCI,
                ResourceDto::FIELD_POWIERZCHNIA_UZYTKOWA,
                PriceHistoryDto::FIELD_CENA_CALKOWITA,
                ResourceDto::FIELD_STATUS,
                ResourcesListShortcode::COLUMN_HISTORIA_CEN
            ],
            'column_names' => $this->getDefaultColumnNames()
        ];
    }
    
    /**
     * Get default column names for display
     */
    private function getDefaultColumnNames() {
        return [
            ResourceDto::FIELD_NR_LOKALU => 'Numer',
            ResourceDto::FIELD_RODZAJ_NIERUCHOMOSCI => 'Typ',
            ResourceDto::FIELD_POWIERZCHNIA_UZYTKOWA => 'Powierzchnia',
            ResourceDto::FIELD_STATUS => 'Status',
            PriceHistoryDto::FIELD_CENA_M2 => 'Cena za m²',
            PriceHistoryDto::FIELD_CENA_CALKOWITA => 'Cena lokalu',
            PriceHistoryDto::FIELD_CENA_Z_DODATKAMI => 'Cena pełna',
            ResourceDto::FIELD_FLOOR_NUMBER => 'Piętro',
            ResourceDto::FIELD_ROOM_COUNT => 'Liczba pokoi',
            ResourceDto::FIELD_ADDITIONAL_DESCRIPTION => 'Opis',
            ResourceDto::FIELD_GARDEN_AREA => 'Ogród',
            ResourceDto::FIELD_FLOOR_PLAN_PDF => 'Plan',
            ResourcesListShortcode::COLUMN_HISTORIA_CEN => 'Historia cen'
        ];
    }
    
    /**
     * Generate shortcode string based on current settings
     */
    private function generateShortcode(array $settings): string {
        $types_string = implode(',', array_map(fn($type) => $type->value, $settings['selected_types']));
        
        // Generate columns with names in format "field:name,field2:name2"
        $columns_with_names = [];
        foreach ($settings['visible_columns'] as $column) {
            $column_name = $settings['column_names'][$column] ?? ucfirst($column);
            $columns_with_names[] = "{$column}:{$column_name}";
        }
        $columns_string = implode(',', $columns_with_names);
        
        $shortcode = "[resources_list types=\"{$types_string}\"";
        
        if (!empty($columns_string)) {
            $shortcode .= " columns=\"{$columns_string}\"";
        }
        
        if ($settings['primary_color'] !== '#007cba') {
            $shortcode .= " color=\"{$settings['primary_color']}\"";
        }
        
        $shortcode .= "]";
        
        return $shortcode;
    }
    
    /**
     * Render JavaScript and CSS
     */
    private function render_scripts_and_styles() {
        ?>
        <style>
        /* 3-Column Grid Layout */
        .shortcode-generator-grid {
            display: grid;
            grid-template-columns: 1fr 1fr 1fr;
            gap: 30px;
            margin: 20px 0;
        }
        
        @media (max-width: 1200px) {
            .shortcode-generator-grid {
                grid-template-columns: 1fr 1fr;
            }
        }
        
        @media (max-width: 768px) {
            .shortcode-generator-grid {
                grid-template-columns: 1fr;
            }
        }
        
        .shortcode-generator-grid h4 {
            margin-top: 0;
            padding-bottom: 10px;
            border-bottom: 2px solid #0073aa;
            color: #0073aa;
        }
        
        .setting-group {
            margin-bottom: 25px;
        }
        
        .setting-group label {
            display: block;
            font-weight: 600;
            margin-bottom: 8px;
        }
        
        /* Property Types & Visible Columns Checkboxes */
        .property-types-checkboxes label,
        .visible-columns-checkboxes label {
            display: block;
            margin-bottom: 8px;
            font-weight: normal;
        }
        
        .property-types-checkboxes input,
        .visible-columns-checkboxes input {
            margin-right: 8px;
        }
        
        /* Dynamic Column Names */
        .dynamic-column-names {
            min-height: 200px;
        }
        
        .column-name-input {
            margin-bottom: 15px;
            padding: 10px;
            background: #f9f9f9;
            border-radius: 4px;
        }
        
        .column-name-input label {
            display: block;
            margin-bottom: 5px;
            font-size: 13px;
        }
        
        .column-name-input input {
            width: 100%;
        }
        
        /* Shortcode Preview */
        .shortcode-preview {
            margin-top: 30px;
            padding: 15px;
            background: #f8f9fa;
            border: 1px solid #ddd;
            border-radius: 4px;
        }
        
        .shortcode-display {
            display: flex;
            align-items: center;
            gap: 10px;
            margin-top: 10px;
        }
        
        .shortcode-display code {
            padding: 8px 12px;
            background: white;
            border: 1px solid #ddd;
            border-radius: 3px;
            font-family: Monaco, Consolas, monospace;
            flex-grow: 1;
            word-break: break-all;
        }
        
        /* General Styles */
        .submit-section {
            margin-top: 20px;
            padding: 20px 0;
            border-top: 1px solid #ddd;
        }
        
        .submit-section .button {
            margin-right: 10px;
        }
        
        .notice.inline {
            margin: 15px 0;
        }
        </style>
        
        <script>
        jQuery(document).ready(function($) {
            
            // Update shortcode preview when settings change
            function updateShortcodePreview() {
                const selectedTypes = $('input[name="selected_types[]"]:checked').map(function() {
                    return this.value;
                }).get();
                
                // Generate columns with names in format "field:name,field2:name2"
                const columnsWithNames = [];
                $('input[name="visible_columns[]"]:checked').each(function() {
                    const fieldName = this.value;
                    const customName = $('input[name="column_names[' + fieldName + ']"]').val();
                    if (customName) {
                        columnsWithNames.push(fieldName + ':' + customName);
                    }
                });
                
                const primaryColor = $('#primary-color').val();
                
                let shortcode = '[resources_list';
                
                if (selectedTypes.length > 0) {
                    shortcode += ' types="' + selectedTypes.join(',') + '"';
                }
                
                if (columnsWithNames.length > 0) {
                    shortcode += ' columns="' + columnsWithNames.join(',') + '"';
                }
                
                if (primaryColor && primaryColor !== '#007cba') {
                    shortcode += ' color="' + primaryColor + '"';
                }
                
                shortcode += ']';
                
                $('#generated-shortcode').text(shortcode);
            }
            
            // Toggle column name inputs based on visible columns selection
            function toggleColumnNameInputs() {
                $('input[name="visible_columns[]"]').each(function() {
                    const columnName = $(this).val();
                    const isChecked = $(this).is(':checked');
                    const columnInput = $('.column-name-input[data-column="' + columnName + '"]');
                    
                    if (isChecked) {
                        columnInput.show();
                    } else {
                        columnInput.hide();
                    }
                });
            }
            
            // Update preview and column inputs on changes
            $('input[name="selected_types[]"], input[name="visible_columns[]"], #primary-color').on('change', function() {
                updateShortcodePreview();
                toggleColumnNameInputs();
            });
            
            // Update shortcode when column names change
            $(document).on('input', 'input[name^="column_names["]', function() {
                updateShortcodePreview();
            });
            
            // Initialize on page load
            toggleColumnNameInputs();
            
            // Copy shortcode to clipboard
            $('#copy-shortcode').on('click', function() {
                const shortcode = $('#generated-shortcode').text();
                navigator.clipboard.writeText(shortcode).then(function() {
                    $(this).text('Skopiowano!').addClass('button-primary');
                    setTimeout(() => {
                        $(this).text('Kopiuj').removeClass('button-primary');
                    }, 2000);
                }.bind(this));
            });
            
            // Removed save functionality - shortcode is generated dynamically only
            
            // Reset settings
            $('#reset-settings').on('click', function() {
                if (!confirm('Czy na pewno chcesz przywrócić domyślne ustawienia? Ta operacja jest nieodwracalna.')) {
                    return;
                }
                
                const $resetBtn = $(this);
                const originalText = $resetBtn.text();
                $resetBtn.text('Resetowanie...').prop('disabled', true);
                
                $.post(ajaxurl, {
                    action: 'ujc_reset_frontend_settings',
                    nonce: $('[name="nonce"]').val()
                }, function(response) {
                    if (response.success) {
                        alert('✅ ' + response.data.message);
                        if (response.data.reload) {
                            location.reload();
                        }
                    } else {
                        alert('❌ ' + response.data);
                    }
                }).fail(function() {
                    alert('❌ Błąd połączenia');
                }).always(function() {
                    $resetBtn.text(originalText).prop('disabled', false);
                });
            });
        });
        </script>
        <?php
    }
}