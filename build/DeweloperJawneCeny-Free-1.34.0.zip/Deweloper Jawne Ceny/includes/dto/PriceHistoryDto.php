<?php

if (!defined('ABSPATH')) {
    exit;
}

class PriceHistoryDto extends ModelDto {
    
    public const FIELD_ID = 'id';
    public const FIELD_RESOURCE_ID = 'resource_id';
    public const FIELD_CENA_M2_OLD = 'cena_m2_old';
    public const FIELD_CENA_M2_NEW = 'cena_m2_new';
    public const FIELD_CENA_CALKOWITA_OLD = 'cena_calkowita_old';
    public const FIELD_CENA_CALKOWITA_NEW = 'cena_calkowita_new';
    public const FIELD_CENA_Z_DODATKAMI_OLD = 'cena_z_dodatkami_old';
    public const FIELD_CENA_Z_DODATKAMI_NEW = 'cena_z_dodatkami_new';
    public const FIELD_DATA_ZMIANY = 'data_zmiany';
    
    public readonly int $id;
    public readonly int $resource_id;
    public readonly float $cena_m2_old;
    public readonly float $cena_m2_new;
    public readonly float $cena_calkowita_old;
    public readonly float $cena_calkowita_new;
    public readonly float $cena_z_dodatkami_old;
    public readonly float $cena_z_dodatkami_new;
    public readonly DateTime $data_zmiany;
    
    public function __construct(
        int $id,
        int $resource_id,
        float $cena_m2_old,
        float $cena_m2_new,
        float $cena_calkowita_old,
        float $cena_calkowita_new,
        float $cena_z_dodatkami_old,
        float $cena_z_dodatkami_new,
        DateTime $data_zmiany
    ) {
        $this->id = $id;
        $this->resource_id = $resource_id;
        $this->cena_m2_old = $cena_m2_old;
        $this->cena_m2_new = $cena_m2_new;
        $this->cena_calkowita_old = $cena_calkowita_old;
        $this->cena_calkowita_new = $cena_calkowita_new;
        $this->cena_z_dodatkami_old = $cena_z_dodatkami_old;
        $this->cena_z_dodatkami_new = $cena_z_dodatkami_new;
        $this->data_zmiany = $data_zmiany;
    }
    
    public static function databaseToModel(array $data): static {
        return new static(
            (int)$data[self::FIELD_ID],
            (int)$data[self::FIELD_RESOURCE_ID],
            (float)$data[self::FIELD_CENA_M2_OLD],
            (float)$data[self::FIELD_CENA_M2_NEW],
            (float)$data[self::FIELD_CENA_CALKOWITA_OLD],
            (float)$data[self::FIELD_CENA_CALKOWITA_NEW],
            (float)$data[self::FIELD_CENA_Z_DODATKAMI_OLD],
            (float)$data[self::FIELD_CENA_Z_DODATKAMI_NEW],
            new DateTime($data[self::FIELD_DATA_ZMIANY])
        );
    }
    
    public function modelToDatabase(): array {
        return [
            self::FIELD_RESOURCE_ID => $this->resource_id,
            self::FIELD_CENA_M2_OLD => $this->cena_m2_old,
            self::FIELD_CENA_M2_NEW => $this->cena_m2_new,
            self::FIELD_CENA_CALKOWITA_OLD => $this->cena_calkowita_old,
            self::FIELD_CENA_CALKOWITA_NEW => $this->cena_calkowita_new,
            self::FIELD_CENA_Z_DODATKAMI_OLD => $this->cena_z_dodatkami_old,
            self::FIELD_CENA_Z_DODATKAMI_NEW => $this->cena_z_dodatkami_new,
            self::FIELD_DATA_ZMIANY => $this->data_zmiany
        ];
    }
}