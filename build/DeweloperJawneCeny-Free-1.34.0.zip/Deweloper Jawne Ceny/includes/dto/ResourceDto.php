<?php

if (!defined('ABSPATH')) {
    exit;
}

class ResourceDto extends ModelDto {
    
    public const FIELD_ID = 'id';
    public const FIELD_RODZAJ_NIERUCHOMOSCI = 'rodzaj_nieruchomosci';
    public const FIELD_NR_LOKALU = 'nr_lokalu';
    public const FIELD_POWIERZCHNIA_UZYTKOWA = 'powierzchnia_uzytkowa';
    public const FIELD_CENA_M2 = 'cena_m2';
    public const FIELD_DATA_CENA_M2 = 'data_cena_m2';
    public const FIELD_CENA_CALKOWITA = 'cena_calkowita';
    public const FIELD_DATA_CENA_CALKOWITA = 'data_cena_calkowita';
    public const FIELD_CENA_Z_DODATKAMI = 'cena_z_dodatkami';
    public const FIELD_DATA_CENA_Z_DODATKAMI = 'data_cena_z_dodatkami';
    public const FIELD_STATUS = 'status';
    
    public int $id;
    public string $rodzaj_nieruchomosci;
    public string $nr_lokalu;
    public float $powierzchnia_uzytkowa;
    public float $cena_m2;
    public DateTime $data_cena_m2;
    public float $cena_calkowita;
    public DateTime $data_cena_calkowita;
    public float $cena_z_dodatkami;
    public DateTime $data_cena_z_dodatkami;
    public string $status;
    
    public function __construct(
        int $id,
        string $rodzaj_nieruchomosci,
        string $nr_lokalu,
        float $powierzchnia_uzytkowa,
        float $cena_m2,
        DateTime $data_cena_m2,
        float $cena_calkowita,
        DateTime $data_cena_calkowita,
        float $cena_z_dodatkami,
        DateTime $data_cena_z_dodatkami,
        string $status
    ) {
        $this->id = $id;
        $this->rodzaj_nieruchomosci = $rodzaj_nieruchomosci;
        $this->nr_lokalu = $nr_lokalu;
        $this->powierzchnia_uzytkowa = $powierzchnia_uzytkowa;
        $this->cena_m2 = $cena_m2;
        $this->data_cena_m2 = $data_cena_m2;
        $this->cena_calkowita = $cena_calkowita;
        $this->data_cena_calkowita = $data_cena_calkowita;
        $this->cena_z_dodatkami = $cena_z_dodatkami;
        $this->data_cena_z_dodatkami = $data_cena_z_dodatkami;
        $this->status = $status;
    }
    
    public static function databaseToModel(array $data): static {
        return new static(
            (int)$data[self::FIELD_ID],
            $data[self::FIELD_RODZAJ_NIERUCHOMOSCI] ?? '',
            $data[self::FIELD_NR_LOKALU] ?? '',
            (float)($data[self::FIELD_POWIERZCHNIA_UZYTKOWA] ?? 0),
            (float)($data[self::FIELD_CENA_M2] ?? 0),
            new DateTime($data[self::FIELD_DATA_CENA_M2]),
            (float)($data[self::FIELD_CENA_CALKOWITA] ?? 0),
            new DateTime($data[self::FIELD_DATA_CENA_CALKOWITA]),
            (float)($data[self::FIELD_CENA_Z_DODATKAMI] ?? 0),
            new DateTime($data[self::FIELD_DATA_CENA_Z_DODATKAMI]),
            $data[self::FIELD_STATUS]
        );
    }
    
    public function modelToDatabase(): array {
        return [
            self::FIELD_RODZAJ_NIERUCHOMOSCI => $this->rodzaj_nieruchomosci,
            self::FIELD_NR_LOKALU => $this->nr_lokalu,
            self::FIELD_POWIERZCHNIA_UZYTKOWA => $this->powierzchnia_uzytkowa,
            self::FIELD_CENA_M2 => $this->cena_m2,
            self::FIELD_DATA_CENA_M2 => $this->data_cena_m2,
            self::FIELD_CENA_CALKOWITA => $this->cena_calkowita,
            self::FIELD_DATA_CENA_CALKOWITA => $this->data_cena_calkowita,
            self::FIELD_CENA_Z_DODATKAMI => $this->cena_z_dodatkami,
            self::FIELD_DATA_CENA_Z_DODATKAMI => $this->data_cena_z_dodatkami,
            self::FIELD_STATUS => $this->status
        ];
    }
}