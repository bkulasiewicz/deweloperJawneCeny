<?php

if (!defined('ABSPATH')) {
    exit;
}

class PriceHistory {
    
    public int $resource_id;
    public float $old_price;
    public float $new_price;
    public DateTime $change_date;
    
    public function __construct(
        int $resource_id,
        float $old_price,
        float $new_price,
        DateTime $change_date
    ) {
        $this->resource_id = $resource_id;
        $this->old_price = $old_price;
        $this->new_price = $new_price;
        $this->change_date = $change_date;
    }
}