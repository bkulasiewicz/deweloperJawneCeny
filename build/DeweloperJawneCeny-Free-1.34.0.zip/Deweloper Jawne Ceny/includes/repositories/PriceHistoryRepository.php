<?php

if (!defined('ABSPATH')) {
    exit;
}

class PriceHistoryRepository {
    
    /**
     * Get price history for resource
     */
    public function readByResourceId($resource_id): array {
        $table = TableNames::getPriceHistory();
        global $wpdb;
        
        $results = $wpdb->get_results($wpdb->prepare(
            "SELECT * FROM `{$table}` WHERE resource_id = %d ORDER BY data_zmiany DESC", 
            $resource_id
        ), ARRAY_A);
        
        $dtos = [];
        foreach($results as $row) {
            $dtos[] = PriceHistoryDto::databaseToModel($row);
        }
        
        return $dtos;
    }
    
    /**
     * Save price change history (extended logic)
     */
    public function save(PriceHistoryDto $dto) {
        $table = TableNames::getPriceHistory();
        global $wpdb;
        
        return $wpdb->insert($table, $dto->modelToDatabase());
    }
    
    /**
     * Get full price history for CSV export
     */
    public function readForExport() {
        $history_table = TableNames::getPriceHistory();
        $resources_table = TableNames::getResources();
        global $wpdb;
        
        return $wpdb->get_results($wpdb->prepare("
            SELECT DISTINCT
                r.nr_lokalu,
                r.rodzaj_nieruchomosci,
                r.powierzchnia_uzytkowa,
                COALESCE(latest_m2.cena_m2, r.cena_m2) as cena_m2,
                COALESCE(latest_m2.data_zmiany, r.data_cena_m2) as data_cena_m2,
                COALESCE(latest_calkowita.cena_calkowita, r.cena_calkowita) as cena_calkowita,
                COALESCE(latest_calkowita.data_zmiany, r.data_cena_calkowita) as data_cena_calkowita
            FROM `{$resources_table}` r
            LEFT JOIN (
                SELECT resource_id, cena_m2, data_zmiany,
                       ROW_NUMBER() OVER (PARTITION BY resource_id ORDER BY data_zmiany DESC) as rn
                FROM `{$history_table}` 
                WHERE cena_m2 IS NOT NULL
            ) latest_m2 ON r.id = latest_m2.resource_id AND latest_m2.rn = 1
            LEFT JOIN (
                SELECT resource_id, cena_calkowita, data_zmiany,
                       ROW_NUMBER() OVER (PARTITION BY resource_id ORDER BY data_zmiany DESC) as rn
                FROM `{$history_table}` 
                WHERE cena_calkowita IS NOT NULL
            ) latest_calkowita ON r.id = latest_calkowita.resource_id AND latest_calkowita.rn = 1
            ORDER BY r.nr_lokalu
        "), ARRAY_A);
    }
}