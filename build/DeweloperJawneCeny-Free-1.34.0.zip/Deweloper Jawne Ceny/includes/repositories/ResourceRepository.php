<?php

if (!defined('ABSPATH')) {
    exit;
}

class ResourceRepository {
    
    /**
     * Get all resources
     */
    public function readAll() {
        $table = TableNames::getResources();
        global $wpdb;
        
        $results = $wpdb->get_results($wpdb->prepare("SELECT r.* FROM `{$table}` r ORDER BY r.created_at ASC"), ARRAY_A);
        
        $dtos = [];
        foreach($results as $row) {
            $dtos[] = ResourceDto::databaseToModel($row);
        }
        
        return $dtos;
    }
    
    /**
     * Get resource by ID
     */
    public function readById($id) {
        $table = TableNames::getResources();
        global $wpdb;
        
        $data = $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM `{$table}` WHERE id = %d", 
            $id
        ), ARRAY_A);
        
        if (!$data) {
            return null;
        }
        
        return ResourceDto::databaseToModel($data);
    }
    
    /**
     * Save resource (create or update)
     */
    public function save(ResourceDto $dto, $id = null) {
        $table = TableNames::getResources();
        global $wpdb;
        
        $data = $dto->modelToDatabase();
        
        if ($id) {
            // Update existing
            $result = $wpdb->update($table, $data, ['id' => $id]);
            return $result !== false ? $id : false;
        } else {
            // Create new
            $result = $wpdb->insert($table, $data);
            return $result !== false ? $wpdb->insert_id : false;
        }
    }
    
    /**
     * Delete resource
     */
    public function delete($id) {
        $table = TableNames::getResources();
        global $wpdb;
        
        return $wpdb->delete($table, ['id' => $id]);
    }
}