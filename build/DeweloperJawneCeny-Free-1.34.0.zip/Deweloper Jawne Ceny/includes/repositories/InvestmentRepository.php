<?php

if (!defined('ABSPATH')) {
    exit;
}

class InvestmentRepository {
    
    /**
     * Get investment data as model
     */
    public function read(): ?InvestmentDto {
        $table = TableNames::getInvestmentInfo();        
        global $wpdb;
        $data = $wpdb->get_row($wpdb->prepare("SELECT * FROM `{$table}` LIMIT 1"), ARRAY_A);
        
        return $data ? InvestmentDto::databaseToModel($data) : null;
    }
    
    /**
     * Save investment data (create or update)
     */
    public function save(InvestmentDto $dto) {
        $table = TableNames::getInvestmentInfo();        
        global $wpdb;
        
        $data = $dto->modelToDatabase();
        
        // Check if record already exists
        $existing = $this->read();
        
        if ($existing) {
            // Update existing
            return $wpdb->update($table, $data, ['id' => $existing->id]);
        } else {
            // Create new
            return $wpdb->insert($table, $data);
        }
    }
}