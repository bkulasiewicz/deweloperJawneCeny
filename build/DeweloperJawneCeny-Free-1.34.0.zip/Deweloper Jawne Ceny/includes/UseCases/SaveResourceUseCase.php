<?php

if (!defined('ABSPATH')) {
    exit;
}

class SaveResourceUseCase {
    
    private $repository;
    private $price_history_repo;
    private $investment_repo;
    private $property_parts_repo;
    private $belonging_rooms_repo;
    private $usage_rights_repo;
    private $other_services_repo;
    
    public function __construct() {
        $this->repository = new ResourceRepository();
        $this->price_history_repo = new PriceHistoryRepository();
        $this->investment_repo = new InvestmentRepository();
        $this->property_parts_repo = new PropertyPartsRepository();
        $this->belonging_rooms_repo = new BelongingRoomsRepository();
        $this->usage_rights_repo = new UsageRightsRepository();
        $this->other_services_repo = new OtherServicesRepository();
    }
    
    public function execute($data, $resource_id = null, $propertyParts = null, $belongingRooms = null, $usageRights = null, $otherServices = null) {
        $validation_errors = $this->validate($data, $resource_id);
        if (!empty($validation_errors)) {
            return ['error' => implode(' ', $validation_errors)];
        }
        
        // Get investment configuration to check which components are enabled
        $investment = $this->investment_repo->read();
        
        $old_resource = null;
        if ($resource_id) {
            $old_resource = $this->repository->readById($resource_id);
            if (!$old_resource) {
                return false;
            }
            
            $result = $this->repository->save($data, $resource_id);
            $final_resource_id = $resource_id;
        } else {
            $result = $this->repository->save($data);
            $final_resource_id = $result;
        }
        
        if ($result !== false) {
            // Save component data based on investment configuration
            $this->saveComponentsIfEnabled($final_resource_id, $investment, $propertyParts, $belongingRooms, $usageRights, $otherServices);
            
            // Save price history (only for updates, not new resources)
            try {
                if ($old_resource) {
                    $new_resource = $this->createResourceFromData($data, $final_resource_id);
                    $price_history = $this->createPriceHistoryEntry($old_resource, $new_resource);
                    if ($price_history) {
                        $this->price_history_repo->save($price_history);
                    }
                }
            } catch (Exception $e) {
                Logger::error('UJC Resource: Price history error: ' . $e->getMessage());
            }
        }
        
        return $result;
    }
    
    private function validate($data, $exclude_id = null) {
        $errors = [];
        $table = TableNames::getResources();
        global $wpdb;
        
        if (!empty($data['nr_lokalu'])) {
            if ($exclude_id) {
                $existing = $wpdb->get_var($wpdb->prepare(
                    "SELECT COUNT(*) FROM `{$table}` WHERE nr_lokalu = %s AND id != %d",
                    $data['nr_lokalu'],
                    $exclude_id
                ));
            } else {
                $existing = $wpdb->get_var($wpdb->prepare(
                    "SELECT COUNT(*) FROM `{$table}` WHERE nr_lokalu = %s",
                    $data['nr_lokalu']
                ));
            }
            
            if ($existing > 0) {
                $errors[] = 'Numer lokalu "' . $data['nr_lokalu'] . '" już istnieje. Każdy zasób musi mieć unikalną nazwę.';
            }
        }
        
        return $errors;
    }
    
    private function saveComponentsIfEnabled($resource_id, $investment, $propertyParts, $belongingRooms, $usageRights, $otherServices) {
        if ($investment->hasPropertyParts() && $propertyParts) {
            $this->property_parts_repo->deleteByResourceId($resource_id);
            foreach ($propertyParts as $part) {
                $this->property_parts_repo->save($part, $resource_id);
            }
        }
        
        if ($investment->hasBelongingRooms() && $belongingRooms) {
            $this->belonging_rooms_repo->deleteByResourceId($resource_id);
            foreach ($belongingRooms as $room) {
                $this->belonging_rooms_repo->save($room, $resource_id);
            }
        }
        
        if ($investment->hasUsageRights() && $usageRights) {
            $this->usage_rights_repo->deleteByResourceId($resource_id);
            foreach ($usageRights as $right) {
                $this->usage_rights_repo->save($right, $resource_id);
            }
        }
        
        if ($investment->hasOtherServices() && $otherServices) {
            $this->other_services_repo->deleteByResourceId($resource_id);
            foreach ($otherServices as $service) {
                $this->other_services_repo->save($service, $resource_id);
            }
        }
    }
    
    private function createPriceHistoryEntry(Resource $old_resource, Resource $new_resource) {
        // Check if any price changed
        $cena_m2_changed = $old_resource->cena_m2 != $new_resource->cena_m2;
        $cena_calkowita_changed = $old_resource->cena_calkowita != $new_resource->cena_calkowita;
        $cena_z_dodatkami_changed = $old_resource->cena_z_dodatkami != $new_resource->cena_z_dodatkami;
        
        // Only create history entry if any price changed
        if ($cena_m2_changed || $cena_calkowita_changed || $cena_z_dodatkami_changed) {
            return new PriceHistoryDto(
                id: 0,
                resource_id: $new_resource->id,
                cena_m2_old: $old_resource->cena_m2,
                cena_m2_new: $new_resource->cena_m2,
                cena_calkowita_old: $old_resource->cena_calkowita,
                cena_calkowita_new: $new_resource->cena_calkowita,
                cena_z_dodatkami_old: $old_resource->cena_z_dodatkami,
                cena_z_dodatkami_new: $new_resource->cena_z_dodatkami,
                data_zmiany: new DateTime(DateHelper::currentDatetime())
            );
        }
        
        return null;
    }
    
    private function createResourceFromData($data, $resource_id) {
        return new Resource(
            id: $resource_id,
            rodzaj_nieruchomosci: $data['rodzaj_nieruchomosci'],
            nr_lokalu: $data['nr_lokalu'],
            powierzchnia_uzytkowa: (float)$data['powierzchnia_uzytkowa'],
            cena_m2: (float)$data['cena_m2'],
            data_cena_m2: new DateTime($data['data_cena_m2']),
            cena_calkowita: (float)($data['cena_calkowita'] ?? 0),
            data_cena_calkowita: new DateTime($data['data_cena_calkowita'] ?? DateHelper::currentDatetime()),
            cena_z_dodatkami: (float)($data['cena_z_dodatkami'] ?? 0),
            data_cena_z_dodatkami: new DateTime($data['data_cena_z_dodatkami'] ?? DateHelper::currentDatetime()),
            status: $data['status'] ?? 'dostepny'
        );
    }
}