<?php

if (!defined('ABSPATH')) {
    exit;
}

/**
 * Repository for managing publication history records
 */
class PublicationHistoryRepository {
    
    private $table_name;
    
    public function __construct() {
        $this->table_name = TableNames::getPublicationHistory();
    }
    
    /**
     * Check if publication history table exists and create it if missing
     * 
     * @return bool True if table exists or was created successfully
     */
    private function ensureTableExists() {
        global $wpdb;
        $result = $wpdb->get_var($wpdb->prepare("SHOW TABLES LIKE %s", $this->table_name));
        
        if ($result == $this->table_name) {
            return true;
        }
        
        // Table doesn't exist, try to create it
        Logger::error("PublicationHistory: Table '{$this->table_name}' does not exist, attempting to create it...");
        
        if (class_exists('UJC_Schema_Manager')) {
            try {
                $charset_collate = $wpdb->get_charset_collate();
                $wpdb->query($wpdb->prepare("CREATE TABLE `{$this->table_name}` (
                    id int(11) NOT NULL AUTO_INCREMENT,
                    timestamp int(11) NOT NULL,
                    status varchar(20) NOT NULL,
                    message text,
                    trigger_type varchar(20) NOT NULL,
                    
                    PRIMARY KEY (id),
                    KEY timestamp (timestamp),
                    KEY status (status)
                ) %s", $charset_collate));
                
                // Check if creation was successful
                $result = $wpdb->get_var($wpdb->prepare("SHOW TABLES LIKE %s", $this->table_name));
                if ($result == $this->table_name) {
                    Logger::success("PublicationHistory: Table '{$this->table_name}' created successfully");
                    return true;
                } else {
                    Logger::error("PublicationHistory: Failed to create table '{$this->table_name}' - Error: " . $wpdb->last_error);
                    return false;
                }
            } catch (Exception $e) {
                Logger::error("PublicationHistory: Exception during table creation: " . $e->getMessage());
                return false;
            }
        }
        
        Logger::error("PublicationHistory: Cannot create table - UJC_Schema_Manager not available");
        return false;
    }
    
    /**
     * Add new entry to publication history
     * 
     * @param string $status 'success' or 'error'
     * @param string $message Detailed message or error description
     * @param string $trigger_type 'manual' or 'external_cron'
     * @return bool Success status
     */
    public function addEntry($status, $message, $trigger_type) {
        global $wpdb;
        
        // Ensure table exists, create if missing
        if (!$this->ensureTableExists()) {
            Logger::error("PublicationHistory: Cannot access or create table '{$this->table_name}'!");
            return false;
        }
        
        Logger::info("PublicationHistory: Inserting entry - Status: {$status}, Trigger: {$trigger_type}, Table: {$this->table_name}");
        
        $result = $wpdb->insert(
            $this->table_name,
            [
                'timestamp' => time(),
                'status' => $status,
                'message' => $message,
                'trigger_type' => $trigger_type
            ],
            ['%d', '%s', '%s', '%s']
        );
        
        if ($result === false) {
            Logger::error("PublicationHistory: INSERT FAILED - Error: " . $wpdb->last_error);
            Logger::error("PublicationHistory: Last query: " . $wpdb->last_query);
            return false;
        }
        
        Logger::success("PublicationHistory: INSERT SUCCESS - Inserted ID: " . $wpdb->insert_id);
        return true;
    }
    
    /**
     * Get publication history with limit
     * 
     * @param int $limit Number of records to retrieve
     * @return array Array of history entries
     */
    public function getHistory($limit = 50) {
        global $wpdb;
        
        // Ensure table exists, create if missing
        if (!$this->ensureTableExists()) {
            Logger::error("PublicationHistory: Cannot access or create table '{$this->table_name}' for getHistory()!");
            return [];
        }
        
        Logger::info("PublicationHistory: Getting history from table: {$this->table_name}, limit: {$limit}");
        
        $results = $wpdb->get_results($wpdb->prepare(
            "SELECT * FROM `{$this->table_name}` 
             ORDER BY timestamp DESC 
             LIMIT %d",
            $limit
        ), ARRAY_A);
        
        if ($results === null) {
            Logger::error("PublicationHistory: SELECT FAILED - Error: " . $wpdb->last_error);
            Logger::error("PublicationHistory: Last query: " . $wpdb->last_query);
            return [];
        }
        
        $count = is_array($results) ? count($results) : 0;
        Logger::success("PublicationHistory: SELECT SUCCESS - Found {$count} entries");
        
        return $results ?: [];
    }
    
    /**
     * Clear all history entries
     * 
     * @return bool Success status
     */
    public function clearHistory() {
        global $wpdb;
        
        $result = $wpdb->query("TRUNCATE TABLE {$this->table_name}");
        
        return $result !== false;
    }
    
    /**
     * Get last entry from history
     * 
     * @return array|null Last history entry or null if empty
     */
    public function getLastEntry() {
        global $wpdb;
        
        return $wpdb->get_row($wpdb->prepare("SELECT * FROM `{$this->table_name}` 
                  ORDER BY timestamp DESC 
                  LIMIT %d", 1), ARRAY_A);
    }
    
    /**
     * Count history entries by status
     * 
     * @param string|null $status Filter by status (optional)
     * @return int Number of entries
     */
    public function countEntries($status = null) {
        global $wpdb;
        
        if ($status) {
            return (int) $wpdb->get_var($wpdb->prepare(
                "SELECT COUNT(*) FROM `{$this->table_name}` WHERE status = %s",
                $status
            ));
        } else {
            return (int) $wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM `{$this->table_name}`"));
        }
    }
}