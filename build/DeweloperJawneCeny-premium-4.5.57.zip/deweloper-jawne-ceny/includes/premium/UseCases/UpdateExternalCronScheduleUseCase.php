<?php

namespace JawneCeny;

if (!defined('ABSPATH')) {
    exit;
}

/**
 * Update External Cron Schedule UseCase
 * Handles updating the schedule frequency for external cron via cron-job.org API
 */
class UpdateExternalCronScheduleUseCase {
    
    private $repository;
    
    public function __construct(ExternalCronRepository $repository) {
        $this->repository = $repository;
    }
    
    /**
     * Execute schedule update
     * 
     * @param string $schedule The schedule key (e.g., '1min', '15min', '1hour', '24hour')
     * @return array ['success' => bool, 'message' => string, 'data' => array|null]
     */
    public function execute($schedule) {
        try {
            // Validate schedule parameter
            $schedule = sanitize_text_field($schedule);
            
            if (empty($schedule)) {
                return [
                    'success' => false,
                    'message' => 'Nie podano harmonogramu'
                ];
            }
            
            // Validate prerequisites
            $validation_result = $this->validatePrerequisites($schedule);
            if (!$validation_result['success']) {
                return $validation_result;
            }
            
            // Get job ID
            $job_id = get_option('jawneceny_cronjoborg_job_id');

            // Get available schedules from repository
            $available_schedules = $this->repository->getAvailableSchedules();

            // Update schedule via repository
            $schedule_config = $available_schedules[$schedule];
            $result = $this->repository->updateJobSchedule($job_id, $schedule_config);

            if ($result['success']) {
                // Save locally for reference
                update_option('jawneceny_external_cron_schedule', $schedule);
                
                return [
                    'success' => true,
                    'message' => 'Harmonogram zaktualizowany: ' . $available_schedules[$schedule]['interval_text'],
                    'data' => [
                        'schedule' => $schedule,
                        'job_id' => $job_id,
                        'interval_text' => $available_schedules[$schedule]['interval_text']
                    ]
                ];
            } else {
                return [
                    'success' => false,
                    'message' => 'Błąd podczas aktualizacji harmonogramu: ' . $result['message']
                ];
            }
            
        } catch (Exception $e) {
            Logger::error('UJC UpdateExternalCronScheduleUseCase Error: ' . $e->getMessage());
            return [
                'success' => false,
                'message' => 'Błąd serwera: ' . $e->getMessage()
            ];
        }
    }
    
    /**
     * Validate prerequisites before updating schedule
     * 
     * @param string $schedule
     * @return array ['success' => bool, 'message' => string]
     */
    private function validatePrerequisites($schedule) {
        $errors = [];
        
        // Check if external cron is enabled
        if (!ExternalCronController::is_external_cron_enabled()) {
            $errors[] = 'External Cron nie jest aktywny';
        }
        
        // Check if job ID exists
        $job_id = get_option('jawneceny_cronjoborg_job_id');
        if (!$job_id) {
            $errors[] = 'Brak zarejestrowanego job ID w cron-job.org';
        }
        
        // Check if schedule is valid
        $available_schedules = $this->repository->getAvailableSchedules();
        if (!array_key_exists($schedule, $available_schedules)) {
            $errors[] = 'Nieprawidłowy harmonogram: ' . $schedule;
        }
        
        if (!empty($errors)) {
            return [
                'success' => false,
                'message' => '❌ Nie można zaktualizować harmonogramu:<br>• ' . implode('<br>• ', $errors)
            ];
        }
        
        return ['success' => true];
    }
    
    
    /**
     * Get current schedule status for UI
     * 
     * @return array Current schedule information
     */
    public function getCurrentSchedule() {
        $current_schedule = get_option('jawneceny_external_cron_schedule', '24hour');
        $available_schedules = $this->repository->getAvailableSchedules();

        return [
            'current' => $current_schedule,
            'available' => $available_schedules,
            'current_text' => $available_schedules[$current_schedule]['interval_text'] ?? 'Nieznany',
            'job_id' => get_option('jawneceny_cronjoborg_job_id'),
            'enabled' => ExternalCronController::is_external_cron_enabled()
        ];
    }
}