<?php
/**
 * Premium Features Loader
 *
 * This file loads all premium-only features.
 * It is conditionally loaded only when the premium folder exists.
 */

if (!defined('ABSPATH')) {
    exit;
}

// Premium Use Cases - Publication History
require_once JAWNECENY_PLUGIN_DIR . 'includes/premium/UseCases/PublicationHistory/GetPublicationHistoryUseCase.php';
