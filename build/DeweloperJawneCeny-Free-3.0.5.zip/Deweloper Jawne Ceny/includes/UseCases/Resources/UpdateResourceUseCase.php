<?php

if (!defined('ABSPATH')) {
    exit;
}

class UpdateResourceUseCase {
    
    private $repository;
    private $price_history_repo;
    
    public function __construct() {
        $this->repository = new ResourceRepository();
        $this->price_history_repo = new PriceHistoryRepository();
    }
    
    public function execute(ResourceFormData $formData, int $resource_id): Result {
        Logger::info("UpdateResourceUseCase::execute - Starting for resource ID: {$resource_id}, nr_lokalu: {$formData->nr_lokalu}");
        
        if (!$this->validate($formData, $resource_id)) {
            Logger::info("UpdateResourceUseCase::execute - Validation failed - nr_lokalu '{$formData->nr_lokalu}' already exists");
            return Result::failure('Numer lokalu "' . $formData->nr_lokalu . '" już istnieje. Każdy zasób musi mieć unikalną nazwę.');
        }
        Logger::info("UpdateResourceUseCase::execute - Validation passed");
        
        try {
            // Create resource DTO
            Logger::info("UpdateResourceUseCase::execute - Creating ResourceDto from FormData");
            $resourceDto = $this->createResourceDto($formData);
            
            // Update component dates if prices changed
            Logger::info("UpdateResourceUseCase::execute - Updating component dates if prices changed");
            $this->updateComponentDatesIfPricesChanged($resourceDto, $resource_id);
            
            Logger::info("UpdateResourceUseCase::execute - Updating resource in repository");
            $this->repository->update($resourceDto, $resource_id);
            
            // Zapisz historię cen jeśli się zmieniły
            Logger::info("UpdateResourceUseCase::execute - Checking and saving price history changes");
            $this->savePriceHistoryIfChanged($formData, $resource_id);
            
            Logger::info("UpdateResourceUseCase::execute - Successfully completed for resource ID: {$resource_id}");
            return Result::success('Zasób został zaktualizowany pomyślnie');
            
        } catch (Exception $e) {
            Logger::error("UpdateResourceUseCase::execute - Exception: " . $e->getMessage());
            Logger::error("UpdateResourceUseCase::execute - Exception trace: " . $e->getTraceAsString());
            return Result::failure('Błąd podczas aktualizacji zasobu: ' . $e->getMessage());
        }
    }
    
    private function validate(ResourceFormData $formData, int $exclude_id): bool {
        $all_resources = $this->repository->readAll();
        
        foreach ($all_resources as $resource) {
            if ($resource->id == $exclude_id) {
                continue;
            }
            
            if ($resource->nr_lokalu === $formData->nr_lokalu) {
                return false;
            }
        }
        
        return true;
    }
    
    
    private function createResourceDto(ResourceFormData $formData): ResourceDto {
        return ResourceDto::fromFormData($formData);
    }
    
    private function updateComponentDatesIfPricesChanged(ResourceDto $newDto, int $resource_id): void {
        // Get existing resource to compare component prices
        $existingResource = $this->repository->readById($resource_id);
        if (!$existingResource) {
            return;
        }
        
        $currentDate = DateHelper::currentDatetime();
        
        // Check property part price changes
        if ($newDto->property_part_price !== null && 
            $newDto->property_part_price != $existingResource->property_part_price) {
            $newDto->property_part_price_date = $currentDate;
        } elseif ($newDto->property_part_price !== null && $existingResource->property_part_price_date) {
            $newDto->property_part_price_date = $existingResource->property_part_price_date;
        }
        
        // Check belonging room price changes
        if ($newDto->belonging_room_price !== null && 
            $newDto->belonging_room_price != $existingResource->belonging_room_price) {
            $newDto->belonging_room_price_date = $currentDate;
        } elseif ($newDto->belonging_room_price !== null && $existingResource->belonging_room_price_date) {
            $newDto->belonging_room_price_date = $existingResource->belonging_room_price_date;
        }
        
        // Check usage right price changes
        if ($newDto->usage_right_price !== null && 
            $newDto->usage_right_price != $existingResource->usage_right_price) {
            $newDto->usage_right_price_date = $currentDate;
        } elseif ($newDto->usage_right_price !== null && $existingResource->usage_right_price_date) {
            $newDto->usage_right_price_date = $existingResource->usage_right_price_date;
        }
        
        // Check other service price changes
        if ($newDto->other_service_price !== null && 
            $newDto->other_service_price != $existingResource->other_service_price) {
            $newDto->other_service_price_date = $currentDate;
        } elseif ($newDto->other_service_price !== null && $existingResource->other_service_price_date) {
            $newDto->other_service_price_date = $existingResource->other_service_price_date;
        }
    }
    
    private function savePriceHistoryIfChanged(ResourceFormData $formData, int $resource_id) {
        // Get current prices from PriceHistory
        $currentPrices = $this->price_history_repo->getCurrentPricesForResource($resource_id);
        
        // Check what changed
        $cena_m2_changed = $currentPrices->cena_m2 != $formData->cena_m2;
        $cena_calkowita_changed = $currentPrices->cena_calkowita != $formData->cena_calkowita;
        $cena_z_dodatkami_changed = $currentPrices->cena_z_dodatkami != $formData->cena_z_dodatkami;
        
        if ($cena_m2_changed || $cena_calkowita_changed || $cena_z_dodatkami_changed) {
            $currentDatetime = DateHelper::currentDatetime();
            
            // Determine dates based on what changed
            $data_zmiany = $cena_m2_changed || $cena_calkowita_changed 
                ? $currentDatetime
                : $currentPrices->data_zmiany;
                
            $data_cena_z_dodatkami = $cena_z_dodatkami_changed 
                ? $currentDatetime
                : $currentPrices->data_cena_z_dodatkami;
            
            $priceHistoryDto = new PriceHistoryDto(
                id: 0,
                resource_id: $resource_id,
                cena_m2: $formData->cena_m2,
                cena_calkowita: $formData->cena_calkowita,
                data_zmiany: $data_zmiany,
                cena_z_dodatkami: $formData->cena_z_dodatkami,
                data_cena_z_dodatkami: $data_cena_z_dodatkami
            );
            
            $this->price_history_repo->save($priceHistoryDto);
        }
    }
}