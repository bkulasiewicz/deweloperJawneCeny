<?php

if (!defined('ABSPATH')) {
    exit;
}

/**
 * Model representing other services data as entered by user in presentation layer
 * Used for "Inne świadczenia pieniężne na rzecz dewelopera"
 */
class OtherServiceFormData {
    
    public readonly string $description;
    public readonly float $price;
    
    public function __construct(
        string $description,
        float $price
    ) {
        $this->description = $description;
        $this->price = $price;
    }
}