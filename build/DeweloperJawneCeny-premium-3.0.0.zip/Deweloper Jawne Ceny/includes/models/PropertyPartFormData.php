<?php

if (!defined('ABSPATH')) {
    exit;
}

/**
 * Model representing property part data as entered by user in presentation layer
 * Used for "Część nieruchomości będąca przedmiotem umowy"
 */
class PropertyPartFormData {
    
    public readonly string $type;
    public readonly string $designation;
    public readonly float $price;
    
    public function __construct(
        string $type,
        string $designation,
        float $price
    ) {
        $this->type = $type;
        $this->designation = $designation;
        $this->price = $price;
    }
}