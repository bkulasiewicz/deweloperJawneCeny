<?php

if (!defined('ABSPATH')) {
    exit;
}

/**
 * Model representing usage rights data as entered by user in presentation layer
 * Used for "Prawa niezbędne do korzystania z lokalu lub domu"
 */
class UsageRightFormData {
    
    public readonly string $description;
    public readonly float $price;
    
    public function __construct(
        string $description,
        float $price
    ) {
        $this->description = $description;
        $this->price = $price;
    }
}