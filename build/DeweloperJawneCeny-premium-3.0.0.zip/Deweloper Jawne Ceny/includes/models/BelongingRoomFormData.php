<?php

if (!defined('ABSPATH')) {
    exit;
}

/**
 * Model representing belonging room data as entered by user in presentation layer
 * Used for "Pomieszczenie przynależne"
 */
class BelongingRoomFormData {
    
    public readonly string $type;
    public readonly string $designation;
    public readonly float $price;
    
    public function __construct(
        string $type,
        string $designation,
        float $price
    ) {
        $this->type = $type;
        $this->designation = $designation;
        $this->price = $price;
    }
}