<?php

if (!defined('ABSPATH')) {
    exit;
}

class CreateResourceUseCase {
    
    private $repository;
    private $price_history_repo;
    private $property_parts_repo;
    private $belonging_rooms_repo;
    private $usage_rights_repo;
    private $other_services_repo;
    
    public function __construct() {
        $this->repository = new ResourceRepository();
        $this->price_history_repo = new PriceHistoryRepository();
        $this->property_parts_repo = new PropertyPartsRepository();
        $this->belonging_rooms_repo = new BelongingRoomsRepository();
        $this->usage_rights_repo = new UsageRightsRepository();
        $this->other_services_repo = new OtherServicesRepository();
    }
    
    public function execute(
        ResourceFormData $formData, 
        ?PropertyPartFormData $propertyPart = null, 
        ?BelongingRoomFormData $belongingRoom = null, 
        ?UsageRightFormData $usageRight = null, 
        ?OtherServiceFormData $otherService = null
    ): Result {
        Logger::info("CreateResourceUseCase::execute - Starting for nr_lokalu: " . $formData->nr_lokalu);
        
        if (!$this->validate($formData)) {
            Logger::info("CreateResourceUseCase::execute - Validation failed for nr_lokalu: " . $formData->nr_lokalu);
            return Result::failure('Numer lokalu "' . $formData->nr_lokalu . '" już istnieje. Każdy zasób musi mieć unikalną nazwę.');
        }
        
        try {
            Logger::info("CreateResourceUseCase::execute - Creating resource DTO");
            // Create resource without prices
            $resourceDto = $this->createResourceDto($formData);
            
            Logger::info("CreateResourceUseCase::execute - Calling repository->create()");
            $resource_id = $this->repository->create($resourceDto);
            Logger::info("CreateResourceUseCase::execute - Resource created with ID: " . $resource_id);
            
            // Create initial price history entry
            Logger::info("CreateResourceUseCase::execute - Creating initial price history");
            $priceHistoryDto = $this->createInitialPriceHistory($formData, $resource_id);
            $this->price_history_repo->save($priceHistoryDto);
            Logger::info("CreateResourceUseCase::execute - Price history saved");
            
            // Zapisz komponenty jeśli zostały przekazane
            Logger::info("CreateResourceUseCase::execute - Saving components");
            $this->saveComponents($resource_id, $propertyPart, $belongingRoom, $usageRight, $otherService);
            
            Logger::info("CreateResourceUseCase::execute - Resource creation completed successfully for ID: " . $resource_id);
            return Result::success('Zasób został utworzony pomyślnie');
            
        } catch (Exception $e) {
            Logger::error("CreateResourceUseCase::execute - Exception: " . $e->getMessage());
            return Result::failure('Błąd podczas tworzenia zasobu: ' . $e->getMessage());
        }
    }
    
    private function validate(ResourceFormData $formData): bool {
        $all_resources = $this->repository->readAll();
        
        foreach ($all_resources as $resource) {
            if ($resource->nr_lokalu === $formData->nr_lokalu) {
                return false;
            }
        }
        
        return true;
    }
    
    private function createResourceDto(ResourceFormData $formData): ResourceDto {
        return ResourceDto::fromFormData($formData);
    }
    
    private function createInitialPriceHistory(ResourceFormData $formData, int $resource_id): PriceHistoryDto {
        $currentDatetime = DateHelper::currentDatetime();
        
        return new PriceHistoryDto(
            id: 0,
            resource_id: $resource_id,
            cena_m2: $formData->cena_m2,
            cena_calkowita: $formData->cena_calkowita,
            data_zmiany: $currentDatetime,
            cena_z_dodatkami: $formData->cena_z_dodatkami,
            data_cena_z_dodatkami: $currentDatetime
        );
    }
    
    private function saveComponents(
        int $resource_id, 
        ?PropertyPartFormData $propertyPart, 
        ?BelongingRoomFormData $belongingRoom, 
        ?UsageRightFormData $usageRight, 
        ?OtherServiceFormData $otherService
    ): void {
        if ($propertyPart) {
            $dto = new PropertyPartDto(
                id: 0,
                resource_id: $resource_id,
                type: $propertyPart->type,
                designation: $propertyPart->designation,
                price: $propertyPart->price,
                price_date: DateHelper::currentDatetime()
            );
            $this->property_parts_repo->save($dto, $resource_id);
        }
        
        if ($belongingRoom) {
            $dto = new BelongingRoomDto(
                id: 0,
                resource_id: $resource_id,
                type: $belongingRoom->type,
                designation: $belongingRoom->designation,
                price: $belongingRoom->price,
                price_date: DateHelper::currentDatetime()
            );
            $this->belonging_rooms_repo->save($dto, $resource_id);
        }
        
        if ($usageRight) {
            $dto = new UsageRightDto(
                id: 0,
                resource_id: $resource_id,
                description: $usageRight->description,
                price: $usageRight->price,
                price_date: DateHelper::currentDatetime()
            );
            $this->usage_rights_repo->save($dto, $resource_id);
        }
        
        if ($otherService) {
            $dto = new OtherServiceDto(
                id: 0,
                resource_id: $resource_id,
                description: $otherService->description,
                price: $otherService->price,
                price_date: DateHelper::currentDatetime()
            );
            $this->other_services_repo->save($dto, $resource_id);
        }
    }
}