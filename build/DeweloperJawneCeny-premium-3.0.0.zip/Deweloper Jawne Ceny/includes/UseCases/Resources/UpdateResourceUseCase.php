<?php

if (!defined('ABSPATH')) {
    exit;
}

class UpdateResourceUseCase {
    
    private $repository;
    private $price_history_repo;
    private $property_parts_repo;
    private $belonging_rooms_repo;
    private $usage_rights_repo;
    private $other_services_repo;
    
    public function __construct() {
        $this->repository = new ResourceRepository();
        $this->price_history_repo = new PriceHistoryRepository();
        $this->property_parts_repo = new PropertyPartsRepository();
        $this->belonging_rooms_repo = new BelongingRoomsRepository();
        $this->usage_rights_repo = new UsageRightsRepository();
        $this->other_services_repo = new OtherServicesRepository();
    }
    
    public function execute(
        ResourceFormData $formData, 
        int $resource_id, 
        ?PropertyPartFormData $propertyPart = null, 
        ?BelongingRoomFormData $belongingRoom = null, 
        ?UsageRightFormData $usageRight = null, 
        ?OtherServiceFormData $otherService = null
    ): Result {
        Logger::info("UpdateResourceUseCase::execute - Starting for resource ID: {$resource_id}, nr_lokalu: {$formData->nr_lokalu}");
        
        if (!$this->validate($formData, $resource_id)) {
            Logger::info("UpdateResourceUseCase::execute - Validation failed - nr_lokalu '{$formData->nr_lokalu}' already exists");
            return Result::failure('Numer lokalu "' . $formData->nr_lokalu . '" już istnieje. Każdy zasób musi mieć unikalną nazwę.');
        }
        Logger::info("UpdateResourceUseCase::execute - Validation passed");
        
        try {
            // Create resource DTO without prices
            Logger::info("UpdateResourceUseCase::execute - Creating ResourceDto from FormData");
            $resourceDto = $this->createResourceDto($formData);
            
            Logger::info("UpdateResourceUseCase::execute - Updating resource in repository");
            $this->repository->update($resourceDto, $resource_id);
            
            // Zapisz komponenty jeśli zostały przekazane
            Logger::info("UpdateResourceUseCase::execute - Updating components");
            $this->updateComponents($resource_id, $propertyPart, $belongingRoom, $usageRight, $otherService);
            
            // Zapisz historię cen jeśli się zmieniły
            Logger::info("UpdateResourceUseCase::execute - Checking and saving price history changes");
            $this->savePriceHistoryIfChanged($formData, $resource_id);
            
            Logger::info("UpdateResourceUseCase::execute - Successfully completed for resource ID: {$resource_id}");
            return Result::success('Zasób został zaktualizowany pomyślnie');
            
        } catch (Exception $e) {
            Logger::error("UpdateResourceUseCase::execute - Exception: " . $e->getMessage());
            Logger::error("UpdateResourceUseCase::execute - Exception trace: " . $e->getTraceAsString());
            return Result::failure('Błąd podczas aktualizacji zasobu: ' . $e->getMessage());
        }
    }
    
    private function validate(ResourceFormData $formData, int $exclude_id): bool {
        $all_resources = $this->repository->readAll();
        
        foreach ($all_resources as $resource) {
            if ($resource->id == $exclude_id) {
                continue;
            }
            
            if ($resource->nr_lokalu === $formData->nr_lokalu) {
                return false;
            }
        }
        
        return true;
    }
    
    private function updateComponents(
        int $resource_id, 
        ?PropertyPartFormData $propertyPart, 
        ?BelongingRoomFormData $belongingRoom, 
        ?UsageRightFormData $usageRight, 
        ?OtherServiceFormData $otherService
    ): void {
        // Always clear existing components first
        $this->property_parts_repo->deleteByResourceId($resource_id);
        $this->belonging_rooms_repo->deleteByResourceId($resource_id);
        $this->usage_rights_repo->deleteByResourceId($resource_id);
        $this->other_services_repo->deleteByResourceId($resource_id);
        
        // Add new components if provided
        if ($propertyPart) {
            $dto = new PropertyPartDto(
                id: 0,
                resource_id: $resource_id,
                type: $propertyPart->type,
                designation: $propertyPart->designation,
                price: $propertyPart->price,
                price_date: DateHelper::currentDatetime()
            );
            $this->property_parts_repo->save($dto, $resource_id);
        }
        
        if ($belongingRoom) {
            $dto = new BelongingRoomDto(
                id: 0,
                resource_id: $resource_id,
                type: $belongingRoom->type,
                designation: $belongingRoom->designation,
                price: $belongingRoom->price,
                price_date: DateHelper::currentDatetime()
            );
            $this->belonging_rooms_repo->save($dto, $resource_id);
        }
        
        if ($usageRight) {
            $dto = new UsageRightDto(
                id: 0,
                resource_id: $resource_id,
                description: $usageRight->description,
                price: $usageRight->price,
                price_date: DateHelper::currentDatetime()
            );
            $this->usage_rights_repo->save($dto, $resource_id);
        }
        
        if ($otherService) {
            $dto = new OtherServiceDto(
                id: 0,
                resource_id: $resource_id,
                description: $otherService->description,
                price: $otherService->price,
                price_date: DateHelper::currentDatetime()
            );
            $this->other_services_repo->save($dto, $resource_id);
        }
    }
    
    private function createResourceDto(ResourceFormData $formData): ResourceDto {
        return ResourceDto::fromFormData($formData);
    }
    
    private function savePriceHistoryIfChanged(ResourceFormData $formData, int $resource_id) {
        // Get current prices from PriceHistory
        $currentPrices = $this->price_history_repo->getCurrentPricesForResource($resource_id);
        
        // Check what changed
        $cena_m2_changed = $currentPrices->cena_m2 != $formData->cena_m2;
        $cena_calkowita_changed = $currentPrices->cena_calkowita != $formData->cena_calkowita;
        $cena_z_dodatkami_changed = $currentPrices->cena_z_dodatkami != $formData->cena_z_dodatkami;
        
        if ($cena_m2_changed || $cena_calkowita_changed || $cena_z_dodatkami_changed) {
            $currentDatetime = DateHelper::currentDatetime();
            
            // Determine dates based on what changed
            $data_zmiany = $cena_m2_changed || $cena_calkowita_changed 
                ? $currentDatetime
                : $currentPrices->data_zmiany;
                
            $data_cena_z_dodatkami = $cena_z_dodatkami_changed 
                ? $currentDatetime
                : $currentPrices->data_cena_z_dodatkami;
            
            $priceHistoryDto = new PriceHistoryDto(
                id: 0,
                resource_id: $resource_id,
                cena_m2: $formData->cena_m2,
                cena_calkowita: $formData->cena_calkowita,
                data_zmiany: $data_zmiany,
                cena_z_dodatkami: $formData->cena_z_dodatkami,
                data_cena_z_dodatkami: $data_cena_z_dodatkami
            );
            
            $this->price_history_repo->save($priceHistoryDto);
        }
    }
}