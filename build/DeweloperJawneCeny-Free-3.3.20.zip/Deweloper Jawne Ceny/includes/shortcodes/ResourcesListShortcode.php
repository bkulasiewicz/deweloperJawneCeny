<?php

if (!defined('ABSPATH')) {
    exit;
}

/**
 * Resources List Shortcode Handler
 * Handles the [resources_list] shortcode with filtering and customization options
 */
class ResourcesListShortcode {
    
    /**
     * Handle resources_list shortcode with type-safe parsing
     * All configuration comes from shortcode parameters with sensible defaults
     */
    public static function handle($atts) {
        // Default columns
        $default_columns = implode(',', [
            ResourceDto::FIELD_NR_LOKALU,
            ResourceDto::FIELD_RODZAJ_NIERUCHOMOSCI,
            ResourceDto::FIELD_POWIERZCHNIA_UZYTKOWA,
            'cena_calkowita',
            ResourceDto::FIELD_STATUS,
            'historia_cen'
        ]);
        
        // Default types - residential units only
        $default_types = PropertyType::RESIDENTIAL_UNIT->value;
        
        $atts = shortcode_atts([
            'types' => $default_types,
            'columns' => $default_columns,
            'color' => '#007cba',
        ], $atts);
        
        try {
            // Parse property types
            $type_strings = array_map('trim', explode(',', $atts['types']));
            $selected_types = [];
            
            foreach ($type_strings as $type_string) {
                try {
                    $selected_types[] = PropertyType::from($type_string);
                } catch (ValueError $e) {
                    Logger::error("Invalid PropertyType in shortcode: {$type_string}");
                    // Skip invalid types, don't fail completely
                }
            }
            
            // If no valid types, use default
            if (empty($selected_types)) {
                $selected_types = [PropertyType::RESIDENTIAL_UNIT];
            }
            
            // Parse visible columns
            $column_strings = array_map('trim', explode(',', $atts['columns']));
            $available_columns = FrontendSettingsDto::getAllAvailableColumns();
            $visible_columns = array_intersect($column_strings, $available_columns);
            
            // If no valid columns, use defaults
            if (empty($visible_columns)) {
                $visible_columns = [
                    ResourceDto::FIELD_NR_LOKALU,
                    ResourceDto::FIELD_RODZAJ_NIERUCHOMOSCI,
                    ResourceDto::FIELD_POWIERZCHNIA_UZYTKOWA,
                    'cena_calkowita',
                    ResourceDto::FIELD_STATUS,
                    'historia_cen'
                ];
            }
            
            // Use provided color
            $primary_color = $atts['color'];
            
            // Get default column names
            $column_names = FrontendSettingsDto::getDefaultColumnNames();
            
            // Render the resources table
            return self::render_resources_table($selected_types, $visible_columns, $column_names, $primary_color);
            
        } catch (Exception $e) {
            Logger::error("Shortcode error: " . $e->getMessage());
            return '<div class="ujc-shortcode-error">Błąd podczas ładowania zasobów.</div>';
        }
    }
    
    /**
     * Render resources table for shortcode
     */
    private static function render_resources_table(array $selected_types, array $visible_columns, array $column_names, string $primary_color): string {
        Logger::info("Shortcode: render_resources_table started");
        Logger::info("Shortcode: Selected types count: " . count($selected_types));
        Logger::info("Shortcode: Selected type values: " . implode(', ', array_map(fn($type) => $type->value, $selected_types)));
        
        // Get resources using dedicated frontend UseCase with built-in filtering
        $frontend_use_case = new GetResourcesForFrontendUseCase();
        $filtered_resources = $frontend_use_case->execute($selected_types);
        Logger::info("Shortcode: Got " . count($filtered_resources) . " filtered resources from GetResourcesForFrontendUseCase");
        
        if (empty($filtered_resources)) {
            Logger::error("Shortcode: No resources to display");
            return '<div class="ujc-no-resources">Brak zasobów do wyświetlenia.</div>';
        }
        
        // Start output buffering
        ob_start();
        
        // Generate dynamic CSS
        self::render_dynamic_css($primary_color);
        
        ?>
        <div class="ujc-shortcode-resources-list">
            <table class="resources-table">
                <thead>
                    <tr>
                        <?php foreach ($visible_columns as $column): ?>
                            <th><?php echo esc_html($column_names[$column] ?? ucfirst($column)); ?></th>
                        <?php endforeach; ?>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($filtered_resources as $resource): ?>
                        <tr>
                            <?php foreach ($visible_columns as $column): ?>
                                <td><?php echo self::render_column_value($resource, $column); ?></td>
                            <?php endforeach; ?>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
            
            <!-- Price History Modal (same as in existing block) -->
            <div id="price-history-modal" class="price-history-modal" style="display: none;">
                <div class="modal-content">
                    <div class="modal-header">
                        <h3>Historia cen - <span id="modal-resource-name"></span></h3>
                        <button class="modal-close">&times;</button>
                    </div>
                    <div class="modal-body">
                        <div id="history-loading">Ładowanie...</div>
                        <div id="history-content"></div>
                    </div>
                </div>
            </div>
        </div>
        <?php
        
        return ob_get_clean();
    }
    
    /**
     * Render individual column value
     */
    private static function render_column_value($resource, string $column): string {
        switch ($column) {
            case ResourceDto::FIELD_NR_LOKALU:
                return esc_html($resource->nr_lokalu);
                
            case ResourceDto::FIELD_RODZAJ_NIERUCHOMOSCI:
                try {
                    $propertyType = PropertyType::from($resource->rodzaj_nieruchomosci);
                    return esc_html($propertyType->getDisplayText());
                } catch (ValueError $e) {
                    return esc_html($resource->rodzaj_nieruchomosci);
                }
                
            case ResourceDto::FIELD_POWIERZCHNIA_UZYTKOWA:
                // Hide surface area for parking spaces (existing logic)
                if ($resource->rodzaj_nieruchomosci === PropertyType::PARKING_SPACE->value) {
                    return '—';
                }
                return esc_html(number_format($resource->powierzchnia_uzytkowa, 2, ',', ' ')) . ' m²';
                
            case ResourceDto::FIELD_STATUS:
                try {
                    $status = ResourceStatus::from($resource->status);
                    return '<span class="status-' . esc_attr($resource->status) . '">' . esc_html($status->getDisplayText()) . '</span>';
                } catch (ValueError $e) {
                    return esc_html($resource->status);
                }
                
            case 'cena_m2':
                // Hide price per m2 for parking spaces (existing logic)
                if ($resource->rodzaj_nieruchomosci === PropertyType::PARKING_SPACE->value) {
                    return '—';
                }
                if ($resource->cena_m2 !== null && $resource->cena_m2 > 0) {
                    return esc_html(number_format($resource->cena_m2, 2, ',', ' ')) . ' zł';
                }
                return '—';
                
            case 'cena_calkowita':
                if ($resource->cena_calkowita) {
                    return esc_html(number_format($resource->cena_calkowita, 2, ',', ' ')) . ' zł';
                }
                return '—';
                
            case 'cena_z_dodatkami':
                if ($resource->cena_z_dodatkami) {
                    return esc_html(number_format($resource->cena_z_dodatkami, 2, ',', ' ')) . ' zł';
                }
                return '—';
                
            case 'historia_cen':
                return '<button class="price-history-btn" data-resource-id="' . esc_attr($resource->id) . '" data-resource-name="' . esc_attr($resource->nr_lokalu) . '">Historia cen</button>';
                
            // Marketing fields
            case ResourceDto::FIELD_FLOOR_NUMBER:
                return $resource->floor_number ? esc_html($resource->floor_number) : '—';
                
            case ResourceDto::FIELD_ROOM_COUNT:
                return $resource->room_count ? esc_html($resource->room_count) : '—';
                
            case ResourceDto::FIELD_ADDITIONAL_DESCRIPTION:
                return $resource->additional_description ? esc_html(wp_trim_words($resource->additional_description, 10)) : '—';
                
            case ResourceDto::FIELD_GARDEN_AREA:
                return $resource->garden_area ? esc_html(number_format($resource->garden_area, 2, ',', ' ')) . ' m²' : '—';
                
            case ResourceDto::FIELD_FLOOR_PLAN_PDF:
                return $resource->floor_plan_pdf ? '<a href="' . esc_url($resource->floor_plan_pdf) . '" target="_blank">Plan</a>' : '—';
                
            default:
                return '—';
        }
    }
    
    /**
     * Render dynamic CSS with custom primary color
     */
    private static function render_dynamic_css(string $primary_color): void {
        // Calculate darker shade for hover
        $primary_rgb = sscanf($primary_color, "#%02x%02x%02x");
        $darker_color = sprintf("#%02x%02x%02x", 
            max(0, $primary_rgb[0] - 30),
            max(0, $primary_rgb[1] - 30), 
            max(0, $primary_rgb[2] - 30)
        );
        
        ?>
        <style>
        .ujc-shortcode-resources-list .price-history-btn {
            background-color: <?php echo esc_attr($primary_color); ?>;
            color: white;
            border: none;
            padding: 6px 12px;
            border-radius: 4px;
            cursor: pointer;
            font-size: 0.875em;
            transition: background-color 0.2s;
        }
        
        .ujc-shortcode-resources-list .price-history-btn:hover {
            background-color: <?php echo esc_attr($darker_color); ?>;
        }
        
        .ujc-shortcode-resources-list .resources-table {
            width: 100%;
            border-collapse: collapse;
            margin: 1em 0;
        }
        
        .ujc-shortcode-resources-list .resources-table th,
        .ujc-shortcode-resources-list .resources-table td {
            padding: 12px 8px;
            text-align: left;
            border-bottom: 1px solid #ddd;
        }
        
        .ujc-shortcode-resources-list .resources-table th {
            background-color: #f9f9f9;
            font-weight: 600;
            border-bottom: 2px solid <?php echo esc_attr($primary_color); ?>;
        }
        
        .ujc-shortcode-resources-list .resources-table tbody tr:hover {
            background-color: #f5f5f5;
        }
        
        .ujc-shortcode-resources-list .ujc-no-resources {
            padding: 20px;
            text-align: center;
            color: #666;
            font-style: italic;
        }
        
        .ujc-shortcode-resources-list .ujc-shortcode-error {
            padding: 15px;
            background-color: #ffebee;
            color: #c62828;
            border: 1px solid #ffcdd2;
            border-radius: 4px;
            margin: 10px 0;
        }
        </style>
        <?php
    }
}