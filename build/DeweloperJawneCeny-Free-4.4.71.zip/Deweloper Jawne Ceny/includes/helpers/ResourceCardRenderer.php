<?php

if (!defined('ABSPATH')) {
    exit;
}

/**
 * Resource Card Renderer Helper
 * Renders resources in card/tile layout as an alternative to table view
 */
class ResourceCardRenderer {

    /**
     * Render resources as a grid of cards
     */
    public static function renderCardGrid(
        array $resources,
        array $visible_columns,
        array $column_names,
        array $styling_options = [],
        array $card_config = []
    ): string {

        if (empty($resources)) {
            return '<div class="ujc-no-resources">Brak zasobów do wyświetlenia.</div>';
        }

        // Start output buffering
        ob_start();

        // Generate dynamic CSS for cards
        self::renderDynamicCSS($styling_options, $card_config);

        // Determine cards per row
        $cards_per_row = $card_config['cardsPerRow'] ?? 3;
        ?>
        <div class="resource-cards-grid cards-per-row-<?php echo esc_attr($cards_per_row); ?>">
            <?php foreach ($resources as $resource): ?>
                <?php echo self::renderSingleCard($resource, $visible_columns, $column_names, $styling_options, $card_config); ?>
            <?php endforeach; ?>
        </div>

        <!-- Price History Modal (shared with table view) -->
        <div id="price-history-modal" class="price-history-modal" style="display: none;">
            <div class="modal-content">
                <div class="modal-header">
                    <h3>Historia cen</h3>
                    <span class="close">&times;</span>
                </div>
                <div class="modal-body">
                    <div id="price-history-content">
                        <p>Ładowanie...</p>
                    </div>
                </div>
            </div>
        </div>
        <?php

        return ob_get_clean();
    }

    /**
     * Render a single resource card
     */
    private static function renderSingleCard(
        $resource,
        array $visible_columns,
        array $column_names,
        array $styling_options,
        array $card_config
    ): string {

        // Handle clickable cards (same as clickable rows)
        $detail_url = $card_config['detailPageUrl'] ?? '';
        $clickable_attrs = '';
        $clickable_class = '';

        if (!empty($detail_url)) {
            $clickable_class = ' clickable-card';
            $full_detail_url = rtrim($detail_url, '/') . '/' . urlencode($resource->nr_lokalu);
            $clickable_attrs = ' data-detail-url="' . esc_attr($full_detail_url) . '"';
        }

        // Build HTML using string concatenation (like renderColumnValue pattern)
        $html = '<div class="resource-card' . $clickable_class . '"' . $clickable_attrs . '>';
        $html .= '<div class="card-header">';
        $html .= '<div class="card-title-area">';
        $html .= self::renderCardTitle($resource, $visible_columns, $column_names, $styling_options);
        $html .= '</div>';
        $html .= '<div class="status-badge-fixed">';
        $html .= self::renderStatusBadge($resource, $styling_options);
        $html .= '</div>';
        $html .= '</div>';
        $html .= '<div class="card-body">';
        $html .= self::renderCardBody($resource, $visible_columns, $column_names, $styling_options);
        $html .= '</div>';
        $html .= '</div>';

        return $html;
    }

    /**
     * Render card title (first field from visible_columns, excluding status)
     */
    private static function renderCardTitle(
        ResourceDto $resource,
        array $visible_columns,
        array $column_names,
        array $styling_options
    ): string {

        // Find first non-status field for title
        $title_field = '';
        foreach ($visible_columns as $field) {
            if ($field !== ResourceDto::FIELD_STATUS) {
                $title_field = $field;
                break;
            }
        }

        if (empty($title_field)) {
            $title_field = ResourceDto::FIELD_NR_LOKALU; // Fallback
        }

        $title_value = self::getFieldValue($resource, $title_field);
        $title_label = $column_names[$title_field] ?? ucfirst(str_replace('_', ' ', $title_field));

        return '<h3 class="card-title">' . esc_html($title_value) . '</h3>';
    }

    /**
     * Render card body with remaining fields
     */
    private static function renderCardBody(
        ResourceDto $resource,
        array $visible_columns,
        array $column_names,
        array $styling_options
    ): string {

        $body_html = '';

        // Get body fields (exclude status and title field)
        $title_field = '';
        foreach ($visible_columns as $field) {
            if ($field !== ResourceDto::FIELD_STATUS) {
                $title_field = $field;
                break;
            }
        }

        foreach ($visible_columns as $field) {
            // Skip status (in header) and title field (already rendered)
            if ($field === ResourceDto::FIELD_STATUS || $field === $title_field) {
                continue;
            }

            $body_html .= self::renderCardField($resource, $field, $column_names, $styling_options);
        }

        return $body_html;
    }

    /**
     * Render a single field in the card
     */
    private static function renderCardField(
        ResourceDto $resource,
        string $field,
        array $column_names,
        array $styling_options
    ): string {

        $field_value = self::getFieldValue($resource, $field);
        $field_label = $column_names[$field] ?? ucfirst(str_replace('_', ' ', $field));

        // Handle special fields like buttons
        if ($field === ResourceTableRenderer::COLUMN_HISTORIA_CEN) {
            return self::renderHistoriaButton($resource, $styling_options);
        }

        if ($field === ResourceDto::FIELD_FLOOR_PLAN_PDF) {
            return self::renderFloorPlanButton($resource, $styling_options);
        }

        // Add semantic classes based on field type
        $field_classes = ['card-field'];

        // Add price field class for price-related fields
        if (self::isPriceField($field)) {
            $field_classes[] = 'price-field';
        }

        // Add area field class for area-related fields
        if (self::isAreaField($field)) {
            $field_classes[] = 'area-field';
        }

        $class_attr = implode(' ', $field_classes);

        // Regular field
        return '<div class="' . esc_attr($class_attr) . '">
            <span class="field-label">' . esc_html($field_label) . ':</span>
            <span class="field-value">' . esc_html($field_value) . '</span>
        </div>';
    }

    /**
     * Render status badge (same logic as table)
     */
    private static function renderStatusBadge(ResourceDto $resource, array $styling_options): string {

        // Use same logic as ResourceTableRenderer for status rendering
        $status = $resource->status;
        $status_text = ucfirst($status);

        // Apply status styling (uses CSS variables set by styling_options)
        return '<span class="status-badge status-' . esc_attr($status) . '">' . esc_html($status_text) . '</span>';
    }

    /**
     * Render Historia Cen button
     */
    private static function renderHistoriaButton(ResourceDto $resource, array $styling_options): string {
        $button_text = $styling_options['historia_btn_text'] ?? 'Historia';

        return '<div class="card-field card-action">
            <button class="historia-btn" data-resource-id="' . esc_attr($resource->id) . '">
                ' . esc_html($button_text) . '
            </button>
        </div>';
    }

    /**
     * Render floor plan button
     */
    private static function renderFloorPlanButton(ResourceDto $resource, array $styling_options): string {
        if (empty($resource->floor_plan_pdf)) {
            return '';
        }

        $button_text = $styling_options['karta_btn_text'] ?? 'Plan';

        return '<div class="card-field card-action">
            <a href="' . esc_url($resource->floor_plan_pdf) . '" target="_blank" class="floor-plan-btn">
                ' . esc_html($button_text) . '
            </a>
        </div>';
    }

    /**
     * Get field value from resource (same logic as ResourceTableRenderer)
     */
    private static function getFieldValue(ResourceDto $resource, string $field): string {

        switch ($field) {
            case ResourceDto::FIELD_NR_LOKALU:
                return $resource->nr_lokalu;
            case ResourceDto::FIELD_RODZAJ_NIERUCHOMOSCI:
                return $resource->rodzaj_nieruchomosci;
            case ResourceDto::FIELD_POWIERZCHNIA_UZYTKOWA:
                return $resource->powierzchnia_uzytkowa . ' m²';
            case ResourceDto::FIELD_STATUS:
                return ucfirst($resource->status);
            case ResourceDto::FIELD_FLOOR_NUMBER:
                return (string)$resource->floor_number;
            case ResourceDto::FIELD_ROOM_COUNT:
                return (string)$resource->room_count;
            case ResourceDto::FIELD_ADDITIONAL_DESCRIPTION:
                return $resource->additional_description ?? '';
            case ResourceDto::FIELD_GARDEN_AREA:
                return $resource->garden_area ? $resource->garden_area . ' m²' : '';
            case PriceHistoryDto::FIELD_CENA_M2:
                return number_format($resource->price_per_m2, 0, ',', ' ') . ' PLN/m²';
            case PriceHistoryDto::FIELD_CENA_CALKOWITA:
                return number_format($resource->total_price, 0, ',', ' ') . ' PLN';
            case PriceHistoryDto::FIELD_CENA_Z_DODATKAMI:
                return $resource->price_with_extras ? number_format($resource->price_with_extras, 0, ',', ' ') . ' PLN' : '';
            default:
                return '';
        }
    }


    /**
     * Check if field is a price-related field
     */
    private static function isPriceField(string $field): bool {
        return in_array($field, [
            PriceHistoryDto::FIELD_CENA_M2,
            PriceHistoryDto::FIELD_CENA_CALKOWITA,
            PriceHistoryDto::FIELD_CENA_Z_DODATKAMI
        ]);
    }

    /**
     * Check if field is an area-related field
     */
    private static function isAreaField(string $field): bool {
        return in_array($field, [
            ResourceDto::FIELD_POWIERZCHNIA_UZYTKOWA,
            ResourceDto::FIELD_GARDEN_AREA
        ]);
    }

    /**
     * Enqueue necessary JavaScript assets for card functionality
     */
    private static function enqueueCardAssets(bool $has_clickable_cards = false): void {
        // Always enqueue the resources widget JavaScript for modal functionality
        wp_enqueue_script(
            'ujc-resources-widget',
            plugins_url('assets/blocks/resources-list-widget.js', dirname(dirname(__DIR__)) . '/ustawa-jawnosci-cen.php'),
            ['jquery'],
            VERSION,
            true
        );

        // Localize script with AJAX data
        wp_localize_script('ujc-resources-widget', 'resourcesListAjax', [
            'ajax_url' => admin_url('admin-ajax.php'),
            'nonce' => wp_create_nonce('resources_list_nonce'),
            'strings' => [
                'loading' => 'Ładowanie...',
                'error' => 'Wystąpił błąd podczas ładowania historii cen.',
                'no_history' => 'Brak historii cen dla tego zasobu.'
            ]
        ]);

        // Enqueue clickable cards JavaScript if needed
        if ($has_clickable_cards) {
            wp_enqueue_script(
                'ujc-clickable-rows',
                plugins_url('assets/frontend-clickable-rows.js', dirname(dirname(__DIR__)) . '/ustawa-jawnosci-cen.php'),
                ['jquery'],
                '1.0.1',
                true
            );
        }
    }

    /**
     * Render CSS variables for card styling (like ResourceTableRenderer)
     */
    private static function renderDynamicCSS(array $styling_options, array $card_config): void {
        ?>
        <style>
        /* CSS Custom Properties for resource cards styling */
        :root {
            /* Shared variables (same as table) */
            --text-color: <?php echo esc_attr($styling_options['text_color'] ?? '#333'); ?>;
            --content-font-family: <?php echo esc_attr($styling_options['content_font_family'] ?? 'inherit'); ?>;

            /* Status variables (shared) */
            --status-available-bg-color: <?php echo esc_attr($styling_options['status_available_bg_color'] ?? '#28a745'); ?>;
            --status-available-text-color: <?php echo esc_attr($styling_options['status_available_text_color'] ?? '#ffffff'); ?>;
            --status-sold-bg-color: <?php echo esc_attr($styling_options['status_sold_bg_color'] ?? '#dc3545'); ?>;
            --status-sold-text-color: <?php echo esc_attr($styling_options['status_sold_text_color'] ?? '#ffffff'); ?>;
            --status-reserved-bg-color: <?php echo esc_attr($styling_options['status_reserved_bg_color'] ?? '#ffc107'); ?>;
            --status-reserved-text-color: <?php echo esc_attr($styling_options['status_reserved_text_color'] ?? '#000000'); ?>;
            --status-font-size: <?php echo esc_attr($styling_options['status_font_size'] ?? '0.875em'); ?>;
            --status-padding: <?php echo esc_attr($styling_options['status_padding'] ?? '4px 8px'); ?>;
            --status-border-radius: <?php echo esc_attr($styling_options['status_border_radius'] ?? '4px'); ?>;
            --status-font-weight: <?php echo esc_attr($styling_options['status_font_weight'] ?? 'normal'); ?>;

            /* Button variables (shared) */
            --historia-btn-bg-color: <?php echo esc_attr($styling_options['historia_btn_bg_color'] ?? '#007cba'); ?>;
            --historia-btn-text-color: <?php echo esc_attr($styling_options['historia_btn_text_color'] ?? '#ffffff'); ?>;
            --karta-btn-bg-color: <?php echo esc_attr($styling_options['karta_btn_bg_color'] ?? '#007cba'); ?>;
            --karta-btn-text-color: <?php echo esc_attr($styling_options['karta_btn_text_color'] ?? '#ffffff'); ?>;

            /* Card-specific variables */
            --card-bg-color: <?php echo esc_attr($card_config['cardBgColor'] ?? '#ffffff'); ?>;
            --card-border-color: <?php echo esc_attr($card_config['cardBorderColor'] ?? '#e1e5e9'); ?>;
            --card-border-radius: <?php echo esc_attr($card_config['cardBorderRadius'] ?? '8px'); ?>;
            --card-padding: <?php echo esc_attr($card_config['cardPadding'] ?? '16px'); ?>;
            --card-shadow: <?php echo esc_attr($card_config['cardShadow'] ?? '0 2px 4px rgba(0,0,0,0.1)'); ?>;
            --card-hover-shadow: <?php echo esc_attr($card_config['cardHoverShadow'] ?? '0 4px 12px rgba(0,0,0,0.15)'); ?>;
            --card-gap: <?php echo esc_attr($card_config['cardGap'] ?? '20px'); ?>;

            /* Layout variables */
            --container-margin: <?php echo esc_attr($styling_options['container_margin'] ?? '20px 0'); ?>;

            /* Modal variables (shared) */
            --modal-background-color: <?php echo esc_attr($styling_options['modal_background_color'] ?? '#ffffff'); ?>;
            --modal-border-radius: <?php echo esc_attr($styling_options['modal_border_radius'] ?? '8px'); ?>;
            --modal-max-width: <?php echo esc_attr($styling_options['modal_max_width'] ?? '600px'); ?>;
            --modal-padding: <?php echo esc_attr($styling_options['modal_padding'] ?? '20px'); ?>;
            --modal-box-shadow: <?php echo esc_attr($styling_options['modal_box_shadow'] ?? '0 10px 30px rgba(0,0,0,0.3)'); ?>;
            --modal-header-border-color: <?php echo esc_attr($styling_options['modal_header_border_color'] ?? '#dee2e6'); ?>;
            --modal-close-btn-color: <?php echo esc_attr($styling_options['modal_close_btn_color'] ?? '#666666'); ?>;
            --modal-close-btn-hover-color: <?php echo esc_attr($styling_options['modal_close_btn_hover_color'] ?? '#000000'); ?>;
            --modal-z-index: <?php echo esc_attr($styling_options['modal_z_index'] ?? '10000'); ?>;
        }
        </style>
        <?php
    }
}