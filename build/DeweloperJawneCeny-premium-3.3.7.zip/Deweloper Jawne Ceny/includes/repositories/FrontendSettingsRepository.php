<?php

if (!defined('ABSPATH')) {
    exit;
}

/**
 * Repository for frontend settings storage using WordPress options
 */
class FrontendSettingsRepository {
    
    private const OPTION_NAME = 'ujc_frontend_settings';
    
    /**
     * Save frontend settings to WordPress options
     */
    public function save(FrontendSettingsDto $settings): bool {
        Logger::info("FrontendSettingsRepository::save - Saving frontend settings");
        
        try {
            $data = $settings->toArray();
            $result = update_option(self::OPTION_NAME, $data);
            
            if ($result) {
                Logger::info("FrontendSettingsRepository::save - Settings saved successfully");
                return true;
            } else {
                Logger::warning("FrontendSettingsRepository::save - Failed to save settings or no changes detected");
                return false;
            }
            
        } catch (Exception $e) {
            Logger::error("FrontendSettingsRepository::save - Exception: " . $e->getMessage());
            return false;
        }
    }
    
    /**
     * Load frontend settings from WordPress options
     */
    public function load(): ?FrontendSettingsDto {
        Logger::info("FrontendSettingsRepository::load - Loading frontend settings");
        
        try {
            $data = get_option(self::OPTION_NAME, null);
            
            if ($data === null || !is_array($data)) {
                Logger::info("FrontendSettingsRepository::load - No settings found, returning default");
                return $this->getDefaultSettings();
            }
            
            Logger::info("FrontendSettingsRepository::load - Settings loaded successfully");
            return FrontendSettingsDto::fromArray($data);
            
        } catch (Exception $e) {
            Logger::error("FrontendSettingsRepository::load - Exception: " . $e->getMessage());
            return $this->getDefaultSettings();
        }
    }
    
    /**
     * Get default frontend settings
     */
    private function getDefaultSettings(): FrontendSettingsDto {
        return new FrontendSettingsDto(
            selected_types: [PropertyType::RESIDENTIAL_UNIT],
            primary_color: '#007cba',
            visible_columns: [
                ResourceDto::FIELD_NR_LOKALU,
                ResourceDto::FIELD_RODZAJ_NIERUCHOMOSCI,
                ResourceDto::FIELD_POWIERZCHNIA_UZYTKOWA,
                'cena_calkowita',
                ResourceDto::FIELD_STATUS,
                'historia_cen'
            ],
            column_names: FrontendSettingsDto::getDefaultColumnNames()
        );
    }
    
    /**
     * Reset settings to default values
     */
    public function reset(): bool {
        Logger::info("FrontendSettingsRepository::reset - Resetting to default settings");
        
        try {
            $default_settings = $this->getDefaultSettings();
            return $this->save($default_settings);
        } catch (Exception $e) {
            Logger::error("FrontendSettingsRepository::reset - Exception: " . $e->getMessage());
            return false;
        }
    }
    
    /**
     * Check if settings exist
     */
    public function exists(): bool {
        $data = get_option(self::OPTION_NAME, null);
        return $data !== null;
    }
    
    /**
     * Delete settings from database
     */
    public function delete(): bool {
        Logger::info("FrontendSettingsRepository::delete - Deleting frontend settings");
        
        try {
            $result = delete_option(self::OPTION_NAME);
            
            if ($result) {
                Logger::info("FrontendSettingsRepository::delete - Settings deleted successfully");
                return true;
            } else {
                Logger::warning("FrontendSettingsRepository::delete - Failed to delete settings or option not found");
                return false;
            }
            
        } catch (Exception $e) {
            Logger::error("FrontendSettingsRepository::delete - Exception: " . $e->getMessage());
            return false;
        }
    }
    
    /**
     * Get raw option data for debugging
     */
    public function getRawData(): ?array {
        return get_option(self::OPTION_NAME, null);
    }
}