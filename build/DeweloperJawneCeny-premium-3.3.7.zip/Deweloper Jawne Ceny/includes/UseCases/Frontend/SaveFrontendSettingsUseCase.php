<?php

if (!defined('ABSPATH')) {
    exit;
}

/**
 * Use case for saving frontend settings with validation
 */
class SaveFrontendSettingsUseCase {
    
    private $repository;
    
    public function __construct() {
        $this->repository = new FrontendSettingsRepository();
    }
    
    /**
     * Execute the save operation with validation
     */
    public function execute(array $form_data): Result {
        Logger::info("SaveFrontendSettingsUseCase::execute - Starting save operation");
        
        try {
            // Validate and sanitize form data
            $validated_data = $this->validateAndSanitizeFormData($form_data);
            if (!$validated_data) {
                return Result::failure('Nieprawidłowe dane formularza');
            }
            
            // Create DTO from validated data
            $settings_dto = $this->createSettingsDto($validated_data);
            
            // Save to repository
            $success = $this->repository->save($settings_dto);
            
            if ($success) {
                Logger::info("SaveFrontendSettingsUseCase::execute - Settings saved successfully");
                return Result::success('Ustawienia warstwy frontendowej zostały zapisane pomyślnie');
            } else {
                Logger::error("SaveFrontendSettingsUseCase::execute - Failed to save settings");
                return Result::failure('Błąd podczas zapisywania ustawień');
            }
            
        } catch (Exception $e) {
            Logger::error("SaveFrontendSettingsUseCase::execute - Exception: " . $e->getMessage());
            return Result::failure('Błąd systemu: ' . $e->getMessage());
        }
    }
    
    /**
     * Validate and sanitize form data
     */
    private function validateAndSanitizeFormData(array $form_data): ?array {
        Logger::info("SaveFrontendSettingsUseCase::validateAndSanitizeFormData - Validating form data");
        
        $validated = [];
        
        // Validate selected types
        if (!isset($form_data['selected_types']) || !is_array($form_data['selected_types'])) {
            Logger::error("SaveFrontendSettingsUseCase::validateAndSanitizeFormData - Invalid selected_types");
            return null;
        }
        
        $valid_property_types = array_map(fn($type) => $type->value, PropertyType::cases());
        $validated['selected_types'] = array_filter(
            array_map('sanitize_text_field', $form_data['selected_types']),
            fn($type) => in_array($type, $valid_property_types)
        );
        
        if (empty($validated['selected_types'])) {
            Logger::error("SaveFrontendSettingsUseCase::validateAndSanitizeFormData - No valid property types selected");
            return null;
        }
        
        // Validate primary color
        $primary_color = sanitize_text_field($form_data['primary_color'] ?? '#007cba');
        if (!preg_match('/^#[a-fA-F0-9]{6}$/', $primary_color)) {
            Logger::warning("SaveFrontendSettingsUseCase::validateAndSanitizeFormData - Invalid color format, using default");
            $primary_color = '#007cba';
        }
        $validated['primary_color'] = $primary_color;
        
        // Validate visible columns
        if (isset($form_data['visible_columns']) && is_array($form_data['visible_columns'])) {
            $available_columns = FrontendSettingsDto::getAllAvailableColumns();
            $validated['visible_columns'] = array_filter(
                array_map('sanitize_text_field', $form_data['visible_columns']),
                fn($column) => in_array($column, $available_columns)
            );
        } else {
            $validated['visible_columns'] = [];
        }
        
        // Validate column names
        $validated['column_names'] = [];
        if (isset($form_data['column_names']) && is_array($form_data['column_names'])) {
            $available_columns = FrontendSettingsDto::getAllAvailableColumns();
            foreach ($form_data['column_names'] as $column => $name) {
                $column = sanitize_text_field($column);
                if (in_array($column, $available_columns)) {
                    $validated['column_names'][$column] = sanitize_text_field($name);
                }
            }
        }
        
        // Merge with defaults if empty
        if (empty($validated['column_names'])) {
            $validated['column_names'] = FrontendSettingsDto::getDefaultColumnNames();
        }
        
        Logger::info("SaveFrontendSettingsUseCase::validateAndSanitizeFormData - Validation completed successfully");
        return $validated;
    }
    
    /**
     * Create FrontendSettingsDto from validated data
     */
    private function createSettingsDto(array $validated_data): FrontendSettingsDto {
        // Convert string values to PropertyType enums
        $selected_types = array_map(
            fn($type_string) => PropertyType::from($type_string),
            $validated_data['selected_types']
        );
        
        return new FrontendSettingsDto(
            selected_types: $selected_types,
            primary_color: $validated_data['primary_color'],
            visible_columns: $validated_data['visible_columns'],
            column_names: $validated_data['column_names']
        );
    }
}