<?php

if (!defined('ABSPATH')) {
    exit;
}

class GetAllResourcesUseCase {
    
    private ResourceRepository $resourceRepository;
    private PriceHistoryRepository $priceHistoryRepository;
    
    public function __construct() {
        $this->resourceRepository = new ResourceRepository();
        $this->priceHistoryRepository = new PriceHistoryRepository();
    }
    
    /**
     * @return PresentableResource[]
     * @throws Exception
     */
    public function execute(): array {
        $resources = $this->resourceRepository->readAll();
        $result = [];
        
        foreach ($resources as $resource) {
            $currentPrices = $this->priceHistoryRepository->getCurrentPricesForResource($resource->id);
            $presentableResource = new PresentableResource(
                $resource->id,
                PropertyType::from($resource->rodzaj_nieruchomosci),
                $resource->nr_lokalu,
                $resource->powierzchnia_uzytkowa,
                ResourceStatus::from($resource->status),
                $currentPrices->cena_m2,
                $currentPrices->cena_calkowita,
                $currentPrices->cena_z_dodatkami,
                $currentPrices->data_zmiany,
                $currentPrices->data_cena_z_dodatkami
            );
            
            $result[] = $presentableResource;
        }
        
        return $result;
    }
}