<?php

namespace JawneCeny;

if (!defined('ABSPATH')) {
    exit;
}

/**
 * Strona Instrukcji - pełna instrukcja obsługi wtyczki
 */
class InstructionsPage {

    public function __construct() {
        add_action('admin_enqueue_scripts', [$this, 'enqueue_assets']);
    }

    public function enqueue_assets() {
        wp_enqueue_style(
            'instructions-page',
            JAWNECENY_PLUGIN_URL . 'includes/views/admin/instructions/InstructionsPage.css',
            [],
            JAWNECENY_VERSION
        );
    }

    public function render() {
        ?>
        <div class="wrap instructions-page">
            <h1>Instrukcja obsługi wtyczki</h1>

            <div class="instructions-content">

                <!-- CZĘŚĆ 1: Pierwsze kroki -->
                <section class="instruction-section">
                    <h2>1. Pierwsze kroki - skonfiguruj wtyczkę</h2>

                    <p class="intro-text">
                        Zanim zaczniesz wyświetlać dane na stronie, musisz najpierw dodać informacje o swoich nieruchomościach. Proces składa się z trzech prostych kroków.
                    </p>

                    <div class="step-box">
                        <h3>Krok 1: Dodaj dane dostawcy</h3>
                        <ol>
                            <li>W menu wtyczki przejdź do zakładki <strong>"Dane dostawcy"</strong></li>
                            <li>Wypełnij formularz swoimi danymi</li>
                            <li>Kliknij przycisk <strong>"Zapisz"</strong></li>
                        </ol>
                        <p class="tip">Te dane będą wykorzystywane we wszystkich generowanych plikach i dokumentach.</p>
                    </div>

                    <div class="step-box">
                        <h3>Krok 2: Dodaj inwestycję</h3>
                        <ol>
                            <li>Przejdź do zakładki <strong>"Zasoby"</strong> w menu wtyczki</li>
                            <li>Jeśli nie masz jeszcze inwestycji, zobaczysz komunikat "Brak danych o inwestycji"</li>
                            <li>Kliknij przycisk <strong>"Dodaj Inwestycję"</strong></li>
                            <li>Wypełnij formularz z danymi inwestycji</li>
                            <li>Kliknij przycisk <strong>"Zapisz"</strong></li>
                        </ol>
                    </div>

                    <div class="step-box">
                        <h3>Krok 3: Dodaj zasoby (mieszkania, lokale)</h3>
                        <ol>
                            <li>Pozostań w zakładce <strong>"Zasoby"</strong></li>
                            <li>Kliknij przycisk <strong>"Dodaj Zasób"</strong></li>
                            <li>Wypełnij formularz z danymi nieruchomości</li>
                            <li>Kliknij przycisk <strong>"Zapisz zasób"</strong></li>
                            <li>Powtórz proces dla każdego mieszkania/lokalu w swojej inwestycji</li>
                        </ol>
                        <p class="tip">Możesz w każdej chwili edytować lub usunąć dodane zasoby klikając na karcie zasobu.</p>
                    </div>
                </section>

                <!-- CZĘŚĆ 2: Wyświetlanie na stronie -->
                <section class="instruction-section">
                    <h2>2. Wyświetlanie zasobów na stronie</h2>

                    <p class="intro-text">
                        Teraz, gdy masz już dodane zasoby, możesz wyświetlić je na swojej stronie internetowej. Masz do wyboru dwa sposoby - wybierz ten, który jest dla Ciebie wygodniejszy.
                    </p>

                    <div class="method-box">
                        <h3>Sposób A: Bloki Gutenberga (wizualny edytor) - POLECANY</h3>
                        <p class="method-description">To najprostszy sposób.</p>

                        <h4>Blok 1: "Lista Zasobów" - tabela lub kafelki z mieszkaniami</h4>

                        <p><strong>Jak dodać:</strong></p>
                        <ol>
                            <li>Otwórz stronę lub wpis, gdzie chcesz wyświetlić listę mieszkań</li>
                            <li>Kliknij przycisk <strong>"+"</strong> (dodaj blok)</li>
                            <li>W wyszukiwarce wpisz <strong>"Lista Zasobów"</strong></li>
                            <li>Kliknij na blok <strong>"Lista Zasobów"</strong></li>
                            <li>Po prawej stronie edytora zobaczysz panel ustawień bloku</li>
                        </ol>

                        <p><strong>Co możesz skonfigurować:</strong></p>
                        <ul>
                            <li><strong>Typy nieruchomości:</strong> Zaznacz które rodzaje chcesz pokazać (mieszkania, garaże, itp.)</li>
                            <li><strong>Sposób wyświetlania:</strong> Tabela lub kafelki</li>
                            <li><strong>Widoczne kolumny:</strong> Zaznacz które informacje mają być widoczne (numer, cena, powierzchnia, itp.)</li>
                            <li><strong>Nazwy kolumn:</strong> Możesz zmienić nazwy każdej kolumny</li>
                            <li><strong>Kolejność kolumn:</strong> Przeciągnij kolumny aby zmienić ich kolejność</li>
                            <li><strong>Kolory:</strong> Zmień kolory tła, tekstu, nagłówków, przycisków</li>
                            <li><strong>Czcionki:</strong> Wybierz czcionki dla nagłówków i treści</li>
                            <li><strong>Nawigacja:</strong> Ustaw klikalne wiersze lub przycisk "Zobacz więcej"</li>
                            <li><strong>Sortowanie:</strong> Włącz sortowanie po kliknięciu w nagłówek kolumny</li>
                        </ul>

                        <ol start="6">
                            <li>Kliknij <strong>"Opublikuj"</strong> lub <strong>"Aktualizuj"</strong></li>
                            <li>Gotowe! Odwiedź swoją stronę, aby zobaczyć efekt</li>
                        </ol>

                        <h4>Blok 2: "Filtry Zasobów" - zewnętrzne filtrowanie dla klientów</h4>

                        <p><strong>Jak dodać:</strong></p>
                        <ol>
                            <li>Na tej samej stronie co "Lista Zasobów" kliknij przycisk <strong>"+"</strong></li>
                            <li>W wyszukiwarce wpisz <strong>"Filtry Zasobów"</strong></li>
                            <li>Kliknij na blok <strong>"Filtry Zasobów"</strong></li>
                            <li>Umieść ten blok obok "Lista Zasobów"</li>
                        </ol>

                        <p><strong>Co możesz skonfigurować:</strong></p>
                        <ul>
                            <li><strong>Dostępne filtry:</strong> Zaznacz które filtry mają być widoczne:
                                <ul>
                                    <li>Rodzaj nieruchomości</li>
                                    <li>Liczba pokoi</li>
                                    <li>Piętro</li>
                                    <li>Powierzchnia (od-do)</li>
                                    <li>Cena (od-do)</li>
                                    <li>Status (dostępne/zarezerwowane)</li>
                                </ul>
                            </li>
                            <li><strong>Kolory:</strong> Dostosuj kolory przycisków i tła</li>
                            <li><strong>Układ:</strong> Wybierz sposób wyświetlania filtrów</li>
                        </ul>

                        <div class="important-box">
                            <p><strong>WAŻNE:</strong> Aby filtry działały:</p>
                            <ol>
                                <li>W bloku "Lista Zasobów" włącz opcję <strong>"Czytaj filtry z URL"</strong> (znajdziesz ją w panelu ustawień bloku)</li>
                                <li>Oba bloki muszą być na tej samej stronie</li>
                            </ol>
                        </div>

                        <p class="tip">Jak to działa: Klient wybiera filtry → Lista automatycznie się aktualizuje bez przeładowania strony</p>

                        <h4>Blok 3: "Szczegóły zasobu" - pojedyncze mieszkanie</h4>

                        <p><strong>Jak dodać:</strong></p>
                        <ol>
                            <li>Utwórz osobną stronę dla każdego mieszkania (np. "/mieszkania/a1")</li>
                            <li>Na tej stronie kliknij przycisk <strong>"+"</strong> i wyszukaj <strong>"Szczegóły zasobu"</strong></li>
                            <li>Kliknij na blok <strong>"Szczegóły zasobu"</strong></li>
                        </ol>

                        <p><strong>Co możesz skonfigurować:</strong></p>
                        <ul>
                            <li><strong>Widoczne pola:</strong> Zaznacz które informacje mają być wyświetlane</li>
                            <li><strong>Nazwy pól:</strong> Zmień nazwy każdego pola</li>
                            <li><strong>Kolejność pól:</strong> Przeciągnij pola aby zmienić ich kolejność</li>
                            <li><strong>Kolory:</strong> Dostosuj kolory tła, tekstu, nagłówków</li>
                            <li><strong>Historia cen:</strong> Włącz/wyłącz przycisk historii cen</li>
                        </ul>

                        <div class="important-box">
                            <p><strong>WAŻNE:</strong> Blok automatycznie wykrywa numer lokalu z adresu URL strony. Jeśli strona ma adres <code>/mieszkania/A1</code>, blok wyświetli dane lokalu A1.</p>
                        </div>

                        <ol start="4">
                            <li>Zapisz stronę</li>
                            <li>Gotowe!</li>
                        </ol>
                    </div>

                    <div class="method-box">
                        <h3>Sposób B: Shortcode</h3>

                        <h4>Jak użyć shortcode dla listy zasobów:</h4>
                        <ol>
                            <li>Przejdź do zakładki <strong>"Generator Shortcode"</strong> w menu wtyczki</li>
                            <li>Przełącz na zakładkę <strong>"Lista zasobów"</strong></li>
                            <li>Skonfiguruj wygląd tabeli używając formularza:
                                <ul>
                                    <li>Wybierz typy nieruchomości</li>
                                    <li>Zaznacz kolumny do wyświetlenia</li>
                                    <li>Zmień nazwy kolumn</li>
                                    <li>Dostosuj kolory i wygląd</li>
                                    <li>Ustaw nawigację i sortowanie</li>
                                </ul>
                            </li>
                            <li>Na dole strony w sekcji "Wygenerowany shortcode" zobaczysz kod, np:<br>
                                <code>[resources_list types="residential_unit" columns="nr_lokalu:Numer,powierzchnia_uzytkowa:Powierzchnia,cena_calkowita:Cena"]</code>
                            </li>
                            <li>Skopiuj ten kod</li>
                            <li>Otwórz stronę, gdzie chcesz wyświetlić mieszkania</li>
                            <li>Dodaj blok <strong>"Shortcode"</strong></li>
                            <li>Wklej skopiowany kod</li>
                            <li>Zapisz stronę</li>
                        </ol>

                        <h4>Jak użyć shortcode dla pojedynczego zasobu:</h4>
                        <ol>
                            <li>Utwórz stronę dla mieszkania (np. "/mieszkania/a1")</li>
                            <li>Dodaj blok <strong>"Shortcode"</strong></li>
                            <li>Wklej kod: <code>[resource_single]</code></li>
                            <li>Shortcode automatycznie wykryje numer lokalu z adresu URL</li>
                            <li>Zapisz stronę</li>
                        </ol>

                        <p class="tip">W Generatorze Shortcode możesz też skonfigurować wygląd pojedynczego zasobu w zakładce "Szczegóły zasobu".</p>
                    </div>
                </section>

                <!-- CZĘŚĆ 3: Następny krok -->
                <section class="instruction-section premium-section">
                    <h2>3. Następny krok - spełnienie wymogów prawnych</h2>

                    <h3>Dlaczego potrzebujesz więcej?</h3>

                    <p>
                        Jako deweloper jesteś <strong>zobowiązany prawnie</strong> do przekazywania danych o cenach mieszkań
                        do Ministerstwa Rozwoju i Technologii zgodnie z <strong>Ustawą o jawności cen nieruchomości</strong>.
                    </p>

                    <p>Do tej pory dodałeś dane i wyświetliłeś je na stronie. To świetny początek!</p>

                    <p>Ale <strong>aby spełnić wymogi prawne</strong>, musisz:</p>
                    <ul>
                        <li>Generować pliki XML i CSV w formacie wymaganym przez ministerstwo</li>
                        <li>Automatycznie aktualizować te pliki codziennie</li>
                        <li>Udostępnić je ministerstwu przez publicznie dostępne adresy URL</li>
                    </ul>

                    <p><strong>Bez tego możesz być narażony na kary prawne.</strong></p>

                    <h3>Rozwiązanie: Pełna wersja wtyczki</h3>

                    <p>Pełna wersja wtyczki automatyzuje cały proces zgodności z ustawą:</p>

                    <ul class="feature-list">
                        <li>Automatyczne generowanie plików XML i CSV - zgodnie z wymaganiami ministerstwa</li>
                        <li>Automatyczna aktualizacja co 24h - nie musisz pamiętać o niczym</li>
                        <li>Integracja z portalem dane.gov.pl - automatyczne zasilanie danych</li>
                        <li>Pełna zgodność z ustawą - spokój prawny</li>
                    </ul>

                    <h3>Jak kupić pełną wersję?</h3>

                    <p>Odwiedź stronę: <a href="https://www.deweloperjawneceny.pl" target="_blank" class="premium-link">https://www.deweloperjawneceny.pl</a></p>

                    <p>Po zakupie otrzymasz:</p>
                    <ul>
                        <li>Plik wtyczki w wersji Premium</li>
                        <li>Dostęp do wszystkich funkcji automatyzacji</li>
                    </ul>

                    <p class="tip">Po zainstalowaniu pełnej wersji, przejdź do kolejnej części tej instrukcji.</p>
                </section>

                <!-- CZĘŚĆ 4: Automatyzacja -->
                <section class="instruction-section ministry-section">
                    <h2>4. Włączenie automatyzacji i integracja z Ministerstwem</h2>

                    <div class="important-box">
                        <p><strong>UWAGA:</strong> Ta część instrukcji dotyczy tylko pełnej wersji wtyczki. Jeśli jeszcze jej nie masz, wróć do poprzedniej sekcji.</p>
                    </div>

                    <p class="intro-text">
                        Po zakupie i zainstalowaniu pełnej wersji wtyczki, musisz wykonać dwa kluczowe kroki:<br>
                        1. Włączyć automatyczne generowanie plików<br>
                        2. Zgłosić adresy plików do Ministerstwa, aby mogło je pobierać
                    </p>

                    <p>To jednorazowy proces - wystarczy zrobić to raz, a później wszystko działa automatycznie.</p>

                    <div class="step-box">
                        <h3>Krok 1: Włącz automatyzację</h3>
                        <ol>
                            <li>W menu wtyczki przejdź do zakładki <strong>"Pulpit"</strong></li>
                            <li>Znajdź kafelek <strong>"Automatyzacja"</strong></li>
                            <li>Zobaczysz status: <strong>"❌ Nieaktywny"</strong></li>
                            <li>Kliknij przycisk <strong>"▶️ Włącz External Cron"</strong></li>
                            <li>Poczekaj chwilę - zobaczysz komunikat o powodzeniu</li>
                            <li>Status zmieni się na: <strong>"✅ Aktywny"</strong></li>
                            <li>Pod statusem zobaczysz: <strong>"Częstotliwość: Co 24 godziny"</strong></li>
                        </ol>

                        <p><strong>Co się właśnie stało?</strong><br>
                        Wtyczka będzie teraz automatycznie generować pliki XML i MD5 co 24 godziny. Nie musisz już nic robić - pliki będą zawsze aktualne.</p>

                        <p class="tip">Jeśli kiedykolwiek zechcesz wyłączyć automatyzację, kliknij przycisk "⏸️ Wyłącz External Cron".</p>
                    </div>

                    <div class="step-box">
                        <h3>Krok 2: Skopiuj adresy plików XML i MD5</h3>
                        <ol>
                            <li>W menu wtyczki przejdź do zakładki <strong>"Publikacja Danych"</strong></li>
                            <li>W prawym górnym rogu zobaczysz ramkę <strong>"Publiczne adresy plików"</strong></li>
                            <li>Znajdziesz tam dwa adresy:
                                <ul>
                                    <li><strong>Plik XML:</strong> https://twoja-strona.pl/wp-content/uploads/ujc-data/katalog-danych.xml</li>
                                    <li><strong>Plik MD5:</strong> https://twoja-strona.pl/wp-content/uploads/ujc-data/katalog-danych.md5</li>
                                </ul>
                            </li>
                            <li>Skopiuj oba adresy (zaznacz i naciśnij Ctrl+C lub Cmd+C)</li>
                        </ol>
                        <p class="tip">Te adresy są unikalne dla Twojej strony. Ministerstwo będzie z nich pobierać dane codziennie.</p>
                    </div>

                    <div class="step-box">
                        <h3>Krok 3: Pobierz formularz dla Ministerstwa</h3>
                        <p>Przygotowaliśmy gotowy formularz, który musisz wypełnić i wysłać do Ministerstwa.</p>
                        <div class="download-box">
                            <a href="<?php echo esc_url(JAWNECENY_PLUGIN_URL . 'assets/documents/Dane_niezbedne_do_uruchomienia_automatyzacji.docx'); ?>"
                               class="button button-primary button-large"
                               download>
                                📥 Pobierz formularz (plik DOCX)
                            </a>
                        </div>
                    </div>

                    <div class="step-box">
                        <h3>Krok 4: Wypełnij formularz krok po kroku</h3>
                        <p>Otwórz pobrany plik w programie Word lub Google Docs i uzupełnij wszystkie pola:</p>

                        <table class="form-guide">
                            <thead>
                                <tr>
                                    <th>Pole w formularzu</th>
                                    <th>Co wpisać</th>
                                    <th>Przykład</th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr>
                                    <td><strong>Imię i nazwisko osoby zgłaszającej wniosek</strong></td>
                                    <td>Twoje imię i nazwisko</td>
                                    <td>Jan Kowalski</td>
                                </tr>
                                <tr>
                                    <td><strong>Nazwa dostawcy</strong></td>
                                    <td>Nazwa Twojej firmy (dokładnie taka sama, jak w zakładce "Dane dostawcy")</td>
                                    <td>ABC Development Sp. z o.o.</td>
                                </tr>
                                <tr>
                                    <td><strong>Adres URL pliku XML</strong></td>
                                    <td>Wklej adres XML skopiowany w Kroku 2</td>
                                    <td><code>https://twoja-strona.pl/wp-content/uploads/ujc-data/katalog-danych.xml</code></td>
                                </tr>
                                <tr>
                                    <td><strong>Adres URL pliku MD5</strong></td>
                                    <td>Wklej adres MD5 skopiowany w Kroku 2</td>
                                    <td><code>https://twoja-strona.pl/wp-content/uploads/ujc-data/katalog-danych.md5</code></td>
                                </tr>
                                <tr>
                                    <td><strong>Adres e-mail osoby do kontaktu</strong></td>
                                    <td>Twój służbowy e-mail (na który ministerstwo może się kontaktować)</td>
                                    <td>jan.kowalski@abcdevelopment.pl</td>
                                </tr>
                                <tr>
                                    <td><strong>Częstotliwość aktualizacji</strong></td>
                                    <td>Zostaw domyślną wartość</td>
                                    <td>codziennie</td>
                                </tr>
                            </tbody>
                        </table>

                        <p class="tip">Sprawdź dwukrotnie adresy URL - literówka spowoduje, że ministerstwo nie będzie mogło pobrać danych.</p>
                    </div>

                    <div class="step-box">
                        <h3>Krok 5: Wyślij formularz do Ministerstwa</h3>
                        <ol start="4">
                            <li>W polu <strong>"Do:"</strong> wpisz: <code>kontakt@dane.gov.pl</code></li>
                            <li>W polu <strong>"Temat:"</strong> wpisz:<br>
                                <code>"Wniosek o uruchomienie automatyzacji procesu udostępniania danych - [Nazwa Twojej firmy]"</code><br>
                                (zamień [Nazwa Twojej firmy] na rzeczywistą nazwę, np. "ABC Development Sp. z o.o.")
                            </li>
                            <li>W treści e-maila napisz:
                                <div class="email-template">
                                    <p>Dzień dobry,</p>
                                    <p>Przesyłam wypełniony formularz z danymi niezbędnymi do uruchomienia automatyzacji procesu udostępniania danych o cenach mieszkań.</p>
                                    <p>W załączniku znajduje się wypełniony dokument z adresami URL do plików XML i MD5.</p>
                                    <p>Proszę o konfigurację automatycznego pobierania danych.</p>
                                    <p>Pozdrawiam,<br>
                                    [Twoje imię i nazwisko]<br>
                                    [Nazwa firmy]<br>
                                    [Telefon kontaktowy]</p>
                                </div>
                            </li>
                            <li>Załącz wypełniony formularz (plik DOCX)</li>
                            <li>Sprawdź wszystko jeszcze raz</li>
                            <li>Wyślij e-mail</li>
                        </ol>
                    </div>

                    <div class="success-box">
                        <h3>✅ Gotowe! Co teraz?</h3>
                        <p>Od tego momentu <strong>nie musisz nic robić</strong>:</p>
                        <ul>
                            <li>Wtyczka automatycznie generuje pliki co 24 godziny</li>
                            <li>Ministerstwo pobiera dane z podanych adresów</li>
                            <li>Ty tylko aktualizuj dane o mieszkaniach w zakładce "Zasoby"</li>
                            <li>Wszystko działa automatycznie</li>
                        </ul>
                        <p><strong>Jesteś zgodny z prawem i masz spokój!</strong></p>
                    </div>
                </section>

                <!-- Pomoc -->
                <section class="instruction-section help-section">
                    <h2>Potrzebujesz pomocy?</h2>
                    <p>
                        Jeśli masz jakiekolwiek pytania lub problemy z konfiguracją wtyczki,
                        skontaktuj się z nami poprzez stronę <a href="https://www.deweloperjawneceny.pl" target="_blank">https://www.deweloperjawneceny.pl</a>
                    </p>
                </section>

            </div>
        </div>
        <?php
    }
}
