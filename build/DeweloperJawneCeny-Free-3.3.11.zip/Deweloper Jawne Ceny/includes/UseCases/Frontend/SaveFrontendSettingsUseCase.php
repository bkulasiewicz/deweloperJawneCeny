<?php

if (!defined('ABSPATH')) {
    exit;
}

/**
 * Use case for saving frontend settings with validation
 */
class SaveFrontendSettingsUseCase {
    
    private $repository;
    
    public function __construct() {
        $this->repository = new FrontendSettingsRepository();
    }
    
    /**
     * Execute the save operation with validation
     */
    public function execute(array $form_data): Result {
        Logger::info("SaveFrontendSettingsUseCase::execute - Starting save operation");
        Logger::info("SaveFrontendSettingsUseCase::execute - Form data keys received: " . implode(', ', array_keys($form_data)));
        Logger::info("SaveFrontendSettingsUseCase::execute - Form data count: " . count($form_data) . " elements");
        
        // Log specific form data for debugging
        if (isset($form_data['selected_types'])) {
            Logger::info("SaveFrontendSettingsUseCase::execute - selected_types: " . (is_array($form_data['selected_types']) ? implode(', ', $form_data['selected_types']) : 'NOT ARRAY'));
        } else {
            Logger::warning("SaveFrontendSettingsUseCase::execute - selected_types NOT SET in form_data");
        }
        
        if (isset($form_data['visible_columns'])) {
            Logger::info("SaveFrontendSettingsUseCase::execute - visible_columns: " . (is_array($form_data['visible_columns']) ? implode(', ', $form_data['visible_columns']) : 'NOT ARRAY'));
        } else {
            Logger::warning("SaveFrontendSettingsUseCase::execute - visible_columns NOT SET in form_data");
        }
        
        Logger::info("SaveFrontendSettingsUseCase::execute - primary_color: " . ($form_data['primary_color'] ?? 'NOT SET'));
        
        try {
            Logger::info("SaveFrontendSettingsUseCase::execute - Calling validateAndSanitizeFormData()");
            // Validate and sanitize form data
            $validated_data = $this->validateAndSanitizeFormData($form_data);
            
            if (!$validated_data) {
                Logger::error("SaveFrontendSettingsUseCase::execute - Validation failed, returning failure");
                return Result::failure('Nieprawidłowe dane formularza');
            }
            Logger::info("SaveFrontendSettingsUseCase::execute - Validation passed, validated data keys: " . implode(', ', array_keys($validated_data)));
            
            Logger::info("SaveFrontendSettingsUseCase::execute - Creating settings DTO");
            // Create DTO from validated data
            $settings_dto = $this->createSettingsDto($validated_data);
            Logger::info("SaveFrontendSettingsUseCase::execute - Settings DTO created successfully");
            
            Logger::info("SaveFrontendSettingsUseCase::execute - Calling repository->save()");
            // Save to repository
            $success = $this->repository->save($settings_dto);
            Logger::info("SaveFrontendSettingsUseCase::execute - Repository save result: " . ($success ? 'SUCCESS' : 'FAILED'));
            
            if ($success) {
                Logger::info("SaveFrontendSettingsUseCase::execute - Settings saved successfully");
                return Result::success('Ustawienia warstwy frontendowej zostały zapisane pomyślnie');
            } else {
                Logger::error("SaveFrontendSettingsUseCase::execute - Failed to save settings");
                return Result::failure('Błąd podczas zapisywania ustawień');
            }
            
        } catch (Exception $e) {
            Logger::error("SaveFrontendSettingsUseCase::execute - Exception: " . $e->getMessage());
            Logger::error("SaveFrontendSettingsUseCase::execute - Exception trace: " . $e->getTraceAsString());
            return Result::failure('Błąd systemu: ' . $e->getMessage());
        }
    }
    
    /**
     * Validate and sanitize form data
     */
    private function validateAndSanitizeFormData(array $form_data): ?array {
        Logger::info("SaveFrontendSettingsUseCase::validateAndSanitizeFormData - Validating form data");
        Logger::info("SaveFrontendSettingsUseCase::validateAndSanitizeFormData - Starting validation, checking selected_types first");
        
        $validated = [];
        
        // Validate selected types
        Logger::info("SaveFrontendSettingsUseCase::validateAndSanitizeFormData - Checking if selected_types is set and is array");
        if (!isset($form_data['selected_types']) || !is_array($form_data['selected_types'])) {
            Logger::error("SaveFrontendSettingsUseCase::validateAndSanitizeFormData - Invalid selected_types - not set or not array");
            Logger::error("SaveFrontendSettingsUseCase::validateAndSanitizeFormData - selected_types isset: " . (isset($form_data['selected_types']) ? 'true' : 'false'));
            Logger::error("SaveFrontendSettingsUseCase::validateAndSanitizeFormData - selected_types is_array: " . (isset($form_data['selected_types']) && is_array($form_data['selected_types']) ? 'true' : 'false'));
            return null;
        }
        Logger::info("SaveFrontendSettingsUseCase::validateAndSanitizeFormData - selected_types validation passed - is set and is array");
        
        Logger::info("SaveFrontendSettingsUseCase::validateAndSanitizeFormData - Getting valid PropertyType enum values");
        $valid_property_types = array_map(fn($type) => $type->value, PropertyType::cases());
        Logger::info("SaveFrontendSettingsUseCase::validateAndSanitizeFormData - Valid property types: " . implode(', ', $valid_property_types));
        Logger::info("SaveFrontendSettingsUseCase::validateAndSanitizeFormData - Received selected_types: " . implode(', ', $form_data['selected_types']));
        
        Logger::info("SaveFrontendSettingsUseCase::validateAndSanitizeFormData - Sanitizing and filtering selected types");
        $validated['selected_types'] = array_filter(
            array_map('sanitize_text_field', $form_data['selected_types']),
            fn($type) => in_array($type, $valid_property_types)
        );
        Logger::info("SaveFrontendSettingsUseCase::validateAndSanitizeFormData - After filtering, validated selected_types: " . implode(', ', $validated['selected_types']));
        
        if (empty($validated['selected_types'])) {
            Logger::error("SaveFrontendSettingsUseCase::validateAndSanitizeFormData - No valid property types selected after filtering");
            return null;
        }
        Logger::info("SaveFrontendSettingsUseCase::validateAndSanitizeFormData - selected_types validation completed successfully");
        
        // Validate primary color
        Logger::info("SaveFrontendSettingsUseCase::validateAndSanitizeFormData - Validating primary_color");
        $primary_color = sanitize_text_field($form_data['primary_color'] ?? '#007cba');
        Logger::info("SaveFrontendSettingsUseCase::validateAndSanitizeFormData - Sanitized primary_color: " . $primary_color);
        
        if (!preg_match('/^#[a-fA-F0-9]{6}$/', $primary_color)) {
            Logger::error("SaveFrontendSettingsUseCase::validateAndSanitizeFormData - Invalid color format: " . $primary_color . ", using default #007cba");
            $primary_color = '#007cba';
        } else {
            Logger::info("SaveFrontendSettingsUseCase::validateAndSanitizeFormData - primary_color format validation passed");
        }
        $validated['primary_color'] = $primary_color;
        Logger::info("SaveFrontendSettingsUseCase::validateAndSanitizeFormData - Final primary_color: " . $validated['primary_color']);
        
        // Validate visible columns
        Logger::info("SaveFrontendSettingsUseCase::validateAndSanitizeFormData - Validating visible_columns");
        if (isset($form_data['visible_columns']) && is_array($form_data['visible_columns'])) {
            Logger::info("SaveFrontendSettingsUseCase::validateAndSanitizeFormData - visible_columns is set and is array, count: " . count($form_data['visible_columns']));
            Logger::info("SaveFrontendSettingsUseCase::validateAndSanitizeFormData - Received visible_columns: " . implode(', ', $form_data['visible_columns']));
            
            $available_columns = FrontendSettingsDto::getAllAvailableColumns();
            Logger::info("SaveFrontendSettingsUseCase::validateAndSanitizeFormData - Available columns: " . implode(', ', $available_columns));
            
            $validated['visible_columns'] = array_filter(
                array_map('sanitize_text_field', $form_data['visible_columns']),
                fn($column) => in_array($column, $available_columns)
            );
            Logger::info("SaveFrontendSettingsUseCase::validateAndSanitizeFormData - After filtering, validated visible_columns: " . implode(', ', $validated['visible_columns']));
        } else {
            Logger::info("SaveFrontendSettingsUseCase::validateAndSanitizeFormData - visible_columns not set or not array, using empty array");
            $validated['visible_columns'] = [];
        }
        
        // Validate column names
        Logger::info("SaveFrontendSettingsUseCase::validateAndSanitizeFormData - Validating column_names");
        $validated['column_names'] = [];
        if (isset($form_data['column_names']) && is_array($form_data['column_names'])) {
            Logger::info("SaveFrontendSettingsUseCase::validateAndSanitizeFormData - column_names is set and is array, count: " . count($form_data['column_names']));
            $available_columns = FrontendSettingsDto::getAllAvailableColumns();
            $validated_count = 0;
            
            foreach ($form_data['column_names'] as $column => $name) {
                $column = sanitize_text_field($column);
                $sanitized_name = sanitize_text_field($name);
                Logger::info("SaveFrontendSettingsUseCase::validateAndSanitizeFormData - Processing column: " . $column . " => " . $sanitized_name);
                
                if (in_array($column, $available_columns)) {
                    $validated['column_names'][$column] = $sanitized_name;
                    $validated_count++;
                    Logger::info("SaveFrontendSettingsUseCase::validateAndSanitizeFormData - Column " . $column . " validated successfully");
                } else {
            Logger::error("SaveFrontendSettingsUseCase::validateAndSanitizeFormData - Column " . $column . " not in available columns, skipping");
                }
            }
            Logger::info("SaveFrontendSettingsUseCase::validateAndSanitizeFormData - Validated " . $validated_count . " column names");
        } else {
            Logger::info("SaveFrontendSettingsUseCase::validateAndSanitizeFormData - column_names not set or not array");
        }
        
        // Merge with defaults if empty
        if (empty($validated['column_names'])) {
            Logger::info("SaveFrontendSettingsUseCase::validateAndSanitizeFormData - column_names is empty, using defaults");
            $validated['column_names'] = FrontendSettingsDto::getDefaultColumnNames();
            Logger::info("SaveFrontendSettingsUseCase::validateAndSanitizeFormData - Default column names applied, count: " . count($validated['column_names']));
        }
        
        Logger::info("SaveFrontendSettingsUseCase::validateAndSanitizeFormData - Validation completed successfully");
        Logger::info("SaveFrontendSettingsUseCase::validateAndSanitizeFormData - Final validated data summary:");
        Logger::info("SaveFrontendSettingsUseCase::validateAndSanitizeFormData - - selected_types count: " . count($validated['selected_types']));
        Logger::info("SaveFrontendSettingsUseCase::validateAndSanitizeFormData - - primary_color: " . $validated['primary_color']);
        Logger::info("SaveFrontendSettingsUseCase::validateAndSanitizeFormData - - visible_columns count: " . count($validated['visible_columns']));
        Logger::info("SaveFrontendSettingsUseCase::validateAndSanitizeFormData - - column_names count: " . count($validated['column_names']));
        
        return $validated;
    }
    
    /**
     * Create FrontendSettingsDto from validated data
     */
    private function createSettingsDto(array $validated_data): FrontendSettingsDto {
        // Convert string values to PropertyType enums
        $selected_types = array_map(
            fn($type_string) => PropertyType::from($type_string),
            $validated_data['selected_types']
        );
        
        return new FrontendSettingsDto(
            selected_types: $selected_types,
            primary_color: $validated_data['primary_color'],
            visible_columns: $validated_data['visible_columns'],
            column_names: $validated_data['column_names']
        );
    }
}