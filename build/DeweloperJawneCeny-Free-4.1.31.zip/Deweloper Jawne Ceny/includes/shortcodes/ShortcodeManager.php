<?php

if (!defined('ABSPATH')) {
    exit;
}

/**
 * Shortcode Manager
 * Handles registration and management of plugin shortcodes
 */
class ShortcodeManager {
    
    public function __construct() {
        add_action('init', [$this, 'register_shortcodes']);
    }
    
    /**
     * Register all plugin shortcodes
     */
    public function register_shortcodes() {
        // Register resources list shortcode
        add_shortcode('resources_list', [ResourcesListShortcode::class, 'handle']);
    }
    
    /**
     * Remove all plugin shortcodes (for cleanup/deactivation)
     */
    public static function remove_shortcodes() {
        remove_shortcode('resources_list');
    }
}