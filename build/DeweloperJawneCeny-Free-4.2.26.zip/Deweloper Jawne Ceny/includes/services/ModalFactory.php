<?php

if (!defined('ABSPATH')) {
    exit;
}

/**
 * Modal Factory - Centralized factory for creating modal components
 * Implements Factory Pattern with Dependency Injection for better testability and maintainability
 */
class ModalFactory {

    private $resourceModal;
    private $investmentModal;
    private $historyModal;

    public function __construct(
        ResourceModal $resourceModal,
        InvestmentModal $investmentModal,
        HistoryModal $historyModal
    ) {
        $this->resourceModal = $resourceModal;
        $this->investmentModal = $investmentModal;
        $this->historyModal = $historyModal;
    }

    /**
     * Get ResourceModal instance
     */
    public function getResourceModal(): ResourceModal {
        return $this->resourceModal;
    }

    /**
     * Get InvestmentModal instance
     */
    public function getInvestmentModal(): InvestmentModal {
        return $this->investmentModal;
    }

    /**
     * Get HistoryModal instance
     */
    public function getHistoryModal(): HistoryModal {
        return $this->historyModal;
    }

    /**
     * Create all modals at once - for backward compatibility
     */
    public function createAllModals(): array {
        return [
            'resource' => $this->getResourceModal(),
            'investment' => $this->getInvestmentModal(),
            'history' => $this->getHistoryModal()
        ];
    }
}