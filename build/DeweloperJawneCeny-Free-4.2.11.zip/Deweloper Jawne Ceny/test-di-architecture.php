<?php
/**
 * Test script dla architektury DI
 * Symuluje środowisko WordPress i testuje czy DI Container działa poprawnie
 */

// Symulacja WordPress environment
if (!defined('ABSPATH')) {
    define('ABSPATH', '/tmp/wordpress/');
}

// Podstawowe stałe
define('PLUGIN_DIR', __DIR__ . '/');
define('PLUGIN_URL', 'http://localhost/plugin/');
define('DB_VERSION', '1.7');
define('VERSION', '4.2.10');

// Mock WordPress functions
function admin_url($path) { return 'http://localhost/wp-admin/' . $path; }
function plugin_dir_path($file) { return dirname($file) . '/'; }
function plugin_dir_url($file) { return 'http://localhost/plugin/'; }
function wp_create_nonce($action) { return 'test_nonce_12345'; }
function add_action($hook, $callback, $priority = 10, $args = 1) {
    echo "✅ Hook registered: $hook\n";
}
function add_menu_page($title, $menu, $cap, $slug, $callback, $icon = '', $pos = null) {
    echo "✅ Menu page registered: $title ($slug)\n";
}
function add_submenu_page($parent, $title, $menu, $cap, $slug, $callback) {
    echo "✅ Submenu page registered: $title ($slug)\n";
}
function wp_enqueue_script($handle, $src, $deps = [], $ver = false, $footer = false) {
    echo "✅ Script enqueued: $handle\n";
}
function wp_enqueue_style($handle, $src, $deps = [], $ver = false, $media = 'all') {
    echo "✅ Style enqueued: $handle\n";
}
function wp_localize_script($handle, $name, $data) {
    echo "✅ Script localized: $handle -> $name\n";
}

echo "=== TEST ARCHITEKTURY DI CONTAINER ===\n\n";

try {
    echo "1. Ładowanie dependencies...\n";

    // Load DI52 Library
    require_once PLUGIN_DIR . 'includes/vendor/di52/src/ContainerException.php';
    require_once PLUGIN_DIR . 'includes/vendor/di52/src/NotFoundException.php';
    require_once PLUGIN_DIR . 'includes/vendor/di52/src/NestedParseError.php';
    require_once PLUGIN_DIR . 'includes/vendor/di52/src/Builders/BuilderInterface.php';
    require_once PLUGIN_DIR . 'includes/vendor/di52/src/Builders/ReinitializableBuilderInterface.php';
    require_once PLUGIN_DIR . 'includes/vendor/di52/src/Builders/Parameter.php';
    require_once PLUGIN_DIR . 'includes/vendor/di52/src/Builders/ValueBuilder.php';
    require_once PLUGIN_DIR . 'includes/vendor/di52/src/Builders/ClosureBuilder.php';
    require_once PLUGIN_DIR . 'includes/vendor/di52/src/Builders/CallableBuilder.php';
    require_once PLUGIN_DIR . 'includes/vendor/di52/src/Builders/ClassBuilder.php';
    require_once PLUGIN_DIR . 'includes/vendor/di52/src/Builders/Resolver.php';
    require_once PLUGIN_DIR . 'includes/vendor/di52/src/Builders/Factory.php';
    require_once PLUGIN_DIR . 'includes/vendor/di52/src/Container.php';
    require_once PLUGIN_DIR . 'includes/vendor/di52/src/ServiceProvider.php';
    require_once PLUGIN_DIR . 'includes/vendor/di52/src/App.php';

    echo "✅ DI52 library loaded\n";

    // Load helpers
    require_once PLUGIN_DIR . 'includes/helpers/PremiumHelper.php';
    require_once PLUGIN_DIR . 'includes/helpers/Logger.php';

    // Load DI Container
    require_once PLUGIN_DIR . 'includes/core/DIContainer.php';
    echo "✅ DIContainer loaded\n";

    echo "\n2. Testowanie inicjalizacji DI Container...\n";

    // Initialize DI Container
    $container = DIContainer::init();
    echo "✅ DIContainer initialized\n";

    // Check if container is properly initialized
    if (DIContainer::isInitialized()) {
        echo "✅ DIContainer is initialized\n";
    } else {
        echo "❌ DIContainer initialization failed\n";
    }

    // Get stats
    $stats = DIContainer::getStats();
    echo "✅ DIContainer stats: " . print_r($stats, true) . "\n";

    echo "\n3. Testowanie loading kolejnych warstw...\n";

    // Load required classes for testing
    require_once PLUGIN_DIR . 'includes/config/TableNames.php';
    require_once PLUGIN_DIR . 'includes/enums/PublicationStatus.php';
    require_once PLUGIN_DIR . 'includes/enums/TriggerType.php';
    require_once PLUGIN_DIR . 'includes/enums/ResourceStatus.php';
    require_once PLUGIN_DIR . 'includes/enums/PropertyType.php';

    // DTO classes
    require_once PLUGIN_DIR . 'includes/dto/ModelDto.php';
    require_once PLUGIN_DIR . 'includes/dto/ResourceDto.php';
    require_once PLUGIN_DIR . 'includes/dto/PriceHistoryDto.php';
    require_once PLUGIN_DIR . 'includes/dto/PublicationHistoryDto.php';
    require_once PLUGIN_DIR . 'includes/dto/InvestmentDto.php';
    require_once PLUGIN_DIR . 'includes/dto/SupplierDto.php';
    require_once PLUGIN_DIR . 'includes/dto/XmlResourceDto.php';

    echo "✅ Basic classes loaded\n";

    echo "\n4. Testowanie repositories (Infrastructure layer)...\n";

    // Mock $wpdb global
    $GLOBALS['wpdb'] = (object) [
        'prefix' => 'wp_',
        'get_charset_collate' => function() { return 'utf8mb4_unicode_ci'; }
    ];

    // Load and test repositories
    require_once PLUGIN_DIR . 'includes/repositories/SettingsRepository.php';
    require_once PLUGIN_DIR . 'includes/repositories/DeveloperRepository.php';
    require_once PLUGIN_DIR . 'includes/repositories/InvestmentRepository.php';
    require_once PLUGIN_DIR . 'includes/repositories/ResourceRepository.php';
    require_once PLUGIN_DIR . 'includes/repositories/PriceHistoryRepository.php';
    require_once PLUGIN_DIR . 'includes/repositories/PublicationHistoryRepository.php';
    require_once PLUGIN_DIR . 'includes/repositories/XmlResourceRepository.php';

    // Test repository singletons
    $repo1 = DIContainer::get(ResourceRepository::class);
    $repo2 = DIContainer::get(ResourceRepository::class);

    if ($repo1 === $repo2) {
        echo "✅ Repository singleton works correctly\n";
    } else {
        echo "❌ Repository singleton failed\n";
    }

    echo "\n5. Testowanie Use Cases (Domain layer)...\n";

    // Load Use Cases
    $useCaseFiles = [
        'includes/UseCases/Resource/GetAllResourcesUseCase.php',
        'includes/UseCases/Resource/GetResourcesForFrontendUseCase.php',
        'includes/UseCases/Publication/GetPublicationHistoryUseCase.php',
        'includes/UseCases/Developer/GetDeveloperInfoUseCase.php',
        'includes/UseCases/Investment/GetInvestmentUseCase.php'
    ];

    foreach ($useCaseFiles as $file) {
        if (file_exists(PLUGIN_DIR . $file)) {
            require_once PLUGIN_DIR . $file;
            echo "✅ Loaded: " . basename($file) . "\n";
        }
    }

    // Test Use Case creation through DI
    $useCase = DIContainer::get(GetAllResourcesUseCase::class);
    echo "✅ GetAllResourcesUseCase created through DI\n";

    echo "\n6. Testowanie Services (Application layer)...\n";

    // Load services
    require_once PLUGIN_DIR . 'includes/services/DateHelper.php';
    require_once PLUGIN_DIR . 'includes/services/FileManager.php';
    require_once PLUGIN_DIR . 'includes/services/CSVFormatter.php';
    require_once PLUGIN_DIR . 'includes/services/XMLFormatter.php';

    // Test service singleton
    $service1 = DIContainer::get(DateHelper::class);
    $service2 = DIContainer::get(DateHelper::class);

    if ($service1 === $service2) {
        echo "✅ Service singleton works correctly\n";
    } else {
        echo "❌ Service singleton failed\n";
    }

    echo "\n7. Testowanie ModalFactory...\n";

    // Load modal classes
    require_once PLUGIN_DIR . 'includes/views/admin/components/UJC_Admin_Page.php';
    require_once PLUGIN_DIR . 'includes/views/admin/components/ResourceModal.php';
    require_once PLUGIN_DIR . 'includes/views/admin/components/InvestmentModal.php';
    require_once PLUGIN_DIR . 'includes/views/admin/components/HistoryModal.php';

    // Load additional required Use Cases for ModalFactory
    $modalUseCaseFiles = [
        'includes/UseCases/Resource/CreateResourceUseCase.php',
        'includes/UseCases/Resource/UpdateResourceUseCase.php',
        'includes/UseCases/Resource/GetResourceByIdUseCase.php',
        'includes/UseCases/Resource/DeleteResourceUseCase.php',
        'includes/UseCases/Investment/CreateInvestmentUseCase.php',
        'includes/UseCases/Investment/UpdateInvestmentUseCase.php',
        'includes/UseCases/PriceHistory/GetPriceHistoryUseCase.php'
    ];

    foreach ($modalUseCaseFiles as $file) {
        if (file_exists(PLUGIN_DIR . $file)) {
            require_once PLUGIN_DIR . $file;
        }
    }

    require_once PLUGIN_DIR . 'includes/services/ModalFactory.php';

    $modalFactory = DIContainer::get(ModalFactory::class);
    echo "✅ ModalFactory created through DI\n";

    $resourceModal = $modalFactory->getResourceModal();
    echo "✅ ResourceModal created through ModalFactory\n";

    echo "\n8. Testowanie AdminController...\n";

    // Load admin pages
    require_once PLUGIN_DIR . 'includes/views/admin/pages/SupplierDataPage.php';
    require_once PLUGIN_DIR . 'includes/views/admin/pages/ResourcesPage.php';
    require_once PLUGIN_DIR . 'includes/views/admin/pages/PublicationPage.php';

    require_once PLUGIN_DIR . 'includes/controllers/AdminController.php';

    $adminController = DIContainer::get(AdminController::class);
    echo "✅ AdminController created through DI\n";

    echo "\n=== WSZYSTKIE TESTY PRZESZŁY POMYŚLNIE! ===\n";
    echo "🎉 Architektura DI działa poprawnie!\n\n";

    // Performance test
    echo "9. Test performance DI Container...\n";
    $startTime = microtime(true);
    for ($i = 0; $i < 100; $i++) {
        DIContainer::get(ResourceRepository::class);
    }
    $endTime = microtime(true);
    $totalTime = ($endTime - $startTime) * 1000;
    echo "✅ 100 wywołań DIContainer::get() w {$totalTime}ms\n";

} catch (Exception $e) {
    echo "\n❌ BŁĄD: " . $e->getMessage() . "\n";
    echo "Stack trace:\n" . $e->getTraceAsString() . "\n";
} catch (Error $e) {
    echo "\n❌ FATAL ERROR: " . $e->getMessage() . "\n";
    echo "Stack trace:\n" . $e->getTraceAsString() . "\n";
}