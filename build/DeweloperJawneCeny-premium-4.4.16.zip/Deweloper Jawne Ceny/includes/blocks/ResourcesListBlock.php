<?php

if (!defined('ABSPATH')) {
    exit;
}

class ResourcesListBlock {

    public static function render($attributes, $content) {
        Logger::info("ResourcesListBlock: render started with attributes: " . print_r($attributes, true));

        // Parse and validate attributes with defaults
        $parsed_attributes = self::parseAttributes($attributes);

        // Get property types for filtering
        $selected_types = [];
        foreach ($parsed_attributes['selectedTypes'] as $type_string) {
            try {
                $selected_types[] = PropertyType::from($type_string);
            } catch (ValueError $e) {
                Logger::error("Invalid PropertyType in block: {$type_string}");
            }
        }

        // If no valid types, use default
        if (empty($selected_types)) {
            $selected_types = [PropertyType::RESIDENTIAL_UNIT];
        }

        // Get resources using frontend UseCase with filtering
        $frontend_use_case = DIContainer::get(GetResourcesForFrontendUseCase::class);
        $resources = $frontend_use_case->execute($selected_types);
        Logger::info("ResourcesListBlock: Got " . count($resources) . " resources");

        if (empty($resources)) {
            return '<div class="ujc-no-resources">Brak dostępnych zasobów.</div>';
        }

        // Prepare column configuration
        $visible_columns = $parsed_attributes['visibleColumns'];
        $column_names = self::buildColumnNames($visible_columns, $parsed_attributes['columnNames']);

        // Apply column ordering
        $ordered_columns = self::applyColumnOrdering($visible_columns, $parsed_attributes['columnOrder']);

        // Prepare styling options
        $styling_options = self::buildStylingOptions($parsed_attributes);

        // Use ResourceTableRenderer for consistent output
        return ResourceTableRenderer::renderTable(
            $resources,
            $ordered_columns,
            $column_names,
            $styling_options,
            $parsed_attributes['detailPageUrl'],
            'resources-list-block'  // Different container class for block
        );
    }

    /**
     * Parse and validate block attributes with sensible defaults
     */
    private static function parseAttributes(array $attributes): array {
        $defaults = [
            'visibleColumns' => ResourceTableRenderer::getDefaultColumns(),
            'columnOrder' => ResourceTableRenderer::getDefaultColumns(),
            'columnNames' => [],
            'selectedTypes' => ['residential_unit'],
            'headerBgColor' => '#f9f9f9',
            'headerTextColor' => '#333333',
            'textColor' => '#333333',
            'hoverBgColor' => '#f5f5f5',
            'headerFontFamily' => 'inherit',
            'contentFontFamily' => 'inherit',
            'detailPageUrl' => '',
            'historiaBtnText' => 'Historia',
            'historiaBtnBgColor' => '#007cba',
            'historiaBtnTextColor' => '#ffffff',
            'kartaBtnText' => 'Karta lokalu',
            'kartaBtnBgColor' => '#007cba',
            'kartaBtnTextColor' => '#ffffff'
        ];

        // Merge with defaults and validate
        $parsed = array_merge($defaults, $attributes);

        // Ensure arrays are arrays
        if (!is_array($parsed['visibleColumns'])) {
            $parsed['visibleColumns'] = $defaults['visibleColumns'];
        }
        if (!is_array($parsed['columnOrder'])) {
            $parsed['columnOrder'] = $defaults['columnOrder'];
        }
        if (!is_array($parsed['selectedTypes'])) {
            $parsed['selectedTypes'] = $defaults['selectedTypes'];
        }
        if (!is_array($parsed['columnNames'])) {
            $parsed['columnNames'] = [];
        }

        // Validate columns against available columns
        $available_columns = ResourceTableRenderer::getAvailableColumns();
        $parsed['visibleColumns'] = array_intersect($parsed['visibleColumns'], $available_columns);
        $parsed['columnOrder'] = array_intersect($parsed['columnOrder'], $available_columns);

        // Ensure at least one column is visible
        if (empty($parsed['visibleColumns'])) {
            $parsed['visibleColumns'] = [ResourceDto::FIELD_NR_LOKALU, ResourceDto::FIELD_CENA_CALKOWITA];
        }

        Logger::info("ResourcesListBlock: Parsed attributes: " . print_r($parsed, true));
        return $parsed;
    }

    /**
     * Build column names array combining defaults with custom names
     */
    private static function buildColumnNames(array $visible_columns, array $custom_names): array {
        $default_names = ResourceTableRenderer::getDefaultColumnNames();
        $column_names = [];

        foreach ($visible_columns as $column) {
            // Use custom name if provided, otherwise default
            if (!empty($custom_names[$column])) {
                $column_names[$column] = $custom_names[$column];
            } elseif (isset($default_names[$column])) {
                $column_names[$column] = $default_names[$column];
            } else {
                $column_names[$column] = ucfirst(str_replace('_', ' ', $column));
            }
        }

        return $column_names;
    }

    /**
     * Apply column ordering based on user preferences
     */
    private static function applyColumnOrdering(array $visible_columns, array $column_order): array {
        // Start with the order specified by user
        $ordered = array_intersect($column_order, $visible_columns);

        // Add any visible columns not in the order (append to end)
        $missing = array_diff($visible_columns, $ordered);

        return array_merge($ordered, $missing);
    }

    /**
     * Build styling options array for ResourceTableRenderer
     */
    private static function buildStylingOptions(array $attributes): array {
        return [
            'header_bg_color' => $attributes['headerBgColor'],
            'header_text_color' => $attributes['headerTextColor'],
            'text_color' => $attributes['textColor'],
            'hover_bg_color' => $attributes['hoverBgColor'],
            'header_font_family' => $attributes['headerFontFamily'],
            'content_font_family' => $attributes['contentFontFamily'],
            'historia_btn_text' => $attributes['historiaBtnText'],
            'historia_btn_bg_color' => $attributes['historiaBtnBgColor'],
            'historia_btn_text_color' => $attributes['historiaBtnTextColor'],
            'karta_btn_text' => $attributes['kartaBtnText'],
            'karta_btn_bg_color' => $attributes['kartaBtnBgColor'],
            'karta_btn_text_color' => $attributes['kartaBtnTextColor']
        ];
    }
}