<?php

if (!defined('ABSPATH')) {
    exit;
}

class InvestmentRepository {
    
    /**
     * Get investment data as model
     */
    public function read(): ?InvestmentDto {
        $table = TableNames::getInvestmentInfo();        
        global $wpdb;
        $data = $wpdb->get_row($wpdb->prepare("SELECT * FROM `{$table}` LIMIT 1"), ARRAY_A);
        
        return $data ? InvestmentDto::databaseToModel($data) : null;
    }
    
    /**
     * Create new investment
     */
    public function create(InvestmentDto $dto): int {
        $table = TableNames::getInvestmentInfo();        
        global $wpdb;
        
        Logger::info('UJC: InvestmentRepository::create() started');
        Logger::info('UJC: Table name: ' . $table);
        
        $data = $dto->modelToDatabase();
        Logger::info('UJC: Data to insert: ' . print_r($data, true));
        
        $result = $wpdb->insert($table, $data);
        Logger::info('UJC: Insert result: ' . ($result !== false ? 'SUCCESS' : 'FAILED'));
        
        if ($result === false) {
            Logger::error('UJC: Insert failed. Last error: ' . $wpdb->last_error);
            Logger::error('UJC: Last query: ' . $wpdb->last_query);
            throw new Exception('Failed to create investment: ' . $wpdb->last_error);
        }
        
        $insert_id = $wpdb->insert_id;
        Logger::info('UJC: Created investment with ID: ' . $insert_id);
        
        return $insert_id;
    }
    
    /**
     * Update existing investment
     */
    public function update(InvestmentDto $dto, int $id): void {
        $table = TableNames::getInvestmentInfo();        
        global $wpdb;
        
        Logger::info('UJC: InvestmentRepository::update() started for ID: ' . $id);
        Logger::info('UJC: Table name: ' . $table);
        
        $data = $dto->modelToDatabase();
        Logger::info('UJC: Data to update: ' . print_r($data, true));
        
        $result = $wpdb->update($table, $data, ['id' => $id]);
        Logger::info('UJC: Update result: ' . ($result !== false ? 'SUCCESS (rows affected: ' . $result . ')' : 'FAILED'));
        
        if ($result === false) {
            Logger::error('UJC: Update failed. Last error: ' . $wpdb->last_error);
            Logger::error('UJC: Last query: ' . $wpdb->last_query);
            throw new Exception('Failed to update investment: ' . $wpdb->last_error);
        }
        
        Logger::info('UJC: Investment update completed successfully');
    }
}