<?php
if (!defined('ABSPATH')) {
    exit;
}

use lucatume\DI52\Container;

/**
 * Dependency Injection Container for UJC Plugin
 * Implements layered architecture: Infrastructure -> Domain -> Application -> Presentation
 */
class DIContainer {
    private static $container = null;

    /**
     * Initialize DI Container with all services
     */
    public static function init() {
        if (self::$container === null) {
            self::$container = new Container();
            Logger::info('DIContainer: Initializing DI Container');

            self::registerInfrastructure();
            self::registerDomain();
            self::registerApplication();
            self::registerPresentation();

            Logger::info('DIContainer: All services registered');
        }
        return self::$container;
    }

    /**
     * Get service from container
     */
    public static function get($abstract) {
        if (self::$container === null) {
            self::init();
        }
        Logger::info("DIContainer: Getting service: {$abstract}");
        return self::$container->get($abstract);
    }

    /**
     * INFRASTRUCTURE LAYER - Repositories jako singletony
     * Dostęp do bazy danych, zewnętrznych APIs, filesystem
     */
    private static function registerInfrastructure() {
        $c = self::$container;
        Logger::info('DIContainer: Registering Infrastructure layer');

        // Wszystkie repositories jako singletony - jedna instancja w całej aplikacji
        $c->singleton(ResourceRepository::class);
        $c->singleton(PriceHistoryRepository::class);
        $c->singleton(PublicationHistoryRepository::class);
        $c->singleton(SettingsRepository::class);
        $c->singleton(DeveloperRepository::class);
        $c->singleton(InvestmentRepository::class);
        $c->singleton(XmlResourceRepository::class);

        Logger::info('DIContainer: Infrastructure layer registered (7 repositories)');
    }

    /**
     * DOMAIN LAYER - Use Cases z dependency injection
     * Business logic, główne przypadki użycia aplikacji
     */
    private static function registerDomain() {
        $c = self::$container;
        Logger::info('DIContainer: Registering Domain layer');

        // Use Cases z wstrzykiwaniem repositories
        $c->bind(GetAllResourcesUseCase::class, function() use ($c) {
            return new GetAllResourcesUseCase(
                $c->get(ResourceRepository::class),
                $c->get(PriceHistoryRepository::class)
            );
        });

        $c->bind(GetResourcesForFrontendUseCase::class, function() use ($c) {
            return new GetResourcesForFrontendUseCase(
                $c->get(ResourceRepository::class)
            );
        });

        $c->bind(GetPublicationHistoryUseCase::class, function() use ($c) {
            return new GetPublicationHistoryUseCase(
                $c->get(PublicationHistoryRepository::class)
            );
        });

        // TODO: Dodać pozostałe Use Cases w kolejnych fazach:
        // - SaveResourceUseCase
        // - GenerateFilesUseCase
        // - ImportResourcesUseCase
        // - CreateResourceUseCase
        // - UpdateResourceUseCase

        Logger::info('DIContainer: Domain layer registered (3 Use Cases, more to be added)');
    }

    /**
     * APPLICATION LAYER - Controllers i Services
     * Orchestracja, formatowanie, file operations
     */
    private static function registerApplication() {
        $c = self::$container;
        Logger::info('DIContainer: Registering Application layer');

        // Services jako singletony
        $c->singleton(FileManager::class);
        $c->singleton(CSVFormatter::class);
        $c->singleton(XMLFormatter::class);
        $c->singleton(DateHelper::class);

        // Controllers - będą dodane w fazie 4
        // TODO:
        // $c->singleton(AdminController::class);
        // $c->singleton(ShortcodeManager::class);

        Logger::info('DIContainer: Application layer registered (4 services)');
    }

    /**
     * PRESENTATION LAYER - Admin Pages, UI Components
     * Renderowanie, templates, user interface
     */
    private static function registerPresentation() {
        $c = self::$container;
        Logger::info('DIContainer: Registering Presentation layer');

        // Admin Pages - LAZY LOADING (tworzone tylko gdy potrzebne)
        $c->bind(ResourcesPage::class, function() use ($c) {
            return new ResourcesPage(
                $c->get(GetAllResourcesUseCase::class)
                // TODO: Dodać ModalFactory w fazie 2
            );
        });

        $c->bind(PublicationPage::class, function() use ($c) {
            return new PublicationPage(
                $c->get(GetPublicationHistoryUseCase::class)
            );
        });

        // TODO: Dodać pozostałe strony w kolejnych fazach:
        // - DashboardPage
        // - FrontendManagementPage
        // - SupplierDataPage

        // TODO: Dodać Modals/Components:
        // - InvestmentModal
        // - ResourceModal
        // - HistoryModal

        Logger::info('DIContainer: Presentation layer registered (2 pages, more to be added)');
    }
}