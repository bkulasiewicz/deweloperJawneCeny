<?php

if (!defined('ABSPATH')) {
    exit;
}

/**
 * UseCase for getting resources filtered for government reporting
 * Excludes service premises from the results as they are not reported to the ministry
 */
class GetResourcesForGovernmentUseCase {
    
    private ResourceRepository $resourceRepository;
    private PriceHistoryRepository $priceHistoryRepository;
    
    public function __construct() {
        $this->resourceRepository = new ResourceRepository();
        $this->priceHistoryRepository = new PriceHistoryRepository();
    }
    
    /**
     * Execute the use case
     * @return array Filtered array of PresentableResource objects (excluding service premises)
     */
    public function execute(): array {
        Logger::info("GetResourcesForGovernmentUseCase::execute - Starting");
        
        // Get all ResourceDto objects from repository
        $resources = $this->resourceRepository->readAll();
        Logger::info("GetResourcesForGovernmentUseCase::execute - Got " . count($resources) . " resources from repository");
        
        // Filter out service premises at ResourceDto level before conversion
        $filteredResources = array_filter($resources, function($resource) {
            return $resource->rodzaj_nieruchomosci !== PropertyType::SERVICE_PREMISES;
        });
        Logger::info("GetResourcesForGovernmentUseCase::execute - Filtered to " . count($filteredResources) . " resources (excluding service premises)");
        
        $result = [];
        
        foreach ($filteredResources as $resource) {
            try {
                Logger::info("GetResourcesForGovernmentUseCase::execute - Processing resource ID: " . $resource->id);
                
                Logger::info("GetResourcesForGovernmentUseCase::execute - Getting current prices for resource ID: " . $resource->id);
                $currentPrices = $this->priceHistoryRepository->getCurrentPricesForResource($resource->id);
                Logger::info("GetResourcesForGovernmentUseCase::execute - Got prices for resource ID: " . $resource->id);
                
                // Safe enum conversion with fallback
                Logger::info("GetResourcesForGovernmentUseCase::execute - Converting PropertyType: " . $resource->rodzaj_nieruchomosci->value);
                $propertyTypeDisplay = $resource->rodzaj_nieruchomosci->getDisplayText();
                
                Logger::info("GetResourcesForGovernmentUseCase::execute - Converting ResourceStatus: " . $resource->status->value);
                $statusDisplay = $resource->status->getDisplayText();
                
                Logger::info("GetResourcesForGovernmentUseCase::execute - Creating PresentableResource for ID: " . $resource->id);
                $presentableResource = new PresentableResource(
                    $resource->id,
                    $propertyTypeDisplay,
                    $resource->nr_lokalu,
                    $resource->powierzchnia_uzytkowa,
                    $statusDisplay,
                    $currentPrices->cena_m2,
                    $currentPrices->cena_calkowita,
                    $currentPrices->cena_z_dodatkami,
                    DateHelper::formatForUser($currentPrices->data_zmiany),
                    DateHelper::formatForUser($currentPrices->data_cena_z_dodatkami)
                );
                
                Logger::info("GetResourcesForGovernmentUseCase::execute - Successfully created PresentableResource for ID: " . $resource->id);
                $result[] = $presentableResource;
            } catch (Exception $e) {
                // Skip resources that can't be processed, log error
                Logger::error('GetResourcesForGovernmentUseCase: Failed to process resource ID ' . $resource->id . ': ' . $e->getMessage());
                continue;
            }
        }
        
        Logger::info("GetResourcesForGovernmentUseCase::execute - Processed " . count($result) . " presentable resources for government");
        
        return $result;
    }
}