(function() {
    const { registerBlockType } = wp.blocks;
    const { createElement: el, Fragment } = wp.element;
    const { InspectorControls } = wp.blockEditor;
    const { PanelBody, CheckboxControl, TextControl, SelectControl } = wp.components;

    // Available fields with their default names - all fields from ResourceSingleShortcode
    const AVAILABLE_FIELDS = {
        // Basic information (9 fields)
        'unit_number': 'Numer lokalu',
        'property_type': 'Typ nieruchomości',
        'usable_area': 'Powierzchnia użytkowa',
        'status': 'Status',
        'floor_number': 'Piętro',
        'room_count': 'Pokoje',
        'additional_description': 'Opis',
        'garden_area': 'Ogród',
        'floor_plan_pdf': 'Plan',

        // Prices (3 fields)
        'price_per_m2': 'Cena za m²',
        'total_price': 'Cena całkowita',
        'price_with_extras': 'Cena z dodatkami',

        // Property part component (4 fields)
        'property_part_title': 'Część nieruchomości - tytuł',
        'property_part_designation': 'Część nieruchomości - oznaczenie',
        'property_part_price': 'Część nieruchomości - cena',
        'property_part_price_date': 'Część nieruchomości - data ceny',

        // Belonging room component (4 fields)
        'belonging_room_title': 'Pomieszczenie przynależne - tytuł',
        'belonging_room_designation': 'Pomieszczenie przynależne - oznaczenie',
        'belonging_room_price': 'Pomieszczenie przynależne - cena',
        'belonging_room_price_date': 'Pomieszczenie przynależne - data ceny',

        // Usage right component (3 fields)
        'usage_right_title': 'Prawo użytkowania - tytuł',
        'usage_right_price': 'Prawo użytkowania - cena',
        'usage_right_price_date': 'Prawo użytkowania - data ceny',

        // Other service component (3 fields)
        'other_service_title': 'Inna usługa - tytuł',
        'other_service_price': 'Inna usługa - cena',
        'other_service_price_date': 'Inna usługa - data ceny',

        // Functional (1 field)
        'historia_cen': 'Historia cen'
    };

    // Status display style options
    const STATUS_STYLE_OPTIONS = [
        { label: 'Badge (prostokąt z ramką)', value: 'badge' },
        { label: 'Pill (zaokrąglony)', value: 'pill' },
        { label: 'Highlight (podświetlenie)', value: 'highlight' },
        { label: 'Underline (podkreślenie)', value: 'underline' },
        { label: 'Plain (tylko tekst)', value: 'plain' }
    ];

    // Font weight options for labels
    const FONT_WEIGHT_OPTIONS = [
        { label: 'Normal', value: 'normal' },
        { label: 'Medium (500)', value: '500' },
        { label: 'Semi-bold (600)', value: '600' },
        { label: 'Bold', value: 'bold' }
    ];

    // Helper function for compact color picker
    function CompactColorPicker(attributeName, label, value, onChange) {
        return el('div', { style: { marginBottom: '12px' } },
            el('label', {
                style: {
                    display: 'block',
                    marginBottom: '4px',
                    fontSize: '11px',
                    fontWeight: '600',
                    textTransform: 'uppercase',
                    color: '#1e1e1e'
                }
            }, label),
            el('div', {
                style: {
                    display: 'flex',
                    alignItems: 'center',
                    gap: '8px'
                }
            },
                el('input', {
                    type: 'color',
                    value: value,
                    onChange: (e) => onChange(e.target.value),
                    style: {
                        width: '40px',
                        height: '30px',
                        border: '1px solid #ddd',
                        borderRadius: '4px',
                        cursor: 'pointer'
                    }
                }),
                el('code', {
                    style: {
                        fontSize: '12px',
                        color: '#666',
                        backgroundColor: '#f5f5f5',
                        padding: '4px 8px',
                        borderRadius: '3px',
                        fontFamily: 'monospace'
                    }
                }, value.toUpperCase())
            )
        );
    }

    registerBlockType('jawne-ceny/resource-single', {
        title: 'Szczegóły zasobu',
        description: 'Wyświetla szczegółowe informacje o pojedynczym zasobie wykrytym z URL strony',
        category: 'widgets',
        icon: 'id-alt',
        keywords: ['zasób', 'lokal', 'szczegóły', 'mieszkanie', 'resource'],

        attributes: {
            // Visible fields configuration
            visibleFields: {
                type: 'array',
                default: [
                    'unit_number',
                    'property_type',
                    'usable_area',
                    'room_count',
                    'floor_number',
                    'total_price',
                    'price_per_m2',
                    'historia_cen'
                ]
            },
            fieldLabels: {
                type: 'object',
                default: {}
            },

            // Card styling
            cardBgColor: {
                type: 'string',
                default: '#ffffff'
            },
            cardBorderColor: {
                type: 'string',
                default: '#e1e5e9'
            },
            cardBorderRadius: {
                type: 'string',
                default: '8px'
            },
            cardPadding: {
                type: 'string',
                default: '24px'
            },
            cardTextColor: {
                type: 'string',
                default: '#333333'
            },
            cardLabelColor: {
                type: 'string',
                default: '#666666'
            },
            labelFontWeight: {
                type: 'string',
                default: 'bold'
            },
            fieldSpacing: {
                type: 'string',
                default: '12px'
            },

            // Status styling
            statusDisplayStyle: {
                type: 'string',
                default: 'badge'
            },
            statusAvailableBgColor: {
                type: 'string',
                default: '#28a745'
            },
            statusAvailableTextColor: {
                type: 'string',
                default: '#ffffff'
            },
            statusSoldBgColor: {
                type: 'string',
                default: '#dc3545'
            },
            statusSoldTextColor: {
                type: 'string',
                default: '#ffffff'
            },
            statusReservedBgColor: {
                type: 'string',
                default: '#ffc107'
            },
            statusReservedTextColor: {
                type: 'string',
                default: '#000000'
            },
            statusFontSize: {
                type: 'string',
                default: '0.875em'
            },
            statusPadding: {
                type: 'string',
                default: '4px 8px'
            },
            statusBorderRadius: {
                type: 'string',
                default: '4px'
            },
            statusFontWeight: {
                type: 'string',
                default: 'normal'
            },

            // Button styling
            historiaBtnText: {
                type: 'string',
                default: 'Historia cen'
            },
            historiaBtnBgColor: {
                type: 'string',
                default: '#007cba'
            },
            historiaBtnTextColor: {
                type: 'string',
                default: '#ffffff'
            },
            kartaBtnText: {
                type: 'string',
                default: 'Karta lokalu'
            },
            kartaBtnBgColor: {
                type: 'string',
                default: '#007cba'
            },
            kartaBtnTextColor: {
                type: 'string',
                default: '#ffffff'
            }
        },

        edit: function(props) {
            const { attributes, setAttributes } = props;

            return el(Fragment, {},
                // Auto-detection information banner (top of editor)
                el('div', {
                    style: {
                        padding: '12px 16px',
                        margin: '0 0 16px 0',
                        backgroundColor: '#e7f5ff',
                        borderLeft: '4px solid #007cba',
                        fontSize: '13px',
                        lineHeight: '1.5'
                    }
                },
                    el('strong', { style: { display: 'block', marginBottom: '4px' } }, '💡 Automatyczne wykrywanie zasobu'),
                    el('p', { style: { margin: '0' } },
                        'Numer lokalu jest automatycznie wykrywany z ostatniego segmentu URL strony (np. /mieszkania/A1 → "A1"). Umieść ten blok na stronie z numerem lokalu w adresie URL.'
                    )
                ),

                // InspectorControls (sidebar panels)
                el(InspectorControls, {},

                    // Panel 1: Konfiguracja pól
                    el(PanelBody, {
                        title: 'Konfiguracja pól',
                        initialOpen: true
                    },
                        el('p', { style: { fontSize: '13px', color: '#666', marginTop: '0' } },
                            'Zaznacz pola które mają być wyświetlane:'
                        ),

                        // Checkboxes for visible fields
                        Object.keys(AVAILABLE_FIELDS).map(function(fieldKey) {
                            const isChecked = attributes.visibleFields.includes(fieldKey);

                            return el('div', { key: fieldKey, style: { marginBottom: '8px' } },
                                el(CheckboxControl, {
                                    label: AVAILABLE_FIELDS[fieldKey],
                                    checked: isChecked,
                                    onChange: function(checked) {
                                        let newFields = [...attributes.visibleFields];
                                        if (checked) {
                                            newFields.push(fieldKey);
                                        } else {
                                            newFields = newFields.filter(f => f !== fieldKey);
                                        }
                                        setAttributes({ visibleFields: newFields });
                                    }
                                }),

                                // Custom label input (only for checked fields)
                                isChecked && el(TextControl, {
                                    placeholder: AVAILABLE_FIELDS[fieldKey],
                                    value: attributes.fieldLabels[fieldKey] || '',
                                    onChange: function(value) {
                                        const newLabels = { ...attributes.fieldLabels };
                                        if (value) {
                                            newLabels[fieldKey] = value;
                                        } else {
                                            delete newLabels[fieldKey];
                                        }
                                        setAttributes({ fieldLabels: newLabels });
                                    },
                                    help: 'Własna nazwa pola (opcjonalnie)',
                                    style: { marginLeft: '28px', marginTop: '-8px' }
                                })
                            );
                        })
                    ),

                    // Panel 2: Stylizacja karty
                    el(PanelBody, {
                        title: 'Stylizacja karty',
                        initialOpen: false
                    },
                        CompactColorPicker('cardBgColor', 'Kolor tła', attributes.cardBgColor,
                            (color) => setAttributes({ cardBgColor: color })),

                        CompactColorPicker('cardBorderColor', 'Kolor obramowania', attributes.cardBorderColor,
                            (color) => setAttributes({ cardBorderColor: color })),

                        el(TextControl, {
                            label: 'Zaokrąglenie rogów',
                            value: attributes.cardBorderRadius,
                            onChange: (value) => setAttributes({ cardBorderRadius: value }),
                            placeholder: '8px',
                            help: 'np. 8px, 4px, 0'
                        }),

                        el(TextControl, {
                            label: 'Padding wewnętrzny',
                            value: attributes.cardPadding,
                            onChange: (value) => setAttributes({ cardPadding: value }),
                            placeholder: '24px',
                            help: 'np. 24px, 16px'
                        }),

                        CompactColorPicker('cardTextColor', 'Kolor tekstu', attributes.cardTextColor,
                            (color) => setAttributes({ cardTextColor: color })),

                        CompactColorPicker('cardLabelColor', 'Kolor etykiet', attributes.cardLabelColor,
                            (color) => setAttributes({ cardLabelColor: color })),

                        el(SelectControl, {
                            label: 'Grubość etykiet',
                            value: attributes.labelFontWeight,
                            options: FONT_WEIGHT_OPTIONS,
                            onChange: (value) => setAttributes({ labelFontWeight: value })
                        }),

                        el(TextControl, {
                            label: 'Odstęp między polami',
                            value: attributes.fieldSpacing,
                            onChange: (value) => setAttributes({ fieldSpacing: value }),
                            placeholder: '12px',
                            help: 'np. 12px, 16px, 8px'
                        })
                    ),

                    // Panel 3: Stylizacja statusu
                    el(PanelBody, {
                        title: 'Stylizacja statusu',
                        initialOpen: false
                    },
                        el(SelectControl, {
                            label: 'Styl wyświetlania',
                            value: attributes.statusDisplayStyle,
                            options: STATUS_STYLE_OPTIONS,
                            onChange: (value) => setAttributes({ statusDisplayStyle: value })
                        }),

                        el('hr', { style: { margin: '16px 0' } }),

                        el('h4', { style: { margin: '0 0 12px', fontSize: '13px', fontWeight: '500' } }, 'Status: Dostępny'),
                        CompactColorPicker('statusAvailableBgColor', 'Kolor tła', attributes.statusAvailableBgColor,
                            (color) => setAttributes({ statusAvailableBgColor: color })),
                        CompactColorPicker('statusAvailableTextColor', 'Kolor tekstu', attributes.statusAvailableTextColor,
                            (color) => setAttributes({ statusAvailableTextColor: color })),

                        el('hr', { style: { margin: '16px 0' } }),

                        el('h4', { style: { margin: '0 0 12px', fontSize: '13px', fontWeight: '500' } }, 'Status: Sprzedany'),
                        CompactColorPicker('statusSoldBgColor', 'Kolor tła', attributes.statusSoldBgColor,
                            (color) => setAttributes({ statusSoldBgColor: color })),
                        CompactColorPicker('statusSoldTextColor', 'Kolor tekstu', attributes.statusSoldTextColor,
                            (color) => setAttributes({ statusSoldTextColor: color })),

                        el('hr', { style: { margin: '16px 0' } }),

                        el('h4', { style: { margin: '0 0 12px', fontSize: '13px', fontWeight: '500' } }, 'Status: Zarezerwowany'),
                        CompactColorPicker('statusReservedBgColor', 'Kolor tła', attributes.statusReservedBgColor,
                            (color) => setAttributes({ statusReservedBgColor: color })),
                        CompactColorPicker('statusReservedTextColor', 'Kolor tekstu', attributes.statusReservedTextColor,
                            (color) => setAttributes({ statusReservedTextColor: color })),

                        el('hr', { style: { margin: '16px 0' } }),

                        el('h4', { style: { margin: '0 0 12px', fontSize: '13px', fontWeight: '500' } }, 'Ogólne ustawienia statusu'),
                        el(TextControl, {
                            label: 'Rozmiar czcionki',
                            value: attributes.statusFontSize,
                            onChange: (value) => setAttributes({ statusFontSize: value }),
                            placeholder: '0.875em',
                            help: 'np. 0.875em, 14px'
                        }),

                        el(TextControl, {
                            label: 'Padding',
                            value: attributes.statusPadding,
                            onChange: (value) => setAttributes({ statusPadding: value }),
                            placeholder: '4px 8px',
                            help: 'np. 4px 8px, 6px 12px'
                        }),

                        el(TextControl, {
                            label: 'Zaokrąglenie rogów',
                            value: attributes.statusBorderRadius,
                            onChange: (value) => setAttributes({ statusBorderRadius: value }),
                            placeholder: '4px',
                            help: 'np. 4px, 50px (pill)'
                        }),

                        el(SelectControl, {
                            label: 'Grubość czcionki',
                            value: attributes.statusFontWeight,
                            options: FONT_WEIGHT_OPTIONS,
                            onChange: (value) => setAttributes({ statusFontWeight: value })
                        })
                    ),

                    // Panel 4: Stylizacja przycisków
                    el(PanelBody, {
                        title: 'Stylizacja przycisków',
                        initialOpen: false
                    },
                        el('h4', { style: { margin: '0 0 12px', fontSize: '13px', fontWeight: '500' } }, 'Przycisk "Historia cen"'),
                        el(TextControl, {
                            label: 'Tekst przycisku',
                            value: attributes.historiaBtnText,
                            onChange: (value) => setAttributes({ historiaBtnText: value }),
                            placeholder: 'Historia cen'
                        }),

                        CompactColorPicker('historiaBtnBgColor', 'Kolor tła', attributes.historiaBtnBgColor,
                            (color) => setAttributes({ historiaBtnBgColor: color })),

                        CompactColorPicker('historiaBtnTextColor', 'Kolor tekstu', attributes.historiaBtnTextColor,
                            (color) => setAttributes({ historiaBtnTextColor: color })),

                        el('hr', { style: { margin: '16px 0' } }),

                        el('h4', { style: { margin: '0 0 12px', fontSize: '13px', fontWeight: '500' } }, 'Przycisk "Karta lokalu"'),
                        el(TextControl, {
                            label: 'Tekst przycisku',
                            value: attributes.kartaBtnText,
                            onChange: (value) => setAttributes({ kartaBtnText: value }),
                            placeholder: 'Karta lokalu'
                        }),

                        CompactColorPicker('kartaBtnBgColor', 'Kolor tła', attributes.kartaBtnBgColor,
                            (color) => setAttributes({ kartaBtnBgColor: color })),

                        CompactColorPicker('kartaBtnTextColor', 'Kolor tekstu', attributes.kartaBtnTextColor,
                            (color) => setAttributes({ kartaBtnTextColor: color }))
                    )
                ),

                // Block placeholder in editor
                el('div', {
                    style: {
                        padding: '40px 20px',
                        textAlign: 'center',
                        border: '2px dashed #ccc',
                        borderRadius: '8px',
                        backgroundColor: '#f9f9f9',
                        color: '#666',
                        fontSize: '14px'
                    }
                },
                    el('span', {
                        className: 'dashicons dashicons-id-alt',
                        style: {
                            fontSize: '48px',
                            width: '48px',
                            height: '48px',
                            marginBottom: '12px',
                            display: 'block',
                            margin: '0 auto 12px'
                        }
                    }),
                    el('strong', { style: { display: 'block', marginBottom: '8px', fontSize: '16px' } },
                        'Blok: Szczegóły zasobu'
                    ),
                    el('p', { style: { margin: '0', lineHeight: '1.5' } },
                        'Ten blok wyświetli szczegółowe informacje o zasobie wykrytym z URL strony. ',
                        el('br'),
                        'Liczba widocznych pól: ' + attributes.visibleFields.length
                    )
                )
            );
        },

        save: function() {
            // Dynamic block - rendered server-side
            return null;
        }
    });
})();
