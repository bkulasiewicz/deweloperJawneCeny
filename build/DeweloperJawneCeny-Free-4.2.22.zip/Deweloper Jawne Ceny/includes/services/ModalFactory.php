<?php

if (!defined('ABSPATH')) {
    exit;
}

/**
 * Modal Factory - Centralized factory for creating modal components
 * Implements Factory Pattern with Dependency Injection for better testability and maintainability
 */
class ModalFactory {

    private $resourceModal = null;
    private $investmentModal = null;
    private $historyModal = null;

    // Use Cases injected through DI Container
    private $createResourceUseCase;
    private $updateResourceUseCase;
    private $getResourceByIdUseCase;
    private $deleteResourceUseCase;
    private $createInvestmentUseCase;
    private $updateInvestmentUseCase;
    private $getInvestmentUseCase;
    private $getPriceHistoryUseCase;

    public function __construct(
        CreateResourceUseCase $createResourceUseCase,
        UpdateResourceUseCase $updateResourceUseCase,
        GetResourceByIdUseCase $getResourceByIdUseCase,
        DeleteResourceUseCase $deleteResourceUseCase,
        CreateInvestmentUseCase $createInvestmentUseCase,
        UpdateInvestmentUseCase $updateInvestmentUseCase,
        GetInvestmentUseCase $getInvestmentUseCase,
        GetPriceHistoryUseCase $getPriceHistoryUseCase
    ) {
        $this->createResourceUseCase = $createResourceUseCase;
        $this->updateResourceUseCase = $updateResourceUseCase;
        $this->getResourceByIdUseCase = $getResourceByIdUseCase;
        $this->deleteResourceUseCase = $deleteResourceUseCase;
        $this->createInvestmentUseCase = $createInvestmentUseCase;
        $this->updateInvestmentUseCase = $updateInvestmentUseCase;
        $this->getInvestmentUseCase = $getInvestmentUseCase;
        $this->getPriceHistoryUseCase = $getPriceHistoryUseCase;
    }

    /**
     * Get ResourceModal instance - Singleton pattern within factory
     */
    public function getResourceModal(): ResourceModal {
        if ($this->resourceModal === null) {
            $this->resourceModal = new ResourceModal(
                $this->createResourceUseCase,
                $this->updateResourceUseCase,
                $this->getResourceByIdUseCase,
                $this->deleteResourceUseCase
            );
        }
        return $this->resourceModal;
    }

    /**
     * Get InvestmentModal instance - Singleton pattern within factory
     */
    public function getInvestmentModal(): InvestmentModal {
        if ($this->investmentModal === null) {
            $this->investmentModal = new InvestmentModal(
                $this->createInvestmentUseCase,
                $this->updateInvestmentUseCase,
                $this->getInvestmentUseCase
            );
        }
        return $this->investmentModal;
    }

    /**
     * Get HistoryModal instance - Singleton pattern within factory
     */
    public function getHistoryModal(): HistoryModal {
        if ($this->historyModal === null) {
            $this->historyModal = new HistoryModal(
                $this->getPriceHistoryUseCase
            );
        }
        return $this->historyModal;
    }

    /**
     * Create all modals at once - for backward compatibility
     */
    public function createAllModals(): array {
        return [
            'resource' => $this->getResourceModal(),
            'investment' => $this->getInvestmentModal(),
            'history' => $this->getHistoryModal()
        ];
    }
}