<?php

if (!defined('ABSPATH')) {
    exit;
}

class ResourceDto extends ModelDto {
    
    public const FIELD_ID = 'id';
    public const FIELD_RODZAJ_NIERUCHOMOSCI = 'rodzaj_nieruchomosci';
    public const FIELD_NR_LOKALU = 'nr_lokalu';
    public const FIELD_POWIERZCHNIA_UZYTKOWA = 'powierzchnia_uzytkowa';
    public const FIELD_STATUS = 'status';
    
    public const FIELD_PROPERTY_PART_TYPE = 'property_part_type';
    public const FIELD_PROPERTY_PART_DESIGNATION = 'property_part_designation';
    public const FIELD_PROPERTY_PART_PRICE = 'property_part_price';
    public const FIELD_PROPERTY_PART_PRICE_DATE = 'property_part_price_date';
    
    public const FIELD_BELONGING_ROOM_TYPE = 'belonging_room_type';
    public const FIELD_BELONGING_ROOM_DESIGNATION = 'belonging_room_designation';
    public const FIELD_BELONGING_ROOM_PRICE = 'belonging_room_price';
    public const FIELD_BELONGING_ROOM_PRICE_DATE = 'belonging_room_price_date';
    
    public const FIELD_USAGE_RIGHT_TYPE = 'usage_right_type';
    public const FIELD_USAGE_RIGHT_DESCRIPTION = 'usage_right_description';
    
    public const FIELD_OTHER_SERVICE_TYPE = 'other_service_type';
    public const FIELD_OTHER_SERVICE_DESCRIPTION = 'other_service_description';
    
    public int $id;
    public string $rodzaj_nieruchomosci;
    public string $nr_lokalu;
    public float $powierzchnia_uzytkowa;
    public string $status;
    
    public ?string $property_part_type;
    public ?string $property_part_designation;
    public ?float $property_part_price;
    public ?string $property_part_price_date;
    
    public ?string $belonging_room_type;
    public ?string $belonging_room_designation;
    public ?float $belonging_room_price;
    public ?string $belonging_room_price_date;
    
    public ?string $usage_right_type;
    public ?string $usage_right_description;
    
    public ?string $other_service_type;
    public ?string $other_service_description;
    
    public function __construct(
        int $id,
        string $rodzaj_nieruchomosci,
        string $nr_lokalu,
        float $powierzchnia_uzytkowa,
        string $status,
        ?string $property_part_type = null,
        ?string $property_part_designation = null,
        ?float $property_part_price = null,
        ?string $property_part_price_date = null,
        ?string $belonging_room_type = null,
        ?string $belonging_room_designation = null,
        ?float $belonging_room_price = null,
        ?string $belonging_room_price_date = null,
        ?string $usage_right_type = null,
        ?string $usage_right_description = null,
        ?string $other_service_type = null,
        ?string $other_service_description = null
    ) {
        $this->id = $id;
        $this->rodzaj_nieruchomosci = $rodzaj_nieruchomosci;
        $this->nr_lokalu = $nr_lokalu;
        $this->powierzchnia_uzytkowa = $powierzchnia_uzytkowa;
        $this->status = $status;
        $this->property_part_type = $property_part_type;
        $this->property_part_designation = $property_part_designation;
        $this->property_part_price = $property_part_price;
        $this->property_part_price_date = $property_part_price_date;
        $this->belonging_room_type = $belonging_room_type;
        $this->belonging_room_designation = $belonging_room_designation;
        $this->belonging_room_price = $belonging_room_price;
        $this->belonging_room_price_date = $belonging_room_price_date;
        $this->usage_right_type = $usage_right_type;
        $this->usage_right_description = $usage_right_description;
        $this->other_service_type = $other_service_type;
        $this->other_service_description = $other_service_description;
    }
    
    public static function databaseToModel(array $data): static {
        return new static(
            (int)$data[self::FIELD_ID],
            $data[self::FIELD_RODZAJ_NIERUCHOMOSCI] ?? '',
            $data[self::FIELD_NR_LOKALU] ?? '',
            (float)($data[self::FIELD_POWIERZCHNIA_UZYTKOWA] ?? 0),
            $data[self::FIELD_STATUS] ?? '',
            $data[self::FIELD_PROPERTY_PART_TYPE] ?? null,
            $data[self::FIELD_PROPERTY_PART_DESIGNATION] ?? null,
            isset($data[self::FIELD_PROPERTY_PART_PRICE]) ? (float)$data[self::FIELD_PROPERTY_PART_PRICE] : null,
            $data[self::FIELD_PROPERTY_PART_PRICE_DATE] ?? null,
            $data[self::FIELD_BELONGING_ROOM_TYPE] ?? null,
            $data[self::FIELD_BELONGING_ROOM_DESIGNATION] ?? null,
            isset($data[self::FIELD_BELONGING_ROOM_PRICE]) ? (float)$data[self::FIELD_BELONGING_ROOM_PRICE] : null,
            $data[self::FIELD_BELONGING_ROOM_PRICE_DATE] ?? null,
            $data[self::FIELD_USAGE_RIGHT_TYPE] ?? null,
            $data[self::FIELD_USAGE_RIGHT_DESCRIPTION] ?? null,
            $data[self::FIELD_OTHER_SERVICE_TYPE] ?? null,
            $data[self::FIELD_OTHER_SERVICE_DESCRIPTION] ?? null
        );
    }
    
    public function modelToDatabase(): array {
        return [
            self::FIELD_RODZAJ_NIERUCHOMOSCI => $this->rodzaj_nieruchomosci,
            self::FIELD_NR_LOKALU => $this->nr_lokalu,
            self::FIELD_POWIERZCHNIA_UZYTKOWA => $this->powierzchnia_uzytkowa,
            self::FIELD_STATUS => $this->status,
            self::FIELD_PROPERTY_PART_TYPE => $this->property_part_type,
            self::FIELD_PROPERTY_PART_DESIGNATION => $this->property_part_designation,
            self::FIELD_PROPERTY_PART_PRICE => $this->property_part_price,
            self::FIELD_PROPERTY_PART_PRICE_DATE => $this->property_part_price_date,
            self::FIELD_BELONGING_ROOM_TYPE => $this->belonging_room_type,
            self::FIELD_BELONGING_ROOM_DESIGNATION => $this->belonging_room_designation,
            self::FIELD_BELONGING_ROOM_PRICE => $this->belonging_room_price,
            self::FIELD_BELONGING_ROOM_PRICE_DATE => $this->belonging_room_price_date,
            self::FIELD_USAGE_RIGHT_TYPE => $this->usage_right_type,
            self::FIELD_USAGE_RIGHT_DESCRIPTION => $this->usage_right_description,
            self::FIELD_OTHER_SERVICE_TYPE => $this->other_service_type,
            self::FIELD_OTHER_SERVICE_DESCRIPTION => $this->other_service_description
        ];
    }
    
    /**
     * Create ResourceDto from form data
     * @param ResourceFormData $formData
     * @return static
     */
    public static function fromFormData(ResourceFormData $formData): static {
        return new static(
            id: 0, // ID will be generated by database
            rodzaj_nieruchomosci: $formData->rodzaj_nieruchomosci->value,
            nr_lokalu: $formData->nr_lokalu,
            powierzchnia_uzytkowa: $formData->powierzchnia_uzytkowa,
            status: $formData->status->value,
            property_part_type: $formData->property_part?->type,
            property_part_designation: $formData->property_part?->designation,
            property_part_price: $formData->property_part?->price,
            property_part_price_date: $formData->property_part ? DateHelper::currentDatetime() : null,
            belonging_room_type: $formData->belonging_room?->type,
            belonging_room_designation: $formData->belonging_room?->designation,
            belonging_room_price: $formData->belonging_room?->price,
            belonging_room_price_date: $formData->belonging_room ? DateHelper::currentDatetime() : null,
            usage_right_type: $formData->usage_right?->type,
            usage_right_description: $formData->usage_right?->description,
            other_service_type: $formData->other_service?->type,
            other_service_description: $formData->other_service?->description
        );
    }
    
}