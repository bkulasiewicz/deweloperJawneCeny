<?php

if (!defined('ABSPATH')) {
    exit;
}

class GetResourceByIdUseCase {
    
    private $repository;
    private $price_history_repo;
    
    public function __construct() {
        $this->repository = new ResourceRepository();
        $this->price_history_repo = new PriceHistoryRepository();
    }
    
    public function execute($resource_id) {
        Logger::info("GetResourceByIdUseCase::execute - Starting for resource ID: " . $resource_id);
        
        $resource = $this->repository->readById($resource_id);
        
        if (!$resource) {
            Logger::info("GetResourceByIdUseCase::execute - Resource not found for ID: " . $resource_id);
            return null;
        }
        
        Logger::info("GetResourceByIdUseCase::execute - Found resource: " . $resource->nr_lokalu . " (ID: " . $resource->id . ")");
        
        // Get current prices
        try {
            Logger::info("GetResourceByIdUseCase::execute - Loading current prices for resource ID: " . $resource_id);
            $current_prices = $this->price_history_repo->getCurrentPricesForResource($resource_id);
            Logger::info("GetResourceByIdUseCase::execute - Current prices loaded successfully");
        } catch (Exception $e) {
            Logger::error("GetResourceByIdUseCase::execute - Failed to load current prices: " . $e->getMessage());
            $current_prices = null;
        }
        
        // Return resource data with prices and component fields directly
        Logger::info("GetResourceByIdUseCase::execute - Successfully completed for resource ID: " . $resource_id);
        return [
            'id' => $resource->id,
            'rodzaj_nieruchomosci' => $resource->rodzaj_nieruchomosci,
            'nr_lokalu' => $resource->nr_lokalu,
            'powierzchnia_uzytkowa' => $resource->powierzchnia_uzytkowa,
            'status' => $resource->status,
            'cena_m2' => $current_prices ? $current_prices->cena_m2 : null,
            'cena_calkowita' => $current_prices ? $current_prices->cena_calkowita : null,
            'cena_z_dodatkami' => $current_prices ? $current_prices->cena_z_dodatkami : null,
            'property_part_type' => $resource->property_part_type,
            'property_part_designation' => $resource->property_part_designation,
            'property_part_price' => $resource->property_part_price,
            'property_part_price_date' => $resource->property_part_price_date,
            'belonging_room_type' => $resource->belonging_room_type,
            'belonging_room_designation' => $resource->belonging_room_designation,
            'belonging_room_price' => $resource->belonging_room_price,
            'belonging_room_price_date' => $resource->belonging_room_price_date,
            'usage_right_type' => $resource->usage_right_type,
            'usage_right_description' => $resource->usage_right_description,
            'other_service_type' => $resource->other_service_type,
            'other_service_description' => $resource->other_service_description
        ];
    }
}