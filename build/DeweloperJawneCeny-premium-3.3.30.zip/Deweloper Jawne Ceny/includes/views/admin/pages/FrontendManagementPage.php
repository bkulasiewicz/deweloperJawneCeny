<?php

if (!defined('ABSPATH')) {
    exit;
}

/**
 * Frontend Management Admin Page
 * Simple shortcode generator without backend storage
 */
class FrontendManagementPage {
    
    public function __construct() {
        Logger::info('FrontendManagementPage constructor started');
        
        // Add AJAX handlers  
        add_action('wp_ajax_ujc_reset_frontend_settings', [$this, 'ajax_reset_settings']);
        add_action('wp_ajax_ujc_preview_shortcode', [$this, 'ajax_preview_shortcode']);
        
        Logger::info('FrontendManagementPage constructor completed');
    }
    
    /**
     * Render the frontend management page
     */
    public function render() {
        // Use default settings for display
        $settings = $this->getDefaultSettings();
        
        ?>
        <div class="wrap">
            <div class="page-header">
                <h1>Warstwa Frontendowa</h1>
                <div class="page-actions">
                    <button type="button" class="button button-secondary" id="show-instructions">
                        <span class="dashicons dashicons-editor-help"></span>
                        Instrukcja
                    </button>
                    <button type="button" class="button button-secondary" id="reset-settings">
                        <span class="dashicons dashicons-undo"></span>
                        Przywróć domyślne
                    </button>
                </div>
            </div>
            
            <div class="notice notice-info">
                <p><strong>Konfiguracja widgetów frontendowych</strong></p>
                <p>Skonfiguruj sposób wyświetlania nieruchomości na stronie internetowej i wygeneruj shortcode.</p>
            </div>
            
            <form id="frontend-settings-form" method="post">
                <?php wp_nonce_field('ujc_frontend_settings_nonce', 'nonce'); ?>
                
                <!-- Live Preview Section -->
                <div class="postbox">
                    <div class="postbox-header">
                        <h2>Podgląd na żywo</h2>
                    </div>
                    <div class="inside">
                        <div id="live-preview-container">
                            <div id="preview-loading" style="display: none;">
                                <p>Ładowanie podglądu...</p>
                            </div>
                            <div id="preview-content">
                                <!-- Podgląd będzie wstawiany tutaj przez AJAX -->
                            </div>
                        </div>
                        <p class="description">Zobacz jak będzie wyglądać tabela na stronie. Podgląd aktualizuje się automatycznie po zmianie ustawień.</p>
                    </div>
                </div>
                
                <!-- Configuration Sections -->
                <div class="config-section-grid">
                    <!-- Basic Settings -->
                    <div class="postbox">
                        <div class="postbox-header">
                            <h2>Podstawowe ustawienia</h2>
                        </div>
                        <div class="inside">
                            <div class="setting-group">
                                <label>Typy nieruchomości</label>
                                <?php $this->render_property_types_checkboxes($settings); ?>
                                <p class="description">Wybierz które typy nieruchomości mają być wyświetlane.</p>
                            </div>
                            
                            <div class="setting-group">
                                <label>Widoczne kolumny</label>
                                <?php $this->render_visible_columns_checkboxes($settings); ?>
                                <p class="description">Zaznacz kolumny które mają być wyświetlane w tabeli.</p>
                            </div>
                        </div>
                    </div>
                    
                    <!-- Personalization -->
                    <div class="postbox">
                        <div class="postbox-header">
                            <h2>Personalizacja</h2>
                        </div>
                        <div class="inside">
                            <div class="setting-group">
                                <h4>Nazwy kolumn</h4>
                                <?php $this->render_dynamic_column_names_inputs($settings); ?>
                                <p class="description">Dostosuj nazwy dla zaznaczonych kolumn.</p>
                            </div>
                            
                            <div class="setting-group">
                                <h4>Kolory</h4>
                                <div class="color-inputs-grid">
                                    <div class="color-input">
                                        <label for="header-bg-color">Tło nagłówka</label>
                                        <input type="color" 
                                               id="header-bg-color" 
                                               name="header_bg_color" 
                                               value="<?php echo esc_attr($settings['header_bg_color']); ?>">
                                    </div>
                                    
                                    <div class="color-input">
                                        <label for="header-text-color">Tekst nagłówka</label>
                                        <input type="color" 
                                               id="header-text-color" 
                                               name="header_text_color" 
                                               value="<?php echo esc_attr($settings['header_text_color']); ?>">
                                    </div>
                                    
                                    <div class="color-input">
                                        <label for="button-bg-color">Tło przycisków</label>
                                        <input type="color" 
                                               id="button-bg-color" 
                                               name="button_bg_color" 
                                               value="<?php echo esc_attr($settings['button_bg_color']); ?>">
                                    </div>
                                    
                                    <div class="color-input">
                                        <label for="button-text-color">Tekst przycisków</label>
                                        <input type="color" 
                                               id="button-text-color" 
                                               name="button_text_color" 
                                               value="<?php echo esc_attr($settings['button_text_color']); ?>">
                                    </div>
                                    
                                    <div class="color-input">
                                        <label for="hover-bg-color">Hover wierszy</label>
                                        <input type="color" 
                                               id="hover-bg-color" 
                                               name="hover_bg_color" 
                                               value="<?php echo esc_attr($settings['hover_bg_color']); ?>">
                                    </div>
                                    
                                    <div class="color-input">
                                        <label for="text-color">Kolor tekstu</label>
                                        <input type="color" 
                                               id="text-color" 
                                               name="text_color" 
                                               value="<?php echo esc_attr($settings['text_color']); ?>">
                                    </div>
                                </div>
                            </div>
                            
                            <div class="setting-group">
                                <h4>Czcionki</h4>
                                <div class="font-inputs-grid">
                                    <div class="font-input">
                                        <label for="header-font-family">Czcionka nagłówka</label>
                                        <select id="header-font-family" name="header_font_family">
                                            <option value="inherit" <?php selected($settings['header_font_family'], 'inherit'); ?>>Domyślna</option>
                                            <option value="Arial, sans-serif" <?php selected($settings['header_font_family'], 'Arial, sans-serif'); ?>>Arial</option>
                                            <option value="Helvetica, sans-serif" <?php selected($settings['header_font_family'], 'Helvetica, sans-serif'); ?>>Helvetica</option>
                                            <option value="Georgia, serif" <?php selected($settings['header_font_family'], 'Georgia, serif'); ?>>Georgia</option>
                                            <option value="Times New Roman, serif" <?php selected($settings['header_font_family'], 'Times New Roman, serif'); ?>>Times</option>
                                        </select>
                                    </div>
                                    
                                    <div class="font-input">
                                        <label for="content-font-family">Czcionka treści</label>
                                        <select id="content-font-family" name="content_font_family">
                                            <option value="inherit" <?php selected($settings['content_font_family'], 'inherit'); ?>>Domyślna</option>
                                            <option value="Arial, sans-serif" <?php selected($settings['content_font_family'], 'Arial, sans-serif'); ?>>Arial</option>
                                            <option value="Helvetica, sans-serif" <?php selected($settings['content_font_family'], 'Helvetica, sans-serif'); ?>>Helvetica</option>
                                            <option value="Georgia, serif" <?php selected($settings['content_font_family'], 'Georgia, serif'); ?>>Georgia</option>
                                            <option value="Times New Roman, serif" <?php selected($settings['content_font_family'], 'Times New Roman, serif'); ?>>Times</option>
                                        </select>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                
                <!-- Generated Shortcode Section -->
                <div class="postbox">
                    <div class="postbox-header">
                        <h2>Wygenerowany shortcode</h2>
                    </div>
                    <div class="inside">
                        <div class="shortcode-display">
                            <code id="generated-shortcode"><?php echo esc_html($this->generateShortcode($settings)); ?></code>
                            <button type="button" class="button button-primary" id="copy-shortcode">
                                <span class="dashicons dashicons-admin-page"></span>
                                Kopiuj shortcode
                            </button>
                        </div>
                        <p class="description">Skopiuj powyższy kod i wklej go tam gdzie chcesz wyświetlić tabelę z nieruchomościami.</p>
                    </div>
                </div>
                
            </form>
        </div>
        
        <!-- Instructions Modal -->
        <div id="instructions-modal" class="instructions-modal" style="display: none;">
            <div class="modal-backdrop"></div>
            <div class="modal-content">
                <div class="modal-header">
                    <h2>Instrukcje użycia</h2>
                    <button class="modal-close" id="close-instructions">&times;</button>
                </div>
                <div class="modal-body">
                    <h3>Jak dodać widget na stronę:</h3>
                    <ol>
                        <li><strong>W edytorze Gutenberg:</strong> Dodaj blok "Shortcode" i wklej wygenerowany kod</li>
                        <li><strong>W widżetach:</strong> Dodaj widget "Tekst" lub "HTML" i wklej shortcode</li>
                        <li><strong>W szablonie PHP:</strong> Użyj <code>&lt;?php echo do_shortcode('[shortcode_tutaj]'); ?&gt;</code></li>
                    </ol>
                    
                    <h3>Przykłady użycia:</h3>
                    <ul>
                        <li><code>[resources_list types="residential_unit"]</code> - tylko mieszkania</li>
                        <li><code>[resources_list types="parking_space"]</code> - tylko miejsca postojowe</li>
                        <li><code>[resources_list types="residential_unit,parking_space"]</code> - mieszkania i miejsca postojowe</li>
                    </ul>
                    
                    <div class="notice notice-warning inline">
                        <p><strong>Uwaga:</strong> Po skopiowaniu shortcode sprawdź efekt na stronie. Zmiany stylów będą widoczne natychmiast.</p>
                    </div>
                    
                    <h3>Wskazówki:</h3>
                    <ul>
                        <li>Użyj podglądu na żywo aby zobaczyć jak będzie wyglądać tabela</li>
                        <li>Dostosuj kolory do swojego motywu WordPress</li>
                        <li>Możesz pozostawić puste nazwy kolumn - wtedy nie będą miały nagłówków</li>
                        <li>Przycisk "Historia cen" działa tylko gdy są dostępne dane historyczne</li>
                    </ul>
                </div>
                <div class="modal-footer">
                    <button type="button" class="button button-primary" id="close-instructions-footer">Rozumiem</button>
                </div>
            </div>
        </div>
        
        <?php $this->render_scripts_and_styles(); ?>
        <?php
    }
    
    /**
     * Render property types checkboxes
     */
    private function render_property_types_checkboxes(array $settings) {
        $selected_values = array_map(fn($type) => $type->value, $settings['selected_types']);
        
        echo '<div class="property-types-checkboxes">';
        foreach (PropertyType::cases() as $type) {
            $checked = in_array($type->value, $selected_values) ? 'checked' : '';
            echo '<label>';
            echo '<input type="checkbox" name="selected_types[]" value="' . esc_attr($type->value) . '" ' . $checked . '>';
            echo '<span>' . esc_html($type->getDisplayText()) . '</span>';
            echo '</label><br>';
        }
        echo '</div>';
    }
    
    /**
     * Render visible columns checkboxes
     */
    private function render_visible_columns_checkboxes(array $settings) {
        $available_columns = [
            // Basic information from ResourceDto
            ResourceDto::FIELD_NR_LOKALU,
            ResourceDto::FIELD_RODZAJ_NIERUCHOMOSCI,
            ResourceDto::FIELD_POWIERZCHNIA_UZYTKOWA,
            ResourceDto::FIELD_STATUS,
            
            // Prices from PriceHistory
            PriceHistoryDto::FIELD_CENA_M2,
            PriceHistoryDto::FIELD_CENA_CALKOWITA,
            PriceHistoryDto::FIELD_CENA_Z_DODATKAMI,
            
            // Marketing fields from ResourceDto
            ResourceDto::FIELD_FLOOR_NUMBER,
            ResourceDto::FIELD_ROOM_COUNT,
            ResourceDto::FIELD_ADDITIONAL_DESCRIPTION,
            ResourceDto::FIELD_GARDEN_AREA,
            ResourceDto::FIELD_FLOOR_PLAN_PDF,
            
            // Functional
            ResourcesListShortcode::COLUMN_HISTORIA_CEN
        ];
        
        echo '<div class="visible-columns-checkboxes">';
        foreach ($available_columns as $column) {
            $checked = in_array($column, $settings['visible_columns']) ? 'checked' : '';
            $display_name = $settings['column_names'][$column] ?? ucfirst($column);
            
            echo '<label>';
            echo '<input type="checkbox" name="visible_columns[]" value="' . esc_attr($column) . '" ' . $checked . '>';
            echo '<span>' . esc_html($display_name) . '</span>';
            echo '</label><br>';
        }
        echo '</div>';
    }
    
    /**
     * Render column names input fields (original - for old section)
     */
    private function render_column_names_inputs(array $settings) {
        $available_columns = [
            // Basic information from ResourceDto
            ResourceDto::FIELD_NR_LOKALU,
            ResourceDto::FIELD_RODZAJ_NIERUCHOMOSCI,
            ResourceDto::FIELD_POWIERZCHNIA_UZYTKOWA,
            ResourceDto::FIELD_STATUS,
            
            // Prices from PriceHistory
            PriceHistoryDto::FIELD_CENA_M2,
            PriceHistoryDto::FIELD_CENA_CALKOWITA,
            PriceHistoryDto::FIELD_CENA_Z_DODATKAMI,
            
            // Marketing fields from ResourceDto
            ResourceDto::FIELD_FLOOR_NUMBER,
            ResourceDto::FIELD_ROOM_COUNT,
            ResourceDto::FIELD_ADDITIONAL_DESCRIPTION,
            ResourceDto::FIELD_GARDEN_AREA,
            ResourceDto::FIELD_FLOOR_PLAN_PDF,
            
            // Functional
            ResourcesListShortcode::COLUMN_HISTORIA_CEN
        ];
        
        foreach ($available_columns as $column) {
            $current_name = $settings['column_names'][$column] ?? ucfirst($column);
            
            echo '<tr>';
            echo '<th scope="row">';
            echo '<label for="column_name_' . esc_attr($column) . '">' . esc_html(ucfirst($column)) . '</label>';
            echo '</th>';
            echo '<td>';
            echo '<input type="text" id="column_name_' . esc_attr($column) . '" name="column_names[' . esc_attr($column) . ']" value="' . esc_attr($current_name) . '" class="regular-text">';
            echo '</td>';
            echo '</tr>';
        }
    }
    
    /**
     * Render dynamic column names inputs - only for selected columns
     */
    private function render_dynamic_column_names_inputs(array $settings) {
        $available_columns = [
            // Basic information from ResourceDto
            ResourceDto::FIELD_NR_LOKALU,
            ResourceDto::FIELD_RODZAJ_NIERUCHOMOSCI,
            ResourceDto::FIELD_POWIERZCHNIA_UZYTKOWA,
            ResourceDto::FIELD_STATUS,
            
            // Prices from PriceHistory
            PriceHistoryDto::FIELD_CENA_M2,
            PriceHistoryDto::FIELD_CENA_CALKOWITA,
            PriceHistoryDto::FIELD_CENA_Z_DODATKAMI,
            
            // Marketing fields from ResourceDto
            ResourceDto::FIELD_FLOOR_NUMBER,
            ResourceDto::FIELD_ROOM_COUNT,
            ResourceDto::FIELD_ADDITIONAL_DESCRIPTION,
            ResourceDto::FIELD_GARDEN_AREA,
            ResourceDto::FIELD_FLOOR_PLAN_PDF,
            
            // Functional
            ResourcesListShortcode::COLUMN_HISTORIA_CEN
        ];
        $default_names = $this->getDefaultColumnNames();
        
        echo '<div class="dynamic-column-names">';
        
        foreach ($available_columns as $column) {
            $current_name = $settings['column_names'][$column] ?? ($default_names[$column] ?? ucfirst($column));
            $is_visible = in_array($column, $settings['visible_columns']);
            $display_name = $default_names[$column] ?? ucfirst($column);
            
            echo '<div class="column-name-input" data-column="' . esc_attr($column) . '" style="' . ($is_visible ? '' : 'display: none;') . '">';
            echo '<label for="dynamic_column_name_' . esc_attr($column) . '">Nazwa dla kolumny: <strong>' . esc_html($display_name) . '</strong></label>';
            echo '<input type="text" id="dynamic_column_name_' . esc_attr($column) . '" name="column_names[' . esc_attr($column) . ']" value="' . esc_attr($current_name) . '" class="regular-text" placeholder="Wprowadź własną nazwę">';
            echo '</div>';
        }
        
        echo '</div>';
    }
    
    
    /**
     * AJAX handler for resetting settings
     */
    public function ajax_reset_settings() {
        check_ajax_referer('ujc_frontend_settings_nonce', 'nonce');
        
        if (!current_user_can('manage_options')) {
            wp_send_json_error('Brak uprawnień');
        }
        
        // Reset to defaults by reloading page with default values
        wp_send_json_success([
            'message' => 'Ustawienia zostały zresetowane do domyślnych',
            'reload' => true
        ]);
    }
    
    /**
     * AJAX handler for live preview
     */
    public function ajax_preview_shortcode() {
        check_ajax_referer('ujc_frontend_settings_nonce', 'nonce');
        
        if (!current_user_can('manage_options')) {
            wp_send_json_error('Brak uprawnień');
        }
        
        try {
            // Get parameters from POST
            $selected_types = $_POST['selected_types'] ?? [];
            $visible_columns = $_POST['visible_columns'] ?? [];
            $column_names = $_POST['column_names'] ?? [];
            
            $styling_options = [
                'header_bg_color' => sanitize_hex_color($_POST['header_bg_color'] ?? '#f9f9f9'),
                'header_text_color' => sanitize_hex_color($_POST['header_text_color'] ?? '#333333'),
                'button_bg_color' => sanitize_hex_color($_POST['button_bg_color'] ?? '#007cba'),
                'button_text_color' => sanitize_hex_color($_POST['button_text_color'] ?? '#ffffff'),
                'hover_bg_color' => sanitize_hex_color($_POST['hover_bg_color'] ?? '#f5f5f5'),
                'text_color' => sanitize_hex_color($_POST['text_color'] ?? '#333333'),
                'header_font_family' => sanitize_text_field($_POST['header_font_family'] ?? 'inherit'),
                'content_font_family' => sanitize_text_field($_POST['content_font_family'] ?? 'inherit'),
            ];
            
            // Sanitize column names
            $sanitized_column_names = [];
            foreach ($column_names as $key => $value) {
                $sanitized_column_names[sanitize_key($key)] = sanitize_text_field($value);
            }
            
            // Generate preview HTML
            $preview_html = ResourcesListShortcode::render_preview($styling_options, $visible_columns, $sanitized_column_names);
            
            wp_send_json_success(['html' => $preview_html]);
            
        } catch (Exception $e) {
            Logger::error('Preview error: ' . $e->getMessage());
            wp_send_json_error('Błąd podczas generowania podglądu');
        }
    }
    
    /**
     * Get default settings for the form
     */
    private function getDefaultSettings() {
        return [
            'selected_types' => [PropertyType::RESIDENTIAL_UNIT],
            'visible_columns' => [
                ResourceDto::FIELD_NR_LOKALU,
                ResourceDto::FIELD_RODZAJ_NIERUCHOMOSCI,
                ResourceDto::FIELD_POWIERZCHNIA_UZYTKOWA,
                PriceHistoryDto::FIELD_CENA_CALKOWITA,
                ResourceDto::FIELD_STATUS,
                ResourcesListShortcode::COLUMN_HISTORIA_CEN
            ],
            'column_names' => $this->getDefaultColumnNames(),
            // Styling options
            'header_bg_color' => '#f9f9f9',
            'header_text_color' => '#333333',
            'button_bg_color' => '#007cba',
            'button_text_color' => '#ffffff',
            'hover_bg_color' => '#f5f5f5',
            'text_color' => '#333333',
            'header_font_family' => 'inherit',
            'content_font_family' => 'inherit'
        ];
    }
    
    /**
     * Get default column names for display
     */
    private function getDefaultColumnNames() {
        return [
            ResourceDto::FIELD_NR_LOKALU => 'Numer',
            ResourceDto::FIELD_RODZAJ_NIERUCHOMOSCI => 'Typ',
            ResourceDto::FIELD_POWIERZCHNIA_UZYTKOWA => 'Powierzchnia',
            ResourceDto::FIELD_STATUS => 'Status',
            PriceHistoryDto::FIELD_CENA_M2 => 'Cena za m²',
            PriceHistoryDto::FIELD_CENA_CALKOWITA => 'Cena lokalu',
            PriceHistoryDto::FIELD_CENA_Z_DODATKAMI => 'Cena pełna',
            ResourceDto::FIELD_FLOOR_NUMBER => 'Piętro',
            ResourceDto::FIELD_ROOM_COUNT => 'Liczba pokoi',
            ResourceDto::FIELD_ADDITIONAL_DESCRIPTION => 'Opis',
            ResourceDto::FIELD_GARDEN_AREA => 'Ogród',
            ResourceDto::FIELD_FLOOR_PLAN_PDF => 'Plan',
            ResourcesListShortcode::COLUMN_HISTORIA_CEN => 'Historia cen'
        ];
    }
    
    /**
     * Generate shortcode string based on current settings
     */
    private function generateShortcode(array $settings): string {
        $types_string = implode(',', array_map(fn($type) => $type->value, $settings['selected_types']));
        
        // Generate columns with names in format "field:name,field2:name2"
        $columns_with_names = [];
        foreach ($settings['visible_columns'] as $column) {
            $custom_name = trim($settings['column_names'][$column] ?? '');
            // Always include column, even with empty name (field:)
            $columns_with_names[] = "{$column}:{$custom_name}";
        }
        $columns_string = implode(',', $columns_with_names);
        
        $shortcode = "[resources_list types=\"{$types_string}\"";
        
        if (!empty($columns_string)) {
            $shortcode .= " columns=\"{$columns_string}\"";
        }
        
        // Add styling parameters
        $shortcode .= " header_bg_color=\"{$settings['header_bg_color']}\"";
        $shortcode .= " header_text_color=\"{$settings['header_text_color']}\"";
        $shortcode .= " button_bg_color=\"{$settings['button_bg_color']}\"";
        $shortcode .= " button_text_color=\"{$settings['button_text_color']}\"";
        $shortcode .= " hover_bg_color=\"{$settings['hover_bg_color']}\"";
        $shortcode .= " text_color=\"{$settings['text_color']}\"";
        $shortcode .= " header_font_family=\"{$settings['header_font_family']}\"";
        $shortcode .= " content_font_family=\"{$settings['content_font_family']}\"";
        
        $shortcode .= "]";
        
        return $shortcode;
    }
    
    /**
     * Render JavaScript and CSS
     */
    private function render_scripts_and_styles() {
        ?>
        <style>
        /* Page Header */
        .page-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 20px;
        }
        
        .page-actions {
            display: flex;
            gap: 10px;
        }
        
        /* Configuration Section Grid */
        .config-section-grid {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 20px;
            margin: 20px 0;
        }
        
        @media (max-width: 768px) {
            .config-section-grid {
                grid-template-columns: 1fr;
            }
            
            .page-header {
                flex-direction: column;
                align-items: flex-start;
                gap: 15px;
            }
        }
        
        /* Color inputs grid */
        .color-inputs-grid {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 15px;
            margin: 15px 0;
        }
        
        .color-input {
            display: flex;
            flex-direction: column;
        }
        
        .color-input label {
            margin-bottom: 5px;
            font-weight: 600;
            font-size: 13px;
        }
        
        .color-input input[type="color"] {
            width: 100%;
            height: 35px;
            border: 1px solid #ddd;
            border-radius: 3px;
        }
        
        /* Font inputs grid */
        .font-inputs-grid {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 15px;
            margin: 15px 0;
        }
        
        .font-input {
            display: flex;
            flex-direction: column;
        }
        
        .font-input label {
            margin-bottom: 5px;
            font-weight: 600;
            font-size: 13px;
        }
        
        .setting-group {
            margin-bottom: 25px;
        }
        
        .setting-group label {
            display: block;
            font-weight: 600;
            margin-bottom: 8px;
        }
        
        /* Property Types & Visible Columns Checkboxes */
        .property-types-checkboxes label,
        .visible-columns-checkboxes label {
            display: block;
            margin-bottom: 8px;
            font-weight: normal;
        }
        
        .property-types-checkboxes input,
        .visible-columns-checkboxes input {
            margin-right: 8px;
        }
        
        /* Dynamic Column Names */
        .dynamic-column-names {
            min-height: 200px;
        }
        
        .column-name-input {
            margin-bottom: 15px;
            padding: 10px;
            background: #f9f9f9;
            border-radius: 4px;
        }
        
        .column-name-input label {
            display: block;
            margin-bottom: 5px;
            font-size: 13px;
        }
        
        .column-name-input input {
            width: 100%;
        }
        
        /* Shortcode Preview */
        .shortcode-preview {
            margin-top: 30px;
            padding: 15px;
            background: #f8f9fa;
            border: 1px solid #ddd;
            border-radius: 4px;
        }
        
        .shortcode-display {
            display: flex;
            align-items: center;
            gap: 10px;
            margin-top: 10px;
        }
        
        .shortcode-display code {
            padding: 8px 12px;
            background: white;
            border: 1px solid #ddd;
            border-radius: 3px;
            font-family: Monaco, Consolas, monospace;
            flex-grow: 1;
            word-break: break-all;
        }
        
        /* General Styles */
        .submit-section {
            margin-top: 20px;
            padding: 20px 0;
            border-top: 1px solid #ddd;
        }
        
        .submit-section .button {
            margin-right: 10px;
        }
        
        .notice.inline {
            margin: 15px 0;
        }
        
        /* Live Preview Styles */
        #live-preview-container {
            border: 1px solid #ddd;
            border-radius: 4px;
            padding: 15px;
            background: #fff;
            min-height: 200px;
        }
        
        #preview-loading {
            text-align: center;
            padding: 40px 20px;
            color: #666;
        }
        
        #preview-content .ujc-shortcode-resources-list {
            margin: 0;
        }
        
        #preview-content .resources-table {
            font-size: 12px; /* Smaller for preview */
        }
        
        #preview-content .resources-table th,
        #preview-content .resources-table td {
            padding: 6px 4px; /* Smaller padding for preview */
        }
        
        /* Shortcode Display */
        .shortcode-display {
            display: flex;
            align-items: center;
            gap: 15px;
            margin: 15px 0;
        }
        
        .shortcode-display code {
            padding: 12px 15px;
            background: #f8f9fa;
            border: 1px solid #ddd;
            border-radius: 4px;
            font-family: Monaco, Consolas, monospace;
            flex-grow: 1;
            word-break: break-all;
            font-size: 13px;
        }
        
        /* Instructions Modal */
        .instructions-modal {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            z-index: 100000;
        }
        
        .modal-backdrop {
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0, 0, 0, 0.5);
        }
        
        .modal-content {
            position: relative;
            max-width: 800px;
            margin: 50px auto;
            background: #fff;
            border-radius: 4px;
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.3);
            max-height: calc(100vh - 100px);
            overflow-y: auto;
        }
        
        .modal-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 20px 25px 15px;
            border-bottom: 1px solid #ddd;
        }
        
        .modal-header h2 {
            margin: 0;
            font-size: 20px;
        }
        
        .modal-close {
            background: none;
            border: none;
            font-size: 24px;
            cursor: pointer;
            padding: 0;
            width: 30px;
            height: 30px;
            display: flex;
            align-items: center;
            justify-content: center;
            color: #666;
        }
        
        .modal-close:hover {
            color: #000;
        }
        
        .modal-body {
            padding: 25px;
        }
        
        .modal-body h3 {
            margin-top: 0;
            margin-bottom: 15px;
            color: #0073aa;
        }
        
        .modal-body ol,
        .modal-body ul {
            margin-bottom: 20px;
        }
        
        .modal-body li {
            margin-bottom: 8px;
        }
        
        .modal-body code {
            background: #f1f1f1;
            padding: 2px 6px;
            border-radius: 3px;
            font-size: 12px;
        }
        
        .modal-footer {
            padding: 15px 25px;
            border-top: 1px solid #ddd;
            text-align: right;
        }
        
        /* Prevent body scroll when modal is open */
        body.modal-open {
            overflow: hidden;
        }
        
        /* Responsive modal */
        @media (max-width: 768px) {
            .modal-content {
                margin: 20px;
                max-width: none;
                max-height: calc(100vh - 40px);
            }
            
            .color-inputs-grid,
            .font-inputs-grid {
                grid-template-columns: 1fr;
            }
        }
        </style>
        
        <script>
        jQuery(document).ready(function($) {
            
            // Update shortcode preview when settings change
            function updateShortcodePreview() {
                const selectedTypes = $('input[name="selected_types[]"]:checked').map(function() {
                    return this.value;
                }).get();
                
                // Generate columns with names in format "field:name,field2:name2"
                const columnsWithNames = [];
                $('input[name="visible_columns[]"]:checked').each(function() {
                    const fieldName = this.value;
                    const customName = $('input[name="column_names[' + fieldName + ']"]').val();
                    const finalName = customName ? customName.trim() : '';
                    // Always include column, even with empty name (field:)
                    columnsWithNames.push(fieldName + ':' + finalName);
                });
                
                // Get styling options
                const headerBgColor = $('#header-bg-color').val();
                const headerTextColor = $('#header-text-color').val();
                const buttonBgColor = $('#button-bg-color').val();
                const buttonTextColor = $('#button-text-color').val();
                const hoverBgColor = $('#hover-bg-color').val();
                const textColor = $('#text-color').val();
                const headerFontFamily = $('#header-font-family').val();
                const contentFontFamily = $('#content-font-family').val();
                
                let shortcode = '[resources_list';
                
                if (selectedTypes.length > 0) {
                    shortcode += ' types="' + selectedTypes.join(',') + '"';
                }
                
                if (columnsWithNames.length > 0) {
                    shortcode += ' columns="' + columnsWithNames.join(',') + '"';
                }
                
                // Add styling parameters
                shortcode += ' header_bg_color="' + headerBgColor + '"';
                shortcode += ' header_text_color="' + headerTextColor + '"';
                shortcode += ' button_bg_color="' + buttonBgColor + '"';
                shortcode += ' button_text_color="' + buttonTextColor + '"';
                shortcode += ' hover_bg_color="' + hoverBgColor + '"';
                shortcode += ' text_color="' + textColor + '"';
                shortcode += ' header_font_family="' + headerFontFamily + '"';
                shortcode += ' content_font_family="' + contentFontFamily + '"';
                
                shortcode += ']';
                
                $('#generated-shortcode').text(shortcode);
            }
            
            // Update live preview
            let previewTimeout;
            function updatePreview() {
                // Clear previous timeout
                clearTimeout(previewTimeout);
                
                // Show loading
                $('#preview-loading').show();
                $('#preview-content').hide();
                
                // Debounce AJAX call by 500ms
                previewTimeout = setTimeout(function() {
                    const formData = {
                        action: 'ujc_preview_shortcode',
                        nonce: $('[name="nonce"]').val(),
                        selected_types: $('input[name="selected_types[]"]:checked').map(function() { return this.value; }).get(),
                        visible_columns: $('input[name="visible_columns[]"]:checked').map(function() { return this.value; }).get(),
                        column_names: {},
                        header_bg_color: $('#header-bg-color').val(),
                        header_text_color: $('#header-text-color').val(),
                        button_bg_color: $('#button-bg-color').val(),
                        button_text_color: $('#button-text-color').val(),
                        hover_bg_color: $('#hover-bg-color').val(),
                        text_color: $('#text-color').val(),
                        header_font_family: $('#header-font-family').val(),
                        content_font_family: $('#content-font-family').val()
                    };
                    
                    // Collect column names
                    $('input[name^="column_names["]').each(function() {
                        const fieldName = $(this).attr('name').match(/column_names\[(.+?)\]/)[1];
                        formData.column_names[fieldName] = $(this).val();
                    });
                    
                    $.post(ajaxurl, formData)
                        .done(function(response) {
                            $('#preview-loading').hide();
                            if (response.success) {
                                $('#preview-content').html(response.data.html).show();
                            } else {
                                $('#preview-content').html('<p style="color: red;">Błąd: ' + (response.data || 'Nieznany błąd') + '</p>').show();
                            }
                        })
                        .fail(function() {
                            $('#preview-loading').hide();
                            $('#preview-content').html('<p style="color: red;">Błąd połączenia z serwerem</p>').show();
                        });
                }, 500);
            }
            
            // Toggle column name inputs based on visible columns selection
            function toggleColumnNameInputs() {
                $('input[name="visible_columns[]"]').each(function() {
                    const columnName = $(this).val();
                    const isChecked = $(this).is(':checked');
                    const columnInput = $('.column-name-input[data-column="' + columnName + '"]');
                    
                    if (isChecked) {
                        columnInput.show();
                    } else {
                        columnInput.hide();
                    }
                });
            }
            
            // Update preview and column inputs on changes
            $('input[name="selected_types[]"], input[name="visible_columns[]"]').on('change', function() {
                updateShortcodePreview();
                toggleColumnNameInputs();
                updatePreview();
            });
            
            // Update shortcode when styling options change
            $('#header-bg-color, #header-text-color, #button-bg-color, #button-text-color, #hover-bg-color, #text-color, #header-font-family, #content-font-family').on('change input', function() {
                updateShortcodePreview();
                updatePreview();
            });
            
            // Update shortcode when column names change
            $(document).on('input', 'input[name^="column_names["]', function() {
                updateShortcodePreview();
                updatePreview();
            });
            
            // Initialize on page load
            toggleColumnNameInputs();
            updatePreview(); // Load initial preview
            
            // Instructions Modal
            $('#show-instructions').on('click', function() {
                $('#instructions-modal').fadeIn(200);
                $('body').addClass('modal-open');
            });
            
            $('#close-instructions, #close-instructions-footer, .modal-backdrop').on('click', function() {
                $('#instructions-modal').fadeOut(200);
                $('body').removeClass('modal-open');
            });
            
            // Prevent modal close when clicking inside modal content
            $('.modal-content').on('click', function(e) {
                e.stopPropagation();
            });
            
            // Copy shortcode to clipboard
            $('#copy-shortcode').on('click', function() {
                const shortcode = $('#generated-shortcode').text();
                navigator.clipboard.writeText(shortcode).then(function() {
                    $(this).text('Skopiowano!').addClass('button-primary');
                    setTimeout(() => {
                        $(this).text('Kopiuj').removeClass('button-primary');
                    }, 2000);
                }.bind(this));
            });
            
            // Removed save functionality - shortcode is generated dynamically only
            
            // Reset settings
            $('#reset-settings').on('click', function() {
                if (!confirm('Czy na pewno chcesz przywrócić domyślne ustawienia? Ta operacja jest nieodwracalna.')) {
                    return;
                }
                
                const $resetBtn = $(this);
                const originalText = $resetBtn.text();
                $resetBtn.text('Resetowanie...').prop('disabled', true);
                
                $.post(ajaxurl, {
                    action: 'ujc_reset_frontend_settings',
                    nonce: $('[name="nonce"]').val()
                }, function(response) {
                    if (response.success) {
                        alert('✅ ' + response.data.message);
                        if (response.data.reload) {
                            location.reload();
                        }
                    } else {
                        alert('❌ ' + response.data);
                    }
                }).fail(function() {
                    alert('❌ Błąd połączenia');
                }).always(function() {
                    $resetBtn.text(originalText).prop('disabled', false);
                });
            });
        });
        </script>
        <?php
    }
}