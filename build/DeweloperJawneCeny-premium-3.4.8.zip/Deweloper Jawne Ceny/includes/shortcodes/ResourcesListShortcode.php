<?php

if (!defined('ABSPATH')) {
    exit;
}

/**
 * Resources List Shortcode Handler
 * Handles the [resources_list] shortcode with filtering and customization options
 */
class ResourcesListShortcode {
    
    // Functional column constants
    public const COLUMN_HISTORIA_CEN = 'historia_cen';
    
    /**
     * Handle resources_list shortcode with type-safe parsing
     * All configuration comes from shortcode parameters with sensible defaults
     */
    public static function handle($atts) {
        // Default columns
        $default_columns = implode(',', [
            ResourceDto::FIELD_NR_LOKALU,
            ResourceDto::FIELD_RODZAJ_NIERUCHOMOSCI,
            ResourceDto::FIELD_POWIERZCHNIA_UZYTKOWA,
            PriceHistoryDto::FIELD_CENA_CALKOWITA,
            ResourceDto::FIELD_STATUS,
            self::COLUMN_HISTORIA_CEN
        ]);
        
        // Default types - residential units only
        $default_types = PropertyType::RESIDENTIAL_UNIT->value;
        
        Logger::info('Raw atts before shortcode_atts: ' . print_r($atts, true));
        
        $atts = shortcode_atts([
            'types' => $default_types,
            'columns' => $default_columns,
            'header_bg_color' => '#f9f9f9',
            'header_text_color' => '#333333',
            'button_bg_color' => '#007cba',
            'button_text_color' => '#ffffff',
            'hover_bg_color' => '#f5f5f5',
            'text_color' => '#333333',
            'header_font_family' => 'inherit',
            'content_font_family' => 'inherit',
        ], $atts);
        
        Logger::info('Processed atts after shortcode_atts: ' . print_r($atts, true));
        
        try {
            // Parse property types
            $type_strings = array_map('trim', explode(',', $atts['types']));
            $selected_types = [];
            
            foreach ($type_strings as $type_string) {
                try {
                    $selected_types[] = PropertyType::from($type_string);
                } catch (ValueError $e) {
                    Logger::error("Invalid PropertyType in shortcode: {$type_string}");
                    // Skip invalid types, don't fail completely
                }
            }
            
            // If no valid types, use default
            if (empty($selected_types)) {
                $selected_types = [PropertyType::RESIDENTIAL_UNIT];
            }
            
            // Parse visible columns with names (format: field:name,field2:name2)
            $column_strings = array_map('trim', explode(',', $atts['columns']));
            $visible_columns = [];
            $column_names = [];
            
            $available_columns = [
                // Basic information from ResourceDto
                ResourceDto::FIELD_NR_LOKALU,
                ResourceDto::FIELD_RODZAJ_NIERUCHOMOSCI,
                ResourceDto::FIELD_POWIERZCHNIA_UZYTKOWA,
                ResourceDto::FIELD_STATUS,
                
                // Prices from PriceHistory
                PriceHistoryDto::FIELD_CENA_M2,
                PriceHistoryDto::FIELD_CENA_CALKOWITA,
                PriceHistoryDto::FIELD_CENA_Z_DODATKAMI,
                
                // Marketing fields from ResourceDto
                ResourceDto::FIELD_FLOOR_NUMBER,
                ResourceDto::FIELD_ROOM_COUNT,
                ResourceDto::FIELD_ADDITIONAL_DESCRIPTION,
                ResourceDto::FIELD_GARDEN_AREA,
                ResourceDto::FIELD_FLOOR_PLAN_PDF,
                
                // Functional
                self::COLUMN_HISTORIA_CEN
            ];
            
            foreach ($column_strings as $column_string) {
                if (strpos($column_string, ':') !== false) {
                    [$field, $name] = explode(':', $column_string, 2);
                    $field = trim($field);
                    $name = trim($name);
                    
                    // Replace underscores back to spaces for display
                    $name = str_replace('_', ' ', $name);
                    
                    // Only add if field is valid
                    if (in_array($field, $available_columns)) {
                        $visible_columns[] = $field;
                        $column_names[$field] = $name;
                    } else {
                        Logger::error("Invalid column field in shortcode: {$field}");
                    }
                } else {
                    Logger::error("Column must be in format 'field:name', got: {$column_string}");
                }
            }
            
            // If no valid columns, return error
            if (empty($visible_columns)) {
                Logger::error("No valid columns provided in shortcode");
                return '<div class="ujc-shortcode-error">Błąd: Brak prawidłowych kolumn w formacie field:nazwa.</div>';
            }
            
            // Use provided styling options
            $styling_options = [
                'header_bg_color' => $atts['header_bg_color'],
                'header_text_color' => $atts['header_text_color'],
                'button_bg_color' => $atts['button_bg_color'],
                'button_text_color' => $atts['button_text_color'],
                'hover_bg_color' => $atts['hover_bg_color'],
                'text_color' => $atts['text_color'],
                'header_font_family' => $atts['header_font_family'],
                'content_font_family' => $atts['content_font_family'],
            ];
            
            // Render the resources table
            return self::render_resources_table($selected_types, $visible_columns, $column_names, $styling_options);
            
        } catch (Exception $e) {
            Logger::error("Shortcode error: " . $e->getMessage());
            return '<div class="ujc-shortcode-error">Błąd podczas ładowania zasobów.</div>';
        }
    }
    
    /**
     * Render resources table for shortcode
     */
    private static function render_resources_table(array $selected_types, array $visible_columns, array $column_names, array $styling_options): string {
        Logger::info("Shortcode: render_resources_table started");
        Logger::info("Shortcode: Selected types count: " . count($selected_types));
        Logger::info("Shortcode: Selected type values: " . implode(', ', array_map(fn($type) => $type->value, $selected_types)));
        
        // Get resources using dedicated frontend UseCase with built-in filtering
        $frontend_use_case = new GetResourcesForFrontendUseCase();
        $filtered_resources = $frontend_use_case->execute($selected_types);
        Logger::info("Shortcode: Got " . count($filtered_resources) . " filtered resources from GetResourcesForFrontendUseCase");
        
        if (empty($filtered_resources)) {
            Logger::error("Shortcode: No resources to display");
            return '<div class="ujc-no-resources">Brak zasobów do wyświetlenia.</div>';
        }
        
        // Start output buffering
        ob_start();
        
        // Generate dynamic CSS
        self::render_dynamic_css($styling_options);
        
        ?>
        <div class="ujc-shortcode-resources-list">
            <table class="resources-table">
                <thead>
                    <tr>
                        <?php foreach ($visible_columns as $column): ?>
                            <th><?php echo esc_html($column_names[$column] ?? ucfirst($column)); ?></th>
                        <?php endforeach; ?>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($filtered_resources as $resource): ?>
                        <tr>
                            <?php foreach ($visible_columns as $column): ?>
                                <td><?php echo self::render_column_value($resource, $column); ?></td>
                            <?php endforeach; ?>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
            
            <!-- Price History Modal (same as in existing block) -->
            <div id="price-history-modal" class="price-history-modal" style="display: none;">
                <div class="modal-content">
                    <div class="modal-header">
                        <h3>Historia cen - <span id="modal-resource-name"></span></h3>
                        <button class="modal-close">&times;</button>
                    </div>
                    <div class="modal-body">
                        <div id="history-loading">Ładowanie...</div>
                        <div id="history-content"></div>
                    </div>
                </div>
            </div>
        </div>
        <?php
        
        return ob_get_clean();
    }
    
    /**
     * Render individual column value
     */
    private static function render_column_value($resource, string $column): string {
        switch ($column) {
            case ResourceDto::FIELD_NR_LOKALU:
                return esc_html($resource->nr_lokalu);
                
            case ResourceDto::FIELD_RODZAJ_NIERUCHOMOSCI:
                try {
                    $propertyType = PropertyType::from($resource->rodzaj_nieruchomosci);
                    return esc_html($propertyType->getDisplayText());
                } catch (ValueError $e) {
                    return esc_html($resource->rodzaj_nieruchomosci);
                }
                
            case ResourceDto::FIELD_POWIERZCHNIA_UZYTKOWA:
                // Hide surface area for parking spaces (existing logic)
                if ($resource->rodzaj_nieruchomosci === PropertyType::PARKING_SPACE->value) {
                    return '—';
                }
                return esc_html(number_format($resource->powierzchnia_uzytkowa, 2, ',', ' ')) . ' m²';
                
            case ResourceDto::FIELD_STATUS:
                try {
                    $status = ResourceStatus::from($resource->status);
                    return '<span class="status-' . esc_attr($resource->status) . '">' . esc_html($status->getDisplayText()) . '</span>';
                } catch (ValueError $e) {
                    return esc_html($resource->status);
                }
                
            case PriceHistoryDto::FIELD_CENA_M2:
                // Hide price per m2 for parking spaces (existing logic)
                if ($resource->rodzaj_nieruchomosci === PropertyType::PARKING_SPACE->value) {
                    return '—';
                }
                if ($resource->cena_m2 !== null && $resource->cena_m2 > 0) {
                    return esc_html(number_format($resource->cena_m2, 2, ',', ' ')) . ' zł';
                }
                return '—';
                
            case PriceHistoryDto::FIELD_CENA_CALKOWITA:
                if ($resource->cena_calkowita) {
                    return esc_html(number_format($resource->cena_calkowita, 2, ',', ' ')) . ' zł';
                }
                return '—';
                
            case PriceHistoryDto::FIELD_CENA_Z_DODATKAMI:
                if ($resource->cena_z_dodatkami) {
                    return esc_html(number_format($resource->cena_z_dodatkami, 2, ',', ' ')) . ' zł';
                }
                return '—';
                
            case self::COLUMN_HISTORIA_CEN:
                return '<button class="price-history-btn" data-resource-id="' . esc_attr($resource->id) . '" data-resource-name="' . esc_attr($resource->nr_lokalu) . '">Historia</button>';
                
            // Marketing fields
            case ResourceDto::FIELD_FLOOR_NUMBER:
                return $resource->floor_number ? esc_html($resource->floor_number) : '—';
                
            case ResourceDto::FIELD_ROOM_COUNT:
                return $resource->room_count ? esc_html($resource->room_count) : '—';
                
            case ResourceDto::FIELD_ADDITIONAL_DESCRIPTION:
                return $resource->additional_description ? esc_html(wp_trim_words($resource->additional_description, 10)) : '—';
                
            case ResourceDto::FIELD_GARDEN_AREA:
                return $resource->garden_area ? esc_html(number_format($resource->garden_area, 2, ',', ' ')) . ' m²' : '—';
                
            case ResourceDto::FIELD_FLOOR_PLAN_PDF:
                if ($resource->floor_plan_pdf) {
                    $filename = basename($resource->floor_plan_pdf);
                    return '<button class="download-floorplan-btn" data-filename="' . esc_attr($filename) . '">Karta lokalu</button>';
                }
                return '—';
                
            default:
                return '—';
        }
    }
    
    /**
     * Render dynamic CSS with custom styling options
     */
    private static function render_dynamic_css(array $styling_options): void {
        ?>
        <style>
        /* Headers */
        .ujc-shortcode-resources-list .resources-table th {
            background-color: <?php echo esc_attr($styling_options['header_bg_color']); ?>;
            color: <?php echo esc_attr($styling_options['header_text_color']); ?>;
            font-family: <?php echo esc_attr($styling_options['header_font_family']); ?>;
            font-weight: 600;
            padding: 12px 8px;
            text-align: left;
            border-bottom: 1px solid #ddd;
        }
        
        /* Content cells */
        .ujc-shortcode-resources-list .resources-table td {
            color: <?php echo esc_attr($styling_options['text_color']); ?>;
            font-family: <?php echo esc_attr($styling_options['content_font_family']); ?>;
            padding: 12px 8px;
            text-align: left;
            border-bottom: 1px solid #ddd;
        }
        
        /* Table structure */
        .ujc-shortcode-resources-list .resources-table {
            width: 100%;
            border-collapse: collapse;
            margin: 1em 0;
        }
        
        /* Row hover */
        .ujc-shortcode-resources-list .resources-table tbody tr:hover {
            background-color: <?php echo esc_attr($styling_options['hover_bg_color']); ?>;
        }
        
        /* Buttons - Historia cen and Karta lokalu */
        .ujc-shortcode-resources-list .price-history-btn,
        .ujc-shortcode-resources-list .download-floorplan-btn {
            background-color: <?php echo esc_attr($styling_options['button_bg_color']); ?>;
            color: <?php echo esc_attr($styling_options['button_text_color']); ?>;
            border: none;
            padding: 6px 12px;
            border-radius: 4px;
            cursor: pointer;
            font-size: 0.875em;
            transition: background-color 0.2s;
        }
        
        .ujc-shortcode-resources-list .price-history-btn:hover,
        .ujc-shortcode-resources-list .download-floorplan-btn:hover {
            opacity: 0.8;
        }
        
        /* Links - PDF downloads */
        .ujc-shortcode-resources-list .resources-table td a {
            background-color: <?php echo esc_attr($styling_options['button_bg_color']); ?>;
            color: <?php echo esc_attr($styling_options['button_text_color']); ?>;
            text-decoration: none;
            padding: 4px 8px;
            border-radius: 3px;
            font-size: 0.875em;
            transition: opacity 0.2s;
        }
        
        .ujc-shortcode-resources-list .resources-table td a:hover {
            opacity: 0.8;
        }
        
        /* Error and no resources messages */
        .ujc-shortcode-resources-list .ujc-no-resources {
            padding: 20px;
            text-align: center;
            color: #666;
            font-style: italic;
        }
        
        .ujc-shortcode-resources-list .ujc-shortcode-error {
            padding: 15px;
            background-color: #ffebee;
            color: #c62828;
            border: 1px solid #ffcdd2;
            border-radius: 4px;
            margin: 10px 0;
        }
        </style>
        <?php
    }
}