<?php

if (!defined('ABSPATH')) {
    exit;
}

namespace JawneCeny;


class GetDeveloperInfoUseCase {

    private $repository;

    public function __construct(DeveloperRepository $repository) {
        $this->repository = $repository;
    }
    
    public function execute(): ?SupplierDto {
        return $this->repository->read();
    }
}