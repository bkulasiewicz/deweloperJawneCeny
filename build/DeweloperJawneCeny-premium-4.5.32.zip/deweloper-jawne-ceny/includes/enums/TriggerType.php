<?php

if (!defined('ABSPATH')) {
    exit;
}

namespace JawneCeny;


/**
 * Publication trigger type enum
 */
enum TriggerType: string {
    case Manual = 'manual';
    case ExternalCron = 'external_cron';
    case WpCronFallback = 'wp_cron_fallback';
}