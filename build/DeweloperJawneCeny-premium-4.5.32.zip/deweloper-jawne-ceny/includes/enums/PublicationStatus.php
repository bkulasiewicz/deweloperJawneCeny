<?php

if (!defined('ABSPATH')) {
    exit;
}

namespace JawneCeny;


/**
 * Publication status enum
 */
enum PublicationStatus: string {
    case Success = 'success';
    case Error = 'error';
}