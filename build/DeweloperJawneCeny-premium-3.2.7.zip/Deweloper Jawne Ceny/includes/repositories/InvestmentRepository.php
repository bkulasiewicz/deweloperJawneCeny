<?php

if (!defined('ABSPATH')) {
    exit;
}

class InvestmentRepository {
    
    /**
     * Get investment data as model
     */
    public function read(): ?InvestmentDto {
        $table = TableNames::getInvestmentInfo();        
        global $wpdb;
        $data = $wpdb->get_row($wpdb->prepare("SELECT * FROM `{$table}` LIMIT 1"), ARRAY_A);
        
        return $data ? InvestmentDto::databaseToModel($data) : null;
    }
    
    /**
     * Create new investment
     */
    public function create(InvestmentDto $dto): int {
        $table = TableNames::getInvestmentInfo();        
        global $wpdb;
        
        Logger::info('UJC: InvestmentRepository::create() started');
        Logger::info('UJC: Table name: ' . $table);
        
        $data = $dto->modelToDatabase();
        Logger::info('UJC: Data to insert: ' . print_r($data, true));
        
        $result = $wpdb->insert($table, $data);
        Logger::info('UJC: Insert result: ' . ($result !== false ? 'SUCCESS' : 'FAILED'));
        
        if ($result === false) {
            Logger::error('UJC: Insert failed. Last error: ' . $wpdb->last_error);
            Logger::error('UJC: Last query: ' . $wpdb->last_query);
            throw new Exception('Failed to create investment: ' . $wpdb->last_error);
        }
        
        $insert_id = $wpdb->insert_id;
        Logger::info('UJC: Created investment with ID: ' . $insert_id);
        
        return $insert_id;
    }
    
    /**
     * Update existing investment
     */
    public function update(InvestmentDto $dto, int $id): void {
        $table = TableNames::getInvestmentInfo();        
        global $wpdb;
        
        Logger::info('UJC: InvestmentRepository::update() started for ID: ' . $id);
        Logger::info('UJC: Table name: ' . $table);
        
        $data = $dto->modelToDatabase();
        Logger::info('UJC: Data to update: ' . print_r($data, true));
        
        $result = $wpdb->update($table, $data, ['id' => $id]);
        Logger::info('UJC: Update result: ' . ($result !== false ? 'SUCCESS (rows affected: ' . $result . ')' : 'FAILED'));
        
        if ($result === false) {
            Logger::error('UJC: Update failed. Last error: ' . $wpdb->last_error);
            Logger::error('UJC: Last query: ' . $wpdb->last_query);
            throw new Exception('Failed to update investment: ' . $wpdb->last_error);
        }
        
        Logger::info('UJC: Investment update completed successfully');
    }
    
    /**
     * Create investment table using InvestmentDto field constants
     */
    public function createTable(string $currentDbVersion): bool {
        global $wpdb;
        $table = TableNames::getInvestmentInfo();
        $charset_collate = $wpdb->get_charset_collate();
        
        Logger::info('InvestmentRepository::createTable() - START');
        Logger::info('InvestmentRepository: Table name: ' . $table);
        Logger::info('InvestmentRepository: Received currentDbVersion: ' . $currentDbVersion);
        
        if (!UJC_Schema_Manager::tableExists($table)) {
            Logger::info('InvestmentRepository: Table does not exist, creating full table...');
            return $this->createFullTable();
        }
        
        Logger::info('InvestmentRepository: Table exists, checking for migrations...');
        
        // Migracja do wersji 1.7 - dodanie pól marketingowych
        Logger::info('InvestmentRepository: Checking version_compare(' . $currentDbVersion . ', "1.7", "<")');
        $shouldMigrate = version_compare($currentDbVersion, '1.7', '<');
        Logger::info('InvestmentRepository: version_compare result: ' . ($shouldMigrate ? 'TRUE - MIGRATION NEEDED' : 'FALSE - NO MIGRATION'));
        
        if ($shouldMigrate) {
            Logger::info('InvestmentRepository: Starting migration to 1.7 - adding marketing fields...');
            $this->addMarketingFieldColumns();
            Logger::info('InvestmentRepository: Migration to 1.7 completed');
        }
        
        Logger::info('InvestmentRepository::createTable() - COMPLETED');
        return true;
    }
    
    /**
     * Tworzy pełną tabelę od zera (dla nowych instalacji)
     */
    private function createFullTable(): bool {
        global $wpdb;
        $table = TableNames::getInvestmentInfo();
        $charset_collate = $wpdb->get_charset_collate();
        
        $sql = "CREATE TABLE `{$table}` (
            " . InvestmentDto::FIELD_ID . " int(11) NOT NULL AUTO_INCREMENT,
            " . InvestmentDto::FIELD_DEVELOPER_ID . " int(11) NOT NULL DEFAULT 1,
            " . InvestmentDto::FIELD_NAME . " varchar(255) NOT NULL,
            " . InvestmentDto::FIELD_PROJ_WOJEWODZTWO . " varchar(50) NOT NULL,
            " . InvestmentDto::FIELD_PROJ_POWIAT . " varchar(50),
            " . InvestmentDto::FIELD_PROJ_GMINA . " varchar(50),
            " . InvestmentDto::FIELD_PROJ_MIEJSCOWOSC . " varchar(50) NOT NULL,
            " . InvestmentDto::FIELD_PROJ_ULICA . " varchar(100),
            " . InvestmentDto::FIELD_PROJ_NR . " varchar(20),
            " . InvestmentDto::FIELD_PROJ_KOD . " varchar(10),
            
            " . InvestmentDto::FIELD_HAS_PROPERTY_PARTS . " tinyint(1) DEFAULT 0,
            " . InvestmentDto::FIELD_HAS_BELONGING_ROOMS . " tinyint(1) DEFAULT 0,
            " . InvestmentDto::FIELD_HAS_USAGE_RIGHTS . " tinyint(1) DEFAULT 0,
            " . InvestmentDto::FIELD_HAS_OTHER_SERVICES . " tinyint(1) DEFAULT 0,
            
            " . InvestmentDto::FIELD_SHOW_FLOOR_FIELD . " tinyint(1) DEFAULT 0,
            " . InvestmentDto::FIELD_SHOW_ROOMS_FIELD . " tinyint(1) DEFAULT 0,
            " . InvestmentDto::FIELD_SHOW_DESCRIPTION_FIELD . " tinyint(1) DEFAULT 0,
            " . InvestmentDto::FIELD_SHOW_GARDEN_FIELD . " tinyint(1) DEFAULT 0,
            " . InvestmentDto::FIELD_SHOW_FLOOR_PLAN_FIELD . " tinyint(1) DEFAULT 0,
            
            PRIMARY KEY (" . InvestmentDto::FIELD_ID . "),
            FOREIGN KEY (" . InvestmentDto::FIELD_DEVELOPER_ID . ") REFERENCES " . TableNames::getDeveloperInfo() . "(id) ON DELETE CASCADE
        ) " . $charset_collate;
        
        return $wpdb->query($wpdb->prepare($sql)) !== false;
    }
    
    /**
     * Dodaje kolumny pól marketingowych do istniejącej tabeli
     */
    private function addMarketingFieldColumns(): void {
        global $wpdb;
        $table = TableNames::getInvestmentInfo();
        
        Logger::info('InvestmentRepository::addMarketingFieldColumns() - START');
        Logger::info('InvestmentRepository: Target table: ' . $table);
        
        $sql = "ALTER TABLE `{$table}` ADD COLUMN 
            " . InvestmentDto::FIELD_SHOW_FLOOR_FIELD . " TINYINT(1) DEFAULT 0,
            " . InvestmentDto::FIELD_SHOW_ROOMS_FIELD . " TINYINT(1) DEFAULT 0,
            " . InvestmentDto::FIELD_SHOW_DESCRIPTION_FIELD . " TINYINT(1) DEFAULT 0,
            " . InvestmentDto::FIELD_SHOW_GARDEN_FIELD . " TINYINT(1) DEFAULT 0,
            " . InvestmentDto::FIELD_SHOW_FLOOR_PLAN_FIELD . " TINYINT(1) DEFAULT 0";
        
        Logger::info('InvestmentRepository: Executing ALTER TABLE SQL: ' . $sql);
        
        $result = $wpdb->query($sql);
        
        Logger::info('InvestmentRepository: ALTER TABLE result: ' . ($result !== false ? 'SUCCESS' : 'FAILED'));
        
        if ($result === false) {
            Logger::error('InvestmentRepository: Failed to add marketing field columns: ' . $wpdb->last_error);
            Logger::error('InvestmentRepository: Last query: ' . $wpdb->last_query);
        } else {
            Logger::info('InvestmentRepository: Successfully added marketing field columns');
            Logger::info('InvestmentRepository: Rows affected: ' . $result);
        }
        
        Logger::info('InvestmentRepository::addMarketingFieldColumns() - COMPLETED');
    }
}