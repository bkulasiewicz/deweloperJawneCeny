<?php

if (!defined('ABSPATH')) {
    exit;
}

class OtherService {
    
    public const FIELD_ID = 'id';
    public const FIELD_RESOURCE_ID = 'resource_id';
    public const FIELD_DESCRIPTION = 'description';
    public const FIELD_PRICE = 'price';
    public const FIELD_PRICE_DATE = 'price_date';
    
    public int $id;
    public int $resource_id;
    public string $description;
    public float $price;
    public DateTime $price_date;
    
    public function __construct(
        int $id,
        int $resource_id,
        string $description,
        float $price,
        DateTime $price_date
    ) {
        $this->id = $id;
        $this->resource_id = $resource_id;
        $this->description = $description;
        $this->price = $price;
        $this->price_date = $price_date;
    }
}