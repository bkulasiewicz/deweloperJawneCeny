<?php

if (!defined('ABSPATH')) {
    exit;
}

class PropertyPart {
    
    public const FIELD_ID = 'id';
    public const FIELD_RESOURCE_ID = 'resource_id';
    public const FIELD_TYPE = 'type';
    public const FIELD_DESIGNATION = 'designation';
    public const FIELD_PRICE = 'price';
    public const FIELD_PRICE_DATE = 'price_date';
    
    public int $id;
    public int $resource_id;
    public string $type;
    public string $designation;
    public float $price;
    public DateTime $price_date;
    
    public function __construct(
        int $id,
        int $resource_id,
        string $type,
        string $designation,
        float $price,
        DateTime $price_date
    ) {
        $this->id = $id;
        $this->resource_id = $resource_id;
        $this->type = $type;
        $this->designation = $designation;
        $this->price = $price;
        $this->price_date = $price_date;
    }
}