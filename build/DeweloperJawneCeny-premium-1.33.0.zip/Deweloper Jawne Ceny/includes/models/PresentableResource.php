<?php

if (!defined('ABSPATH')) {
    exit;
}

class PresentableResource {
    
    public Resource $resource;
    public array $property_parts;
    public array $belonging_rooms;
    public array $usage_rights;
    public array $other_services;
    
    public function __construct(
        Resource $resource,
        array $property_parts = [],
        array $belonging_rooms = [],
        array $usage_rights = [],
        array $other_services = []
    ) {
        $this->resource = $resource;
        $this->property_parts = $property_parts;
        $this->belonging_rooms = $belonging_rooms;
        $this->usage_rights = $usage_rights;
        $this->other_services = $other_services;
    }
}