<?php

if (!defined('ABSPATH')) {
    exit;
}

class UsageRightsRepository {
    
    /**
     * Get all usage rights for a resource
     */
    public function getByResourceId($resourceId) {
        $table = TableNames::getResourceUsageRights();        
        global $wpdb;
        return $wpdb->get_results($wpdb->prepare(
            "SELECT * FROM `{$table}` WHERE resource_id = %d ORDER BY created_at ASC", 
            $resourceId
        ), ARRAY_A);
    }
    
    /**
     * Save usage rights for a resource
     */
    public function save($resourceId, $data) {
        $table = TableNames::getResourceUsageRights();        
        global $wpdb;
        
        $data['resource_id'] = $resourceId;
        
        return $wpdb->insert($table, $data);
    }
    
    /**
     * Delete all usage rights for a resource
     */
    public function deleteByResourceId($resourceId) {
        $table = TableNames::getResourceUsageRights();        
        global $wpdb;
        return $wpdb->delete($table, ['resource_id' => $resourceId], ['%d']);
    }
    
    /**
     * Update usage rights
     */
    public function update($id, $data) {
        $table = TableNames::getResourceUsageRights();        
        global $wpdb;
        return $wpdb->update($table, $data, ['id' => $id], null, ['%d']);
    }
    
    /**
     * Delete usage rights by ID
     */
    public function delete($id) {
        $table = TableNames::getResourceUsageRights();        
        global $wpdb;
        return $wpdb->delete($table, ['id' => $id], ['%d']);
    }
}