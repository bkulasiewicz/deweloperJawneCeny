<?php

if (!defined('ABSPATH')) {
    exit;
}

class OtherServicesRepository {
    
    /**
     * Get all other services for a resource
     */
    public function getByResourceId($resourceId) {
        $table = TableNames::getResourceOtherServices();        
        global $wpdb;
        return $wpdb->get_results($wpdb->prepare(
            "SELECT * FROM `{$table}` WHERE resource_id = %d ORDER BY created_at ASC", 
            $resourceId
        ), ARRAY_A);
    }
    
    /**
     * Save other services for a resource
     */
    public function save($resourceId, $data) {
        $table = TableNames::getResourceOtherServices();        
        global $wpdb;
        
        $data['resource_id'] = $resourceId;
        
        return $wpdb->insert($table, $data);
    }
    
    /**
     * Delete all other services for a resource
     */
    public function deleteByResourceId($resourceId) {
        $table = TableNames::getResourceOtherServices();        
        global $wpdb;
        return $wpdb->delete($table, ['resource_id' => $resourceId], ['%d']);
    }
    
    /**
     * Update other services
     */
    public function update($id, $data) {
        $table = TableNames::getResourceOtherServices();        
        global $wpdb;
        return $wpdb->update($table, $data, ['id' => $id], null, ['%d']);
    }
    
    /**
     * Delete other services by ID
     */
    public function delete($id) {
        $table = TableNames::getResourceOtherServices();        
        global $wpdb;
        return $wpdb->delete($table, ['id' => $id], ['%d']);
    }
}