<?php

if (!defined('ABSPATH')) {
    exit;
}

class PropertyPartsRepository {
    
    /**
     * Get all property parts for a resource
     */
    public function getByResourceId($resourceId) {
        $table = TableNames::getResourcePropertyParts();        
        global $wpdb;
        return $wpdb->get_results($wpdb->prepare(
            "SELECT * FROM `{$table}` WHERE resource_id = %d ORDER BY created_at ASC", 
            $resourceId
        ), ARRAY_A);
    }
    
    /**
     * Save property part for a resource
     */
    public function save($resourceId, $data) {
        $table = TableNames::getResourcePropertyParts();        
        global $wpdb;
        
        $data['resource_id'] = $resourceId;
        
        return $wpdb->insert($table, $data);
    }
    
    /**
     * Delete all property parts for a resource
     */
    public function deleteByResourceId($resourceId) {
        $table = TableNames::getResourcePropertyParts();        
        global $wpdb;
        return $wpdb->delete($table, ['resource_id' => $resourceId], ['%d']);
    }
    
    /**
     * Update property part
     */
    public function update($id, $data) {
        $table = TableNames::getResourcePropertyParts();        
        global $wpdb;
        return $wpdb->update($table, $data, ['id' => $id], null, ['%d']);
    }
    
    /**
     * Delete property part by ID
     */
    public function delete($id) {
        $table = TableNames::getResourcePropertyParts();        
        global $wpdb;
        return $wpdb->delete($table, ['id' => $id], ['%d']);
    }
}