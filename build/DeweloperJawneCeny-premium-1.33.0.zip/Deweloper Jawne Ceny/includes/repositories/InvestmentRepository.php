<?php

if (!defined('ABSPATH')) {
    exit;
}

class InvestmentRepository {
    
    /**
     * Get investment data as model
     */
    public function read() {
        $table = TableNames::getInvestmentInfo();        
        global $wpdb;
        $data = $wpdb->get_row("SELECT * FROM `{$table}` LIMIT 1", ARRAY_A);
        
        if (!$data) {
            return null;
        }
        
        return new Investment(
            (int)($data[Investment::FIELD_ID] ?? 0),
            $data[Investment::FIELD_NAME] ?? '',
            $data[Investment::FIELD_PROJ_WOJEWODZTWO] ?? '',
            $data[Investment::FIELD_PROJ_POWIAT] ?? '',
            $data[Investment::FIELD_PROJ_GMINA] ?? '',
            $data[Investment::FIELD_PROJ_MIEJSCOWOSC] ?? '',
            $data[Investment::FIELD_PROJ_ULICA] ?? '',
            $data[Investment::FIELD_PROJ_NR] ?? '',
            $data[Investment::FIELD_PROJ_KOD] ?? '',
            (bool)($data[Investment::FIELD_HAS_PROPERTY_PARTS] ?? 0),
            (bool)($data[Investment::FIELD_HAS_BELONGING_ROOMS] ?? 0),
            (bool)($data[Investment::FIELD_HAS_USAGE_RIGHTS] ?? 0),
            (bool)($data[Investment::FIELD_HAS_OTHER_SERVICES] ?? 0),
            $data[Investment::FIELD_CREATED_AT] ?? null,
            $data[Investment::FIELD_UPDATED_AT] ?? null
        );
    }
    
    /**
     * Save investment data (create or update)
     */
    public function save($data) {
        $table = TableNames::getInvestmentInfo();        
        global $wpdb;
        // Check if record already exists
        $existing = $this->read();
        
        if ($existing) {
            // Update existing
            return $wpdb->update($table, $data, ['id' => $existing['id']]);
        } else {
            // Create new
            return $wpdb->insert($table, $data);
        }
    }
}