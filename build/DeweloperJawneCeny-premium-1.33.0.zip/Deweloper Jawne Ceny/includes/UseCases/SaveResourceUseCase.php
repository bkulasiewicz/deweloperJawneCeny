<?php

if (!defined('ABSPATH')) {
    exit;
}

class SaveResourceUseCase {
    
    private $repository;
    private $price_history_repo;
    private $investment_repo;
    private $property_parts_repo;
    private $belonging_rooms_repo;
    private $usage_rights_repo;
    private $other_services_repo;
    
    public function __construct() {
        $this->repository = new ResourceRepository();
        $this->price_history_repo = new PriceHistoryRepository();
        $this->investment_repo = new InvestmentRepository();
        $this->property_parts_repo = new PropertyPartsRepository();
        $this->belonging_rooms_repo = new BelongingRoomsRepository();
        $this->usage_rights_repo = new UsageRightsRepository();
        $this->other_services_repo = new OtherServicesRepository();
    }
    
    public function execute($data, $resource_id = null, $propertyParts = null, $belongingRooms = null, $usageRights = null, $otherServices = null) {
        $validation_errors = $this->validate($data, $resource_id);
        if (!empty($validation_errors)) {
            return ['error' => implode(' ', $validation_errors)];
        }
        
        // Get investment configuration to check which components are enabled
        $investment = $this->investment_repo->read();
        
        if ($resource_id) {
            $old_data = $this->repository->readById($resource_id);
            if (!$old_data) {
                return false;
            }
            
            $result = $this->repository->save($data, $resource_id);
            $final_resource_id = $resource_id;
        } else {
            $result = $this->repository->save($data);
            $final_resource_id = $result;
        }
        
        if ($result !== false) {
            // Save component data based on investment configuration
            $this->saveComponentsIfEnabled($final_resource_id, $investment, $propertyParts, $belongingRooms, $usageRights, $otherServices);
            
            // Save price history
            try {
                if ($resource_id) {
                    $this->price_history_repo->saveHistory($resource_id, $old_data, $data);
                } else {
                    $this->price_history_repo->saveHistory($result, [], $data);
                }
            } catch (Exception $e) {
                Logger::error('UJC Resource: Price history error: ' . $e->getMessage());
            }
        }
        
        return $result;
    }
    
    private function validate($data, $exclude_id = null) {
        $errors = [];
        $table = TableNames::getResources();
        global $wpdb;
        
        if (!empty($data['nr_lokalu'])) {
            if ($exclude_id) {
                $existing = $wpdb->get_var($wpdb->prepare(
                    "SELECT COUNT(*) FROM `{$table}` WHERE nr_lokalu = %s AND id != %d",
                    $data['nr_lokalu'],
                    $exclude_id
                ));
            } else {
                $existing = $wpdb->get_var($wpdb->prepare(
                    "SELECT COUNT(*) FROM `{$table}` WHERE nr_lokalu = %s",
                    $data['nr_lokalu']
                ));
            }
            
            if ($existing > 0) {
                $errors[] = 'Numer lokalu "' . $data['nr_lokalu'] . '" już istnieje. Każdy zasób musi mieć unikalną nazwę.';
            }
        }
        
        return $errors;
    }
    
    private function saveComponentsIfEnabled($resource_id, $investment, $propertyParts, $belongingRooms, $usageRights, $otherServices) {
        if ($investment->hasPropertyParts() && $propertyParts) {
            $this->property_parts_repo->deleteByResourceId($resource_id);
            foreach ($propertyParts as $part) {
                $this->property_parts_repo->save($part, $resource_id);
            }
        }
        
        if ($investment->hasBelongingRooms() && $belongingRooms) {
            $this->belonging_rooms_repo->deleteByResourceId($resource_id);
            foreach ($belongingRooms as $room) {
                $this->belonging_rooms_repo->save($room, $resource_id);
            }
        }
        
        if ($investment->hasUsageRights() && $usageRights) {
            $this->usage_rights_repo->deleteByResourceId($resource_id);
            foreach ($usageRights as $right) {
                $this->usage_rights_repo->save($right, $resource_id);
            }
        }
        
        if ($investment->hasOtherServices() && $otherServices) {
            $this->other_services_repo->deleteByResourceId($resource_id);
            foreach ($otherServices as $service) {
                $this->other_services_repo->save($service, $resource_id);
            }
        }
    }
}