<?php

if (!defined('ABSPATH')) {
    exit;
}

class GetResourceByIdUseCase {
    
    private $repository;
    private $property_parts_repo;
    private $belonging_rooms_repo;
    private $usage_rights_repo;
    private $other_services_repo;
    
    public function __construct() {
        $this->repository = new ResourceRepository();
        $this->property_parts_repo = new PropertyPartsRepository();
        $this->belonging_rooms_repo = new BelongingRoomsRepository();
        $this->usage_rights_repo = new UsageRightsRepository();
        $this->other_services_repo = new OtherServicesRepository();
    }
    
    public function execute($resource_id) {
        $resource = $this->repository->readById($resource_id);
        
        if (!$resource) {
            return null;
        }
        
        // Load all component data
        $property_parts = $this->property_parts_repo->findByResourceId($resource_id);
        $belonging_rooms = $this->belonging_rooms_repo->findByResourceId($resource_id);
        $usage_rights = $this->usage_rights_repo->findByResourceId($resource_id);
        $other_services = $this->other_services_repo->findByResourceId($resource_id);
        
        return new PresentableResource(
            $resource,
            $property_parts,
            $belonging_rooms,
            $usage_rights,
            $other_services
        );
    }
}