<?php

if (!defined('ABSPATH')) {
    exit;
}

/**
 * Resources List Shortcode Handler
 * Handles the [resources_list] shortcode with filtering and customization options
 */
class ResourcesListShortcode {

    // Functional column constants
    public const COLUMN_HISTORIA_CEN = 'historia_cen';
    
    /**
     * Handle resources_list shortcode with type-safe parsing
     * All configuration comes from shortcode parameters with sensible defaults
     */
    public static function handle($atts) {
        // Default columns
        $default_columns = implode(',', [
            ResourceDto::FIELD_NR_LOKALU,
            ResourceDto::FIELD_RODZAJ_NIERUCHOMOSCI,
            ResourceDto::FIELD_POWIERZCHNIA_UZYTKOWA,
            PriceHistoryDto::FIELD_CENA_CALKOWITA,
            ResourceDto::FIELD_STATUS,
            self::COLUMN_HISTORIA_CEN
        ]);

        // Default types - residential units only
        $default_types = PropertyType::RESIDENTIAL_UNIT->value;

        Logger::info('Raw atts before shortcode_atts: ' . print_r($atts, true));

        // Fix WordPress parsing issue - convert indexed array to associative
        if (isset($atts[0]) && is_string($atts[0])) {
            $fixed_atts = [];
            foreach ($atts as $attr_string) {
                if (preg_match('/(\w+)="([^"]*)"/', $attr_string, $matches)) {
                    $fixed_atts[$matches[1]] = $matches[2];
                }
            }
            $atts = $fixed_atts;
            Logger::info('Fixed atts from indexed array: ' . print_r($atts, true));
        }

        $atts = shortcode_atts([
            'types' => $default_types,
            'columns' => $default_columns,
            'detail_page_url' => '',
            'header_bg_color' => '#f9f9f9',
            'header_text_color' => '#333333',
            'button_bg_color' => '#007cba',
            'button_text_color' => '#ffffff',
            'hover_bg_color' => '#f5f5f5',
            'text_color' => '#333333',
            'header_font_family' => 'inherit',
            'content_font_family' => 'inherit',

            // Status styling options (no defaults - set via frontend generator)
            'status_available_bg_color' => '',
            'status_available_text_color' => '',
            'status_sold_bg_color' => '',
            'status_sold_text_color' => '',
            'status_reserved_bg_color' => '',
            'status_reserved_text_color' => '',
            'status_display_style' => '',
            'status_font_size' => '',
            'status_padding' => '',
            'status_border_radius' => '',
            'status_font_weight' => '',

            // Historia Cen button styling
            'historia_btn_text' => '',
            'historia_btn_bg_color' => '',
            'historia_btn_text_color' => '',
            'historia_btn_font_family' => '',
            'historia_btn_font_size' => '',
            'historia_btn_font_weight' => '',
            'historia_btn_padding' => '',
            'historia_btn_border_radius' => '',
            'historia_btn_style' => '', // button, link, badge, pill, plain

            // Karta Lokalu button styling
            'karta_btn_text' => '',
            'karta_btn_bg_color' => '',
            'karta_btn_text_color' => '',
            'karta_btn_font_family' => '',
            'karta_btn_font_size' => '',
            'karta_btn_font_weight' => '',
            'karta_btn_padding' => '',
            'karta_btn_border_radius' => '',
            'karta_btn_style' => '', // button, link, badge, pill, plain
        ], $atts);

        Logger::info('Processed atts after shortcode_atts: ' . print_r($atts, true));

        // Debug: Check if styling parameters are present
        if (!empty($atts['status_display_style'])) {
            Logger::info('Status styling enabled: ' . $atts['status_display_style']);
        }
        if (!empty($atts['historia_btn_text'])) {
            Logger::info('Historia button text: ' . $atts['historia_btn_text']);
        }

        try {
            // Parse property types
            $type_strings = array_map('trim', explode(',', $atts['types']));
            $selected_types = [];
            
            foreach ($type_strings as $type_string) {
                try {
                    $selected_types[] = PropertyType::from($type_string);
                } catch (ValueError $e) {
                    Logger::error("Invalid PropertyType in shortcode: {$type_string}");
                    // Skip invalid types, don't fail completely
                }
            }
            
            // If no valid types, use default
            if (empty($selected_types)) {
                $selected_types = [PropertyType::RESIDENTIAL_UNIT];
            }
            
            // Parse visible columns with names (format: field:name,field2:name2)
            $column_strings = array_map('trim', explode(',', $atts['columns']));
            $visible_columns = [];
            $column_names = [];
            
            $available_columns = [
                // Basic information from ResourceDto
                ResourceDto::FIELD_NR_LOKALU,
                ResourceDto::FIELD_RODZAJ_NIERUCHOMOSCI,
                ResourceDto::FIELD_POWIERZCHNIA_UZYTKOWA,
                ResourceDto::FIELD_STATUS,
                
                // Prices from PriceHistory
                PriceHistoryDto::FIELD_CENA_M2,
                PriceHistoryDto::FIELD_CENA_CALKOWITA,
                PriceHistoryDto::FIELD_CENA_Z_DODATKAMI,
                
                // Marketing fields from ResourceDto
                ResourceDto::FIELD_FLOOR_NUMBER,
                ResourceDto::FIELD_ROOM_COUNT,
                ResourceDto::FIELD_ADDITIONAL_DESCRIPTION,
                ResourceDto::FIELD_GARDEN_AREA,
                ResourceDto::FIELD_FLOOR_PLAN_PDF,
                
                // Functional
                self::COLUMN_HISTORIA_CEN
            ];
            
            foreach ($column_strings as $column_string) {
                if (strpos($column_string, ':') !== false) {
                    [$field, $name] = explode(':', $column_string, 2);
                    $field = trim($field);
                    $name = trim($name);
                    
                    // Replace underscores back to spaces for display
                    $name = str_replace('_', ' ', $name);
                    
                    // Only add if field is valid
                    if (in_array($field, $available_columns)) {
                        $visible_columns[] = $field;
                        $column_names[$field] = $name;
                    } else {
                        Logger::error("Invalid column field in shortcode: {$field}");
                    }
                } else {
                    Logger::error("Column must be in format 'field:name', got: {$column_string}");
                }
            }
            
            // If no valid columns, return error
            if (empty($visible_columns)) {
                Logger::error("No valid columns provided in shortcode");
                return '<div class="ujc-shortcode-error">Błąd: Brak prawidłowych kolumn w formacie field:nazwa.</div>';
            }
            
            // Use provided styling options
            $styling_options = [
                'header_bg_color' => $atts['header_bg_color'],
                'header_text_color' => $atts['header_text_color'],
                'button_bg_color' => $atts['button_bg_color'],
                'button_text_color' => $atts['button_text_color'],
                'hover_bg_color' => $atts['hover_bg_color'],
                'text_color' => $atts['text_color'],
                'header_font_family' => $atts['header_font_family'],
                'content_font_family' => $atts['content_font_family'],

                // Status styling options
                'status_available_bg_color' => $atts['status_available_bg_color'],
                'status_available_text_color' => $atts['status_available_text_color'],
                'status_sold_bg_color' => $atts['status_sold_bg_color'],
                'status_sold_text_color' => $atts['status_sold_text_color'],
                'status_reserved_bg_color' => $atts['status_reserved_bg_color'],
                'status_reserved_text_color' => $atts['status_reserved_text_color'],
                'status_display_style' => $atts['status_display_style'],
                'status_font_size' => $atts['status_font_size'],
                'status_padding' => $atts['status_padding'],
                'status_border_radius' => $atts['status_border_radius'],
                'status_font_weight' => $atts['status_font_weight'],

                // Button styling options
                'historia_btn_text' => $atts['historia_btn_text'],
                'historia_btn_bg_color' => $atts['historia_btn_bg_color'],
                'historia_btn_text_color' => $atts['historia_btn_text_color'],
                'historia_btn_font_family' => $atts['historia_btn_font_family'],
                'historia_btn_font_size' => $atts['historia_btn_font_size'],
                'historia_btn_font_weight' => $atts['historia_btn_font_weight'],
                'historia_btn_padding' => $atts['historia_btn_padding'],
                'historia_btn_border_radius' => $atts['historia_btn_border_radius'],
                'historia_btn_style' => $atts['historia_btn_style'],

                'karta_btn_text' => $atts['karta_btn_text'],
                'karta_btn_bg_color' => $atts['karta_btn_bg_color'],
                'karta_btn_text_color' => $atts['karta_btn_text_color'],
                'karta_btn_font_family' => $atts['karta_btn_font_family'],
                'karta_btn_font_size' => $atts['karta_btn_font_size'],
                'karta_btn_font_weight' => $atts['karta_btn_font_weight'],
                'karta_btn_padding' => $atts['karta_btn_padding'],
                'karta_btn_border_radius' => $atts['karta_btn_border_radius'],
                'karta_btn_style' => $atts['karta_btn_style'],
            ];
            
            // Render the resources table
            return self::render_resources_table($selected_types, $visible_columns, $column_names, $styling_options, $atts['detail_page_url']);
            
        } catch (Exception $e) {
            Logger::error("Shortcode error: " . $e->getMessage());
            return '<div class="ujc-shortcode-error">Błąd podczas ładowania zasobów.</div>';
        }
    }
    
    /**
     * Render resources table for shortcode
     */
    private static function render_resources_table(array $selected_types, array $visible_columns, array $column_names, array $styling_options, string $detail_page_url = ''): string {
        Logger::info("Shortcode: render_resources_table started");
        Logger::info("Shortcode: Selected types count: " . count($selected_types));
        Logger::info("Shortcode: Selected type values: " . implode(', ', array_map(fn($type) => $type->value, $selected_types)));
        
        // Get resources using dedicated frontend UseCase with built-in filtering
        $frontend_use_case = new GetResourcesForFrontendUseCase();
        $filtered_resources = $frontend_use_case->execute($selected_types);
        Logger::info("Shortcode: Got " . count($filtered_resources) . " filtered resources from GetResourcesForFrontendUseCase");
        
        if (empty($filtered_resources)) {
            Logger::error("Shortcode: No resources to display");
            return '<div class="ujc-no-resources">Brak zasobów do wyświetlenia.</div>';
        }
        
        // Start output buffering
        ob_start();

        // Generate dynamic CSS
        self::render_dynamic_css($styling_options, !empty($detail_page_url));
        
        ?>
        <div class="ujc-shortcode-resources-list">
            <table class="resources-table">
                <thead>
                    <tr>
                        <?php foreach ($visible_columns as $column): ?>
                            <th><?php echo esc_html($column_names[$column] ?? ucfirst($column)); ?></th>
                        <?php endforeach; ?>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($filtered_resources as $resource): ?>
                        <?php
                        $row_classes = [];
                        $row_attributes = [];

                        // Make row clickable if detail_page_url is provided
                        if (!empty($detail_page_url)) {
                            $row_classes[] = 'clickable-row';
                            $detail_url = rtrim($detail_page_url, '/') . '/' . urlencode($resource->nr_lokalu);
                            $row_attributes[] = 'data-detail-url="' . esc_attr($detail_url) . '"';
                        }

                        $class_attr = !empty($row_classes) ? ' class="' . esc_attr(implode(' ', $row_classes)) . '"' : '';
                        $data_attrs = !empty($row_attributes) ? ' ' . implode(' ', $row_attributes) : '';
                        ?>
                        <tr<?php echo $class_attr . $data_attrs; ?>>
                            <?php foreach ($visible_columns as $column): ?>
                                <td><?php echo self::render_column_value($resource, $column, $styling_options); ?></td>
                            <?php endforeach; ?>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
            
            <!-- Price History Modal (same as in existing block) -->
            <div id="price-history-modal" class="price-history-modal" style="display: none;">
                <div class="modal-content">
                    <div class="modal-header">
                        <h3>Historia cen - <span id="modal-resource-name"></span></h3>
                        <button class="modal-close">&times;</button>
                    </div>
                    <div class="modal-body">
                        <div id="history-loading">Ładowanie...</div>
                        <div id="history-content"></div>
                    </div>
                </div>
            </div>
        </div>

        <?php if (!empty($detail_page_url)): ?>
        <?php
        // Enqueue the clickable rows JavaScript with jQuery dependency
        wp_enqueue_script(
            'ujc-clickable-rows',
            plugins_url('assets/frontend-clickable-rows.js', dirname(dirname(__DIR__)) . '/ustawa-jawnosci-cen.php'),
            ['jquery'],
            '1.0.1',
            true
        );

        ?>
        <?php endif; ?>
        <?php

        return ob_get_clean();
    }
    
    /**
     * Render individual column value
     */
    private static function render_column_value($resource, string $column, array $styling_options = []): string {
        switch ($column) {
            case ResourceDto::FIELD_NR_LOKALU:
                return esc_html($resource->nr_lokalu);
                
            case ResourceDto::FIELD_RODZAJ_NIERUCHOMOSCI:
                try {
                    $propertyType = PropertyType::from($resource->rodzaj_nieruchomosci);
                    return esc_html($propertyType->getDisplayText());
                } catch (ValueError $e) {
                    return esc_html($resource->rodzaj_nieruchomosci);
                }
                
            case ResourceDto::FIELD_POWIERZCHNIA_UZYTKOWA:
                // Hide surface area for parking spaces (existing logic)
                if ($resource->rodzaj_nieruchomosci === PropertyType::PARKING_SPACE->value) {
                    return '—';
                }
                return esc_html(number_format($resource->powierzchnia_uzytkowa, 2, ',', ' ')) . ' m²';
                
            case ResourceDto::FIELD_STATUS:
                try {
                    $status = ResourceStatus::from($resource->status);
                    $status_value = $resource->status;
                    $status_text = $status->getDisplayText();

                    // Get display style
                    $display_style = $styling_options['status_display_style'] ?? 'badge';

                    // Build CSS classes
                    $css_classes = ['ujc-status', 'ujc-status-' . $status_value, 'ujc-status-style-' . $display_style];

                    return '<span class="' . esc_attr(implode(' ', $css_classes)) . '">' . esc_html($status_text) . '</span>';
                } catch (ValueError $e) {
                    return esc_html($resource->status);
                }
                
            case PriceHistoryDto::FIELD_CENA_M2:
                // Hide price per m2 for parking spaces (existing logic)
                if ($resource->rodzaj_nieruchomosci === PropertyType::PARKING_SPACE->value) {
                    return '—';
                }
                if ($resource->cena_m2 !== null && $resource->cena_m2 > 0) {
                    return esc_html(number_format($resource->cena_m2, 2, ',', ' ')) . ' zł';
                }
                return '—';
                
            case PriceHistoryDto::FIELD_CENA_CALKOWITA:
                if ($resource->cena_calkowita) {
                    return esc_html(number_format($resource->cena_calkowita, 2, ',', ' ')) . ' zł';
                }
                return '—';
                
            case PriceHistoryDto::FIELD_CENA_Z_DODATKAMI:
                if ($resource->cena_z_dodatkami) {
                    return esc_html(number_format($resource->cena_z_dodatkami, 2, ',', ' ')) . ' zł';
                }
                return '—';
                
            case self::COLUMN_HISTORIA_CEN:
                $btn_text = !empty($styling_options['historia_btn_text']) ? $styling_options['historia_btn_text'] : 'Historia';
                $btn_style = !empty($styling_options['historia_btn_style']) ? $styling_options['historia_btn_style'] : 'button';

                $css_classes = ['price-history-btn', 'ujc-historia-btn', 'ujc-btn-style-' . $btn_style];

                return '<button class="' . esc_attr(implode(' ', $css_classes)) . '" data-resource-id="' . esc_attr($resource->id) . '" data-resource-name="' . esc_attr($resource->nr_lokalu) . '">' . esc_html($btn_text) . '</button>';
                
            // Marketing fields
            case ResourceDto::FIELD_FLOOR_NUMBER:
                return $resource->floor_number ? esc_html($resource->floor_number) : '—';
                
            case ResourceDto::FIELD_ROOM_COUNT:
                return $resource->room_count ? esc_html($resource->room_count) : '—';
                
            case ResourceDto::FIELD_ADDITIONAL_DESCRIPTION:
                return $resource->additional_description ? esc_html(wp_trim_words($resource->additional_description, 10)) : '—';
                
            case ResourceDto::FIELD_GARDEN_AREA:
                return $resource->garden_area ? esc_html(number_format($resource->garden_area, 2, ',', ' ')) . ' m²' : '—';
                
            case ResourceDto::FIELD_FLOOR_PLAN_PDF:
                if ($resource->floor_plan_pdf) {
                    $filename = basename($resource->floor_plan_pdf);
                    $btn_text = !empty($styling_options['karta_btn_text']) ? $styling_options['karta_btn_text'] : 'Karta lokalu';
                    $btn_style = !empty($styling_options['karta_btn_style']) ? $styling_options['karta_btn_style'] : 'button';

                    $css_classes = ['download-floorplan-btn', 'ujc-karta-btn', 'ujc-btn-style-' . $btn_style];

                    return '<button class="' . esc_attr(implode(' ', $css_classes)) . '" data-filename="' . esc_attr($filename) . '">' . esc_html($btn_text) . '</button>';
                }
                return '—';
                
            default:
                return '—';
        }
    }
    
    /**
     * Render dynamic CSS with custom styling options
     */
    private static function render_dynamic_css(array $styling_options, bool $has_clickable_rows = false): void {
        Logger::info('render_dynamic_css called with styling_options: ' . print_r($styling_options, true));
        ?>
        <style>
        /* Headers */
        .ujc-shortcode-resources-list .resources-table th {
            background-color: <?php echo esc_attr($styling_options['header_bg_color']); ?>;
            color: <?php echo esc_attr($styling_options['header_text_color']); ?>;
            font-family: <?php echo esc_attr($styling_options['header_font_family']); ?>;
            font-weight: 600;
            padding: 12px 8px;
            text-align: left;
            border-bottom: 1px solid #ddd;
        }
        
        /* Content cells */
        .ujc-shortcode-resources-list .resources-table td {
            color: <?php echo esc_attr($styling_options['text_color']); ?>;
            font-family: <?php echo esc_attr($styling_options['content_font_family']); ?>;
            padding: 12px 8px;
            text-align: left;
            border-bottom: 1px solid #ddd;
        }
        
        /* Table structure */
        .ujc-shortcode-resources-list .resources-table {
            width: 100%;
            border-collapse: collapse;
            margin: 1em 0;
        }
        
        /* Row hover */
        .ujc-shortcode-resources-list .resources-table tbody tr:hover {
            background-color: <?php echo esc_attr($styling_options['hover_bg_color']); ?>;
        }
        
        /* Individual Button Styling - Historia */
        <?php
        Logger::info('Historia button check: style=' . ($styling_options['historia_btn_style'] ?? 'empty') . ', bg_color=' . ($styling_options['historia_btn_bg_color'] ?? 'empty'));
        if (!empty($styling_options['historia_btn_style']) || !empty($styling_options['historia_btn_bg_color'])): ?>
        /* HISTORIA CSS BLOCK ACTIVATED */
        .ujc-shortcode-resources-list .ujc-historia-btn {
            <?php if (!empty($styling_options['historia_btn_bg_color'])): ?>
            background-color: <?php echo esc_attr($styling_options['historia_btn_bg_color']); ?> !important;
            <?php endif; ?>
            <?php if (!empty($styling_options['historia_btn_text_color'])): ?>
            color: <?php echo esc_attr($styling_options['historia_btn_text_color']); ?> !important;
            <?php endif; ?>
            <?php if (!empty($styling_options['historia_btn_font_family'])): ?>
            font-family: <?php echo esc_attr($styling_options['historia_btn_font_family']); ?>;
            <?php endif; ?>
            <?php if (!empty($styling_options['historia_btn_font_size'])): ?>
            font-size: <?php echo esc_attr($styling_options['historia_btn_font_size']); ?>;
            <?php endif; ?>
            <?php if (!empty($styling_options['historia_btn_font_weight'])): ?>
            font-weight: <?php echo esc_attr($styling_options['historia_btn_font_weight']); ?>;
            <?php endif; ?>
            <?php if (!empty($styling_options['historia_btn_padding'])): ?>
            padding: <?php echo esc_attr($styling_options['historia_btn_padding']); ?>;
            <?php endif; ?>
            <?php if (!empty($styling_options['historia_btn_border_radius'])): ?>
            border-radius: <?php echo esc_attr($styling_options['historia_btn_border_radius']); ?>;
            <?php endif; ?>
            cursor: pointer;
            transition: opacity 0.2s;
        }

        .ujc-shortcode-resources-list .ujc-historia-btn:hover {
            opacity: 0.8;
        }
        <?php endif; ?>

        /* Individual Button Styling - Karta Lokalu */
        <?php if (!empty($styling_options['karta_btn_style']) || !empty($styling_options['karta_btn_bg_color'])): ?>
        .ujc-shortcode-resources-list .ujc-karta-btn {
            <?php if (!empty($styling_options['karta_btn_bg_color'])): ?>
            background-color: <?php echo esc_attr($styling_options['karta_btn_bg_color']); ?> !important;
            <?php endif; ?>
            <?php if (!empty($styling_options['karta_btn_text_color'])): ?>
            color: <?php echo esc_attr($styling_options['karta_btn_text_color']); ?> !important;
            <?php endif; ?>
            <?php if (!empty($styling_options['karta_btn_font_family'])): ?>
            font-family: <?php echo esc_attr($styling_options['karta_btn_font_family']); ?>;
            <?php endif; ?>
            <?php if (!empty($styling_options['karta_btn_font_size'])): ?>
            font-size: <?php echo esc_attr($styling_options['karta_btn_font_size']); ?>;
            <?php endif; ?>
            <?php if (!empty($styling_options['karta_btn_font_weight'])): ?>
            font-weight: <?php echo esc_attr($styling_options['karta_btn_font_weight']); ?>;
            <?php endif; ?>
            <?php if (!empty($styling_options['karta_btn_padding'])): ?>
            padding: <?php echo esc_attr($styling_options['karta_btn_padding']); ?>;
            <?php endif; ?>
            <?php if (!empty($styling_options['karta_btn_border_radius'])): ?>
            border-radius: <?php echo esc_attr($styling_options['karta_btn_border_radius']); ?>;
            <?php endif; ?>
            cursor: pointer;
            transition: opacity 0.2s;
        }

        .ujc-shortcode-resources-list .ujc-karta-btn:hover {
            opacity: 0.8;
        }
        <?php endif; ?>

        /* Button Styles - Individual */
        <?php
        $historia_style = $styling_options['historia_btn_style'];
        $karta_style = $styling_options['karta_btn_style'];
        ?>

        <?php if ($historia_style === 'link'): ?>
        .ujc-shortcode-resources-list .ujc-historia-btn.ujc-btn-style-link {
            background: none !important;
            border: none;
            padding: 0;
            text-decoration: underline;
        }
        <?php endif; ?>

        <?php if ($historia_style === 'badge'): ?>
        .ujc-shortcode-resources-list .ujc-historia-btn.ujc-btn-style-badge {
            border: 1px solid currentColor;
        }
        <?php endif; ?>

        <?php if ($historia_style === 'pill'): ?>
        .ujc-shortcode-resources-list .ujc-historia-btn.ujc-btn-style-pill {
            border-radius: 50px !important;
            border: none;
        }
        <?php endif; ?>

        <?php if ($historia_style === 'plain'): ?>
        .ujc-shortcode-resources-list .ujc-historia-btn.ujc-btn-style-plain {
            background: none !important;
            border: none;
            padding: 0;
            text-decoration: none;
        }
        <?php endif; ?>

        <?php if ($karta_style === 'link'): ?>
        .ujc-shortcode-resources-list .ujc-karta-btn.ujc-btn-style-link {
            background: none !important;
            border: none;
            padding: 0;
            text-decoration: underline;
        }
        <?php endif; ?>

        <?php if ($karta_style === 'badge'): ?>
        .ujc-shortcode-resources-list .ujc-karta-btn.ujc-btn-style-badge {
            border: 1px solid currentColor;
        }
        <?php endif; ?>

        <?php if ($karta_style === 'pill'): ?>
        .ujc-shortcode-resources-list .ujc-karta-btn.ujc-btn-style-pill {
            border-radius: 50px !important;
            border: none;
        }
        <?php endif; ?>

        <?php if ($karta_style === 'plain'): ?>
        .ujc-shortcode-resources-list .ujc-karta-btn.ujc-btn-style-plain {
            background: none !important;
            border: none;
            padding: 0;
            text-decoration: none;
        }
        <?php endif; ?>

        /* Fallback styling for buttons without custom styling */
        .ujc-shortcode-resources-list .price-history-btn:not(.ujc-historia-btn),
        .ujc-shortcode-resources-list .download-floorplan-btn:not(.ujc-karta-btn) {
            background-color: <?php echo esc_attr($styling_options['button_bg_color']); ?>;
            color: <?php echo esc_attr($styling_options['button_text_color']); ?>;
            border: none;
            padding: 6px 12px;
            border-radius: 4px;
            cursor: pointer;
            font-size: 0.875em;
            transition: background-color 0.2s;
        }

        .ujc-shortcode-resources-list .price-history-btn:not(.ujc-historia-btn):hover,
        .ujc-shortcode-resources-list .download-floorplan-btn:not(.ujc-karta-btn):hover {
            opacity: 0.8;
        }
        
        /* Clickable rows styling */
        <?php if ($has_clickable_rows): ?>
        .ujc-shortcode-resources-list .clickable-row {
            cursor: pointer;
            transition: background-color 0.2s;
        }

        .ujc-shortcode-resources-list .clickable-row:hover {
            background-color: <?php echo esc_attr($styling_options['hover_bg_color']); ?> !important;
        }
        <?php endif; ?>

        <?php if (!empty($styling_options['status_display_style'])): ?>
        /* Status styling */
        .ujc-shortcode-resources-list .ujc-status {
            display: inline-block;
            line-height: 1.2;
            <?php if (!empty($styling_options['status_font_size'])): ?>
            font-size: <?php echo esc_attr($styling_options['status_font_size']); ?>;
            <?php endif; ?>
            <?php if (!empty($styling_options['status_font_weight'])): ?>
            font-weight: <?php echo esc_attr($styling_options['status_font_weight']); ?>;
            <?php endif; ?>
        }

        /* Status colors by type */
        <?php if (!empty($styling_options['status_available_bg_color']) || !empty($styling_options['status_available_text_color'])): ?>
        .ujc-shortcode-resources-list .ujc-status-available {
            <?php if (!empty($styling_options['status_available_bg_color'])): ?>
            background-color: <?php echo esc_attr($styling_options['status_available_bg_color']); ?> !important;
            <?php endif; ?>
            <?php if (!empty($styling_options['status_available_text_color'])): ?>
            color: <?php echo esc_attr($styling_options['status_available_text_color']); ?> !important;
            <?php endif; ?>
        }
        <?php endif; ?>

        <?php if (!empty($styling_options['status_sold_bg_color']) || !empty($styling_options['status_sold_text_color'])): ?>
        .ujc-shortcode-resources-list .ujc-status-sold {
            <?php if (!empty($styling_options['status_sold_bg_color'])): ?>
            background-color: <?php echo esc_attr($styling_options['status_sold_bg_color']); ?> !important;
            <?php endif; ?>
            <?php if (!empty($styling_options['status_sold_text_color'])): ?>
            color: <?php echo esc_attr($styling_options['status_sold_text_color']); ?> !important;
            <?php endif; ?>
        }
        <?php endif; ?>

        <?php if (!empty($styling_options['status_reserved_bg_color']) || !empty($styling_options['status_reserved_text_color'])): ?>
        .ujc-shortcode-resources-list .ujc-status-reserved {
            <?php if (!empty($styling_options['status_reserved_bg_color'])): ?>
            background-color: <?php echo esc_attr($styling_options['status_reserved_bg_color']); ?> !important;
            <?php endif; ?>
            <?php if (!empty($styling_options['status_reserved_text_color'])): ?>
            color: <?php echo esc_attr($styling_options['status_reserved_text_color']); ?> !important;
            <?php endif; ?>
        }
        <?php endif; ?>

        /* Status display styles */
        <?php
        $display_style = $styling_options['status_display_style'];
        $status_padding = $styling_options['status_padding'];
        $status_border_radius = $styling_options['status_border_radius'];
        ?>

        <?php if ($display_style === 'badge'): ?>
        .ujc-shortcode-resources-list .ujc-status-style-badge {
            <?php if (!empty($status_padding)): ?>padding: <?php echo esc_attr($status_padding); ?>;<?php endif; ?>
            <?php if (!empty($status_border_radius)): ?>border-radius: <?php echo esc_attr($status_border_radius); ?>;<?php endif; ?>
            border: 1px solid rgba(0,0,0,0.1);
        }
        <?php endif; ?>

        <?php if ($display_style === 'pill'): ?>
        .ujc-shortcode-resources-list .ujc-status-style-pill {
            <?php if (!empty($status_padding)): ?>padding: <?php echo esc_attr($status_padding); ?>;<?php endif; ?>
            border-radius: 50px;
            border: none;
        }
        <?php endif; ?>

        <?php if ($display_style === 'underline'): ?>
        .ujc-shortcode-resources-list .ujc-status-style-underline {
            padding: 2px 0;
            border-bottom: 2px solid currentColor;
            background-color: transparent !important;
            border-radius: 0;
        }
        <?php endif; ?>

        <?php if ($display_style === 'highlight'): ?>
        .ujc-shortcode-resources-list .ujc-status-style-highlight {
            <?php if (!empty($status_padding)): ?>padding: <?php echo esc_attr($status_padding); ?>;<?php endif; ?>
            <?php if (!empty($status_border_radius)): ?>border-radius: <?php echo esc_attr($status_border_radius); ?>;<?php endif; ?>
            opacity: 0.8;
        }
        <?php endif; ?>

        <?php if ($display_style === 'plain'): ?>
        .ujc-shortcode-resources-list .ujc-status-style-plain {
            padding: 0;
            background-color: transparent !important;
            border: none;
            border-radius: 0;
        }
        <?php endif; ?>
        <?php endif; ?>

        /* Error and no resources messages */
        .ujc-shortcode-resources-list .ujc-no-resources {
            padding: 20px;
            text-align: center;
            color: #666;
            font-style: italic;
        }

        .ujc-shortcode-resources-list .ujc-shortcode-error {
            padding: 15px;
            background-color: #ffebee;
            color: #c62828;
            border: 1px solid #ffcdd2;
            border-radius: 4px;
            margin: 10px 0;
        }
        </style>
        <?php
    }
}