(function() {
    const { registerBlockType } = wp.blocks;
    const { createElement: el, Fragment } = wp.element;
    const { InspectorControls } = wp.blockEditor;
    const { PanelBody, CheckboxControl, ColorPicker, TextControl, SelectControl } = wp.components;

    // Available columns with their default names
    const AVAILABLE_COLUMNS = {
        'nr_lokalu': 'Numer lokalu',
        'rodzaj_nieruchomosci': 'Typ nieruchomości',
        'powierzchnia_uzytkowa': 'Powierzchnia',
        'status': 'Status',
        'cena_m2': 'Cena za m²',
        'cena_calkowita': 'Cena całkowita',
        'cena_z_dodatkami': 'Cena z dodatkami',
        'floor_number': 'Piętro',
        'room_count': 'Pokoje',
        'additional_description': 'Opis',
        'garden_area': 'Ogród',
        'floor_plan_pdf': 'Plan',
        'historia_cen': 'Historia cen'
    };

    // Available property types
    const PROPERTY_TYPES = {
        'residential_unit': 'Lokale mieszkalne',
        'single_family_house': 'Domy jednorodzinne',
        'service_premises': 'Lokale usługowe',
        'parking_space': 'Miejsca postojowe',
        'storage_room': 'Komórki lokatorskie',
        'garage': 'Garaże'
    };

    // Font options
    const FONT_OPTIONS = [
        { label: 'Domyślna', value: 'inherit' },
        { label: 'Arial', value: 'Arial, sans-serif' },
        { label: 'Helvetica', value: 'Helvetica, sans-serif' },
        { label: 'Georgia', value: 'Georgia, serif' },
        { label: 'Times New Roman', value: '"Times New Roman", serif' },
        { label: 'Verdana', value: 'Verdana, sans-serif' }
    ];

    registerBlockType('jawne-ceny/resources-list', {
        title: 'Lista Zasobów',
        description: 'Wyświetla listę mieszkań/zasobów z cenami - z pełną personalizacją',
        category: 'widgets',
        icon: 'list-view',
        keywords: ['mieszkania', 'zasoby', 'ceny', 'lista', 'nieruchomości'],

        attributes: {
            // Column configuration
            visibleColumns: {
                type: 'array',
                default: ['nr_lokalu', 'rodzaj_nieruchomosci', 'powierzchnia_uzytkowa', 'cena_calkowita', 'status', 'historia_cen']
            },
            columnOrder: {
                type: 'array',
                default: ['nr_lokalu', 'rodzaj_nieruchomosci', 'powierzchnia_uzytkowa', 'cena_calkowita', 'status', 'historia_cen']
            },
            columnNames: {
                type: 'object',
                default: {}
            },

            // Property type filtering
            selectedTypes: {
                type: 'array',
                default: ['residential_unit']
            },

            // Styling options
            headerBgColor: {
                type: 'string',
                default: '#f9f9f9'
            },
            headerTextColor: {
                type: 'string',
                default: '#333333'
            },
            textColor: {
                type: 'string',
                default: '#333333'
            },
            hoverBgColor: {
                type: 'string',
                default: '#f5f5f5'
            },
            headerFontFamily: {
                type: 'string',
                default: 'inherit'
            },
            contentFontFamily: {
                type: 'string',
                default: 'inherit'
            },

            // Interactive options
            detailPageUrl: {
                type: 'string',
                default: ''
            },

            // Button customization
            historiaBtnText: {
                type: 'string',
                default: 'Historia'
            },
            historiaBtnBgColor: {
                type: 'string',
                default: '#007cba'
            },
            historiaBtnTextColor: {
                type: 'string',
                default: '#ffffff'
            },

            kartaBtnText: {
                type: 'string',
                default: 'Karta lokalu'
            },
            kartaBtnBgColor: {
                type: 'string',
                default: '#007cba'
            },
            kartaBtnTextColor: {
                type: 'string',
                default: '#ffffff'
            }
        },

        edit: function(props) {
            const { attributes, setAttributes } = props;

            // Helper function to handle column visibility
            const toggleColumn = function(column, checked) {
                const newColumns = checked
                    ? [...attributes.visibleColumns, column]
                    : attributes.visibleColumns.filter(col => col !== column);

                setAttributes({ visibleColumns: newColumns });

                // Update column order to match visible columns
                const newOrder = attributes.columnOrder.filter(col => newColumns.includes(col));
                const missingColumns = newColumns.filter(col => !newOrder.includes(col));
                setAttributes({ columnOrder: [...newOrder, ...missingColumns] });
            };

            // Helper function to handle property type selection
            const togglePropertyType = function(type, checked) {
                const newTypes = checked
                    ? [...attributes.selectedTypes, type]
                    : attributes.selectedTypes.filter(t => t !== type);

                setAttributes({ selectedTypes: newTypes });
            };

            // Helper function to update column name
            const updateColumnName = function(column, newName) {
                const newNames = { ...attributes.columnNames };
                if (newName && newName !== AVAILABLE_COLUMNS[column]) {
                    newNames[column] = newName;
                } else {
                    delete newNames[column];
                }
                setAttributes({ columnNames: newNames });
            };

            return el(Fragment, {},
                // Inspector Controls (sidebar panel)
                el(InspectorControls, {},

                    // Property Types Panel
                    el(PanelBody, {
                        title: 'Typy nieruchomości',
                        initialOpen: true
                    },
                        Object.entries(PROPERTY_TYPES).map(([value, label]) =>
                            el(CheckboxControl, {
                                key: value,
                                label: label,
                                checked: attributes.selectedTypes.includes(value),
                                onChange: (checked) => togglePropertyType(value, checked)
                            })
                        )
                    ),

                    // Visible Columns Panel
                    el(PanelBody, {
                        title: 'Widoczne kolumny',
                        initialOpen: true
                    },
                        Object.entries(AVAILABLE_COLUMNS).map(([column, defaultName]) =>
                            el('div', {
                                key: column,
                                style: {
                                    marginBottom: '12px',
                                    padding: '8px',
                                    border: '1px solid #ddd',
                                    borderRadius: '4px'
                                }
                            },
                                el(CheckboxControl, {
                                    label: defaultName,
                                    checked: attributes.visibleColumns.includes(column),
                                    onChange: (checked) => toggleColumn(column, checked)
                                }),
                                attributes.visibleColumns.includes(column) && el(TextControl, {
                                    label: 'Nazwa kolumny',
                                    placeholder: defaultName,
                                    value: attributes.columnNames[column] || '',
                                    onChange: (value) => updateColumnName(column, value),
                                    help: 'Pozostaw puste dla domyślnej nazwy'
                                })
                            )
                        )
                    ),

                    // Styling Panel
                    el(PanelBody, {
                        title: 'Stylizacja tabeli',
                        initialOpen: false
                    },
                        el('div', { style: { marginBottom: '16px' } },
                            el('label', { style: { display: 'block', marginBottom: '8px', fontWeight: 'bold' } }, 'Kolor tła nagłówka'),
                            el(ColorPicker, {
                                color: attributes.headerBgColor,
                                onChangeComplete: (color) => setAttributes({ headerBgColor: color.hex }),
                                disableAlpha: true
                            })
                        ),
                        el('div', { style: { marginBottom: '16px' } },
                            el('label', { style: { display: 'block', marginBottom: '8px', fontWeight: 'bold' } }, 'Kolor tekstu nagłówka'),
                            el(ColorPicker, {
                                color: attributes.headerTextColor,
                                onChangeComplete: (color) => setAttributes({ headerTextColor: color.hex }),
                                disableAlpha: true
                            })
                        ),
                        el('div', { style: { marginBottom: '16px' } },
                            el('label', { style: { display: 'block', marginBottom: '8px', fontWeight: 'bold' } }, 'Kolor tekstu treści'),
                            el(ColorPicker, {
                                color: attributes.textColor,
                                onChangeComplete: (color) => setAttributes({ textColor: color.hex }),
                                disableAlpha: true
                            })
                        ),
                        el('div', { style: { marginBottom: '16px' } },
                            el('label', { style: { display: 'block', marginBottom: '8px', fontWeight: 'bold' } }, 'Kolor hover'),
                            el(ColorPicker, {
                                color: attributes.hoverBgColor,
                                onChangeComplete: (color) => setAttributes({ hoverBgColor: color.hex }),
                                disableAlpha: true
                            })
                        ),
                        el(SelectControl, {
                            label: 'Czcionka nagłówków',
                            value: attributes.headerFontFamily,
                            options: FONT_OPTIONS,
                            onChange: (value) => setAttributes({ headerFontFamily: value })
                        }),
                        el(SelectControl, {
                            label: 'Czcionka treści',
                            value: attributes.contentFontFamily,
                            options: FONT_OPTIONS,
                            onChange: (value) => setAttributes({ contentFontFamily: value })
                        })
                    ),

                    // Interactive Features Panel
                    el(PanelBody, {
                        title: 'Funkcje interaktywne',
                        initialOpen: false
                    },
                        el(TextControl, {
                            label: 'URL strony szczegółów',
                            placeholder: '/mieszkania/',
                            value: attributes.detailPageUrl,
                            onChange: (value) => setAttributes({ detailPageUrl: value }),
                            help: 'Gdy ustawione, wiersze będą klikaln'
                        }),
                        el('hr'),
                        el('h4', { style: { margin: '16px 0 8px' } }, 'Przycisk Historia Cen'),
                        el(TextControl, {
                            label: 'Tekst przycisku',
                            value: attributes.historiaBtnText,
                            onChange: (value) => setAttributes({ historiaBtnText: value })
                        }),
                        el('div', { style: { marginBottom: '12px' } },
                            el('label', { style: { display: 'block', marginBottom: '4px' } }, 'Kolor tła'),
                            el(ColorPicker, {
                                color: attributes.historiaBtnBgColor,
                                onChangeComplete: (color) => setAttributes({ historiaBtnBgColor: color.hex }),
                                disableAlpha: true
                            })
                        ),
                        el('div', { style: { marginBottom: '16px' } },
                            el('label', { style: { display: 'block', marginBottom: '4px' } }, 'Kolor tekstu'),
                            el(ColorPicker, {
                                color: attributes.historiaBtnTextColor,
                                onChangeComplete: (color) => setAttributes({ historiaBtnTextColor: color.hex }),
                                disableAlpha: true
                            })
                        ),
                        el('hr'),
                        el('h4', { style: { margin: '16px 0 8px' } }, 'Przycisk Karta Lokalu'),
                        el(TextControl, {
                            label: 'Tekst przycisku',
                            value: attributes.kartaBtnText,
                            onChange: (value) => setAttributes({ kartaBtnText: value })
                        }),
                        el('div', { style: { marginBottom: '12px' } },
                            el('label', { style: { display: 'block', marginBottom: '4px' } }, 'Kolor tła'),
                            el(ColorPicker, {
                                color: attributes.kartaBtnBgColor,
                                onChangeComplete: (color) => setAttributes({ kartaBtnBgColor: color.hex }),
                                disableAlpha: true
                            })
                        ),
                        el('div', { style: { marginBottom: '16px' } },
                            el('label', { style: { display: 'block', marginBottom: '4px' } }, 'Kolor tekstu'),
                            el(ColorPicker, {
                                color: attributes.kartaBtnTextColor,
                                onChangeComplete: (color) => setAttributes({ kartaBtnTextColor: color.hex }),
                                disableAlpha: true
                            })
                        )
                    )
                ),

                // Block preview in editor
                el('div', {
                    className: 'resources-list-block-placeholder',
                    style: {
                        padding: '20px',
                        textAlign: 'center',
                        border: '2px dashed #ccc',
                        borderRadius: '4px',
                        backgroundColor: '#f9f9f9',
                        position: 'relative'
                    }
                },
                    el('div', {
                        style: {
                            fontSize: '24px',
                            marginBottom: '8px'
                        }
                    }, '📋'),
                    el('h3', {
                        style: {
                            margin: '0 0 8px',
                            color: '#666',
                            fontSize: '18px'
                        }
                    }, 'Lista Zasobów'),
                    el('p', {
                        style: {
                            margin: '0 0 16px',
                            color: '#999',
                            fontSize: '14px'
                        }
                    }, 'Spersonalizowana tabela z nieruchomościami'),

                    // Configuration summary
                    el('div', {
                        style: {
                            backgroundColor: 'white',
                            border: '1px solid #ddd',
                            borderRadius: '4px',
                            padding: '12px',
                            textAlign: 'left',
                            fontSize: '12px',
                            color: '#666'
                        }
                    },
                        el('div', { style: { marginBottom: '4px' } },
                            '🏠 Typy: ', attributes.selectedTypes.length,
                            attributes.selectedTypes.length === 1 ? ' typ' : ' typy'
                        ),
                        el('div', { style: { marginBottom: '4px' } },
                            '📊 Kolumny: ', attributes.visibleColumns.length,
                            attributes.visibleColumns.length === 1 ? ' kolumna' : ' kolumn'
                        ),
                        el('div', {},
                            '🎨 Kolory: ',
                            attributes.headerBgColor !== '#f9f9f9' ||
                            attributes.headerTextColor !== '#333333' ||
                            attributes.textColor !== '#333333' ? 'Spersonalizowane' : 'Domyślne'
                        )
                    )
                )
            );
        },

        save: function() {
            // Return null since we're using server-side rendering
            return null;
        }
    });
})();