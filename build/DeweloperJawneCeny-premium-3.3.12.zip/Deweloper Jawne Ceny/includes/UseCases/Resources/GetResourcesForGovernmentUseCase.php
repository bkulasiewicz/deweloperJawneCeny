<?php

if (!defined('ABSPATH')) {
    exit;
}

/**
 * UseCase for getting resources filtered for government reporting
 * Excludes service premises from the results as they are not reported to the ministry
 */
class GetResourcesForGovernmentUseCase {
    
    private $getAllResourcesUseCase;
    
    public function __construct() {
        $this->getAllResourcesUseCase = new GetAllResourcesUseCase();
    }
    
    /**
     * Execute the use case
     * @return array Filtered array of ResourceDto objects (excluding service premises)
     */
    public function execute(): array {
        // Get all resources
        $allResources = $this->getAllResourcesUseCase->execute();
        
        // Filter out service premises
        $governmentResources = array_filter($allResources, function($resource) {
            return $resource->getRodzajNieruchomosci() !== PropertyType::SERVICE_PREMISES->value;
        });
        
        // Re-index array to maintain consistent indexing
        return array_values($governmentResources);
    }
}