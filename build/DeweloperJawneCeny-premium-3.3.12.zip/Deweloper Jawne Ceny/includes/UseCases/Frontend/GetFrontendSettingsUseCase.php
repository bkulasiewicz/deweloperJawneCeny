<?php

if (!defined('ABSPATH')) {
    exit;
}

/**
 * Use case for retrieving frontend settings
 */
class GetFrontendSettingsUseCase {
    
    private $repository;
    
    public function __construct() {
        $this->repository = new FrontendSettingsRepository();
    }
    
    /**
     * Execute the get operation
     */
    public function execute(): FrontendSettingsDto {
        Logger::info("GetFrontendSettingsUseCase::execute - Loading frontend settings");
        
        try {
            $settings = $this->repository->load();
            
            if ($settings === null) {
                Logger::info("GetFrontendSettingsUseCase::execute - No settings found, creating defaults");
                return $this->getDefaultSettings();
            }
            
            Logger::info("GetFrontendSettingsUseCase::execute - Settings loaded successfully");
            return $settings;
            
        } catch (Exception $e) {
            Logger::error("GetFrontendSettingsUseCase::execute - Exception: " . $e->getMessage());
            Logger::info("GetFrontendSettingsUseCase::execute - Returning default settings due to error");
            return $this->getDefaultSettings();
        }
    }
    
    /**
     * Get default settings
     */
    private function getDefaultSettings(): FrontendSettingsDto {
        return new FrontendSettingsDto(
            selected_types: [PropertyType::RESIDENTIAL_UNIT],
            primary_color: '#007cba',
            visible_columns: [
                ResourceDto::FIELD_NR_LOKALU,
                ResourceDto::FIELD_RODZAJ_NIERUCHOMOSCI,
                ResourceDto::FIELD_POWIERZCHNIA_UZYTKOWA,
                'cena_calkowita',
                ResourceDto::FIELD_STATUS,
                'historia_cen'
            ],
            column_names: FrontendSettingsDto::getDefaultColumnNames()
        );
    }
    
    /**
     * Check if settings exist in database
     */
    public function settingsExist(): bool {
        try {
            return $this->repository->exists();
        } catch (Exception $e) {
            Logger::error("GetFrontendSettingsUseCase::settingsExist - Exception: " . $e->getMessage());
            return false;
        }
    }
    
    /**
     * Reset settings to defaults
     */
    public function resetToDefaults(): Result {
        Logger::info("GetFrontendSettingsUseCase::resetToDefaults - Resetting settings to defaults");
        
        try {
            $success = $this->repository->reset();
            
            if ($success) {
                Logger::info("GetFrontendSettingsUseCase::resetToDefaults - Settings reset successfully");
                return Result::success('Ustawienia zostały zresetowane do wartości domyślnych');
            } else {
                Logger::error("GetFrontendSettingsUseCase::resetToDefaults - Failed to reset settings");
                return Result::failure('Błąd podczas resetowania ustawień');
            }
            
        } catch (Exception $e) {
            Logger::error("GetFrontendSettingsUseCase::resetToDefaults - Exception: " . $e->getMessage());
            return Result::failure('Błąd systemu: ' . $e->getMessage());
        }
    }
}