<?php

if (!defined('ABSPATH')) {
    exit;
}

/**
 * Frontend Management Admin Page
 * Allows configuration of frontend widgets and shortcode generation
 */
class FrontendManagementPage {
    
    private $get_settings_use_case;
    private $save_settings_use_case;
    
    public function __construct() {
        Logger::info('FrontendManagementPage constructor started');
        
        $this->get_settings_use_case = new GetFrontendSettingsUseCase();
        $this->save_settings_use_case = new SaveFrontendSettingsUseCase();
        
        // Add AJAX handlers
        add_action('wp_ajax_ujc_save_frontend_settings', [$this, 'ajax_save_settings']);
        add_action('wp_ajax_ujc_reset_frontend_settings', [$this, 'ajax_reset_settings']);
        
        Logger::info('FrontendManagementPage constructor completed');
    }
    
    /**
     * Render the frontend management page
     */
    public function render() {
        // Load current settings
        $settings = $this->get_settings_use_case->execute();
        
        ?>
        <div class="wrap">
            <h1>Warstwa Frontendowa</h1>
            
            <div class="notice notice-info">
                <p><strong>Konfiguracja widgetów frontendowych</strong></p>
                <p>Skonfiguruj sposób wyświetlania nieruchomości na stronie internetowej i wygeneruj shortcode.</p>
            </div>
            
            <form id="frontend-settings-form" method="post">
                <?php wp_nonce_field('ujc_frontend_settings_nonce', 'nonce'); ?>
                
                <!-- Generator Shortcode Section -->
                <div class="postbox">
                    <div class="postbox-header">
                        <h2>Generator Shortcode</h2>
                    </div>
                    <div class="inside">
                        <table class="form-table">
                            <tr>
                                <th scope="row">
                                    <label>Typy nieruchomości</label>
                                </th>
                                <td>
                                    <?php $this->render_property_types_checkboxes($settings); ?>
                                    <p class="description">Wybierz które typy nieruchomości mają być wyświetlane w widgecie.</p>
                                </td>
                            </tr>
                            <tr>
                                <th scope="row">
                                    <label for="primary-color">Kolor przewodni</label>
                                </th>
                                <td>
                                    <input type="color" 
                                           id="primary-color" 
                                           name="primary_color" 
                                           value="<?php echo esc_attr($settings->primary_color); ?>" 
                                           class="color-picker">
                                    <p class="description">Kolor będzie używany dla przycisków, hover effects i elementów tabeli.</p>
                                </td>
                            </tr>
                        </table>
                        
                        <!-- Generated Shortcode Display -->
                        <div class="shortcode-preview">
                            <h4>Wygenerowany shortcode:</h4>
                            <div class="shortcode-display">
                                <code id="generated-shortcode"><?php echo esc_html($settings->generateShortcode()); ?></code>
                                <button type="button" class="button button-secondary" id="copy-shortcode">Kopiuj</button>
                            </div>
                        </div>
                    </div>
                </div>
                
                <!-- Column Configuration Section -->
                <div class="postbox">
                    <div class="postbox-header">
                        <h2>Konfiguracja Kolumn</h2>
                    </div>
                    <div class="inside">
                        <table class="form-table">
                            <tr>
                                <th scope="row">
                                    <label>Widoczne kolumny</label>
                                </th>
                                <td>
                                    <?php $this->render_visible_columns_checkboxes($settings); ?>
                                    <p class="description">Wybierz które kolumny mają być wyświetlane w tabeli.</p>
                                </td>
                            </tr>
                        </table>
                        
                        <!-- Column Names Configuration -->
                        <h4>Nazwy kolumn</h4>
                        <table class="form-table column-names-table">
                            <?php $this->render_column_names_inputs($settings); ?>
                        </table>
                    </div>
                </div>
                
                <!-- Instructions Section -->
                <div class="postbox">
                    <div class="postbox-header">
                        <h2>Instrukcje użycia</h2>
                    </div>
                    <div class="inside">
                        <h4>Jak dodać widget na stronę:</h4>
                        <ol>
                            <li><strong>W edytorze Gutenberg:</strong> Dodaj blok "Shortcode" i wklej powyższy kod</li>
                            <li><strong>W widżetach:</strong> Dodaj widget "Tekst" lub "HTML" i wklej shortcode</li>
                            <li><strong>W szablonie PHP:</strong> Użyj <code>&lt;?php echo do_shortcode('[shortcode_tutaj]'); ?&gt;</code></li>
                        </ol>
                        
                        <h4>Przykłady użycia:</h4>
                        <ul>
                            <li><code>[resources_list]</code> - wszystkie typy z domyślnymi ustawieniami</li>
                            <li><code>[resources_list types="residential_unit"]</code> - tylko mieszkania</li>
                            <li><code>[resources_list types="parking_space" color="#ff6600"]</code> - miejsca postojowe z własnym kolorem</li>
                        </ul>
                        
                        <div class="notice notice-warning inline">
                            <p><strong>Uwaga:</strong> Po zapisaniu ustawień sprawdź efekt na stronie. Zmiany będą widoczne po odświeżeniu strony z widgetem.</p>
                        </div>
                    </div>
                </div>
                
                <!-- Action Buttons -->
                <div class="submit-section">
                    <button type="submit" class="button-primary" id="save-settings">
                        <span class="dashicons dashicons-yes"></span>
                        Zapisz ustawienia
                    </button>
                    <button type="button" class="button button-secondary" id="reset-settings">
                        <span class="dashicons dashicons-undo"></span>
                        Przywróć domyślne
                    </button>
                </div>
            </form>
        </div>
        
        <?php $this->render_scripts_and_styles(); ?>
        <?php
    }
    
    /**
     * Render property types checkboxes
     */
    private function render_property_types_checkboxes(FrontendSettingsDto $settings) {
        $selected_values = $settings->getSelectedTypesAsStrings();
        
        echo '<div class="property-types-checkboxes">';
        foreach (PropertyType::cases() as $type) {
            $checked = in_array($type->value, $selected_values) ? 'checked' : '';
            echo '<label>';
            echo '<input type="checkbox" name="selected_types[]" value="' . esc_attr($type->value) . '" ' . $checked . '>';
            echo '<span>' . esc_html($type->getDisplayText()) . '</span>';
            echo '</label><br>';
        }
        echo '</div>';
    }
    
    /**
     * Render visible columns checkboxes
     */
    private function render_visible_columns_checkboxes(FrontendSettingsDto $settings) {
        $available_columns = FrontendSettingsDto::getAllAvailableColumns();
        
        echo '<div class="visible-columns-checkboxes">';
        foreach ($available_columns as $column) {
            $checked = in_array($column, $settings->visible_columns) ? 'checked' : '';
            $display_name = $settings->column_names[$column] ?? ucfirst($column);
            
            echo '<label>';
            echo '<input type="checkbox" name="visible_columns[]" value="' . esc_attr($column) . '" ' . $checked . '>';
            echo '<span>' . esc_html($display_name) . '</span>';
            echo '</label><br>';
        }
        echo '</div>';
    }
    
    /**
     * Render column names input fields
     */
    private function render_column_names_inputs(FrontendSettingsDto $settings) {
        $available_columns = FrontendSettingsDto::getAllAvailableColumns();
        
        foreach ($available_columns as $column) {
            $current_name = $settings->column_names[$column] ?? ucfirst($column);
            
            echo '<tr>';
            echo '<th scope="row">';
            echo '<label for="column_name_' . esc_attr($column) . '">' . esc_html(ucfirst($column)) . '</label>';
            echo '</th>';
            echo '<td>';
            echo '<input type="text" id="column_name_' . esc_attr($column) . '" name="column_names[' . esc_attr($column) . ']" value="' . esc_attr($current_name) . '" class="regular-text">';
            echo '</td>';
            echo '</tr>';
        }
    }
    
    /**
     * AJAX handler for saving settings
     */
    public function ajax_save_settings() {
        Logger::info("FrontendManagementPage::ajax_save_settings - START");
        Logger::info("FrontendManagementPage::ajax_save_settings - POST data keys: " . implode(', ', array_keys($_POST)));
        Logger::info("FrontendManagementPage::ajax_save_settings - POST data size: " . count($_POST) . " elements");
        
        try {
            check_ajax_referer('ujc_frontend_settings_nonce', 'nonce');
            Logger::info("FrontendManagementPage::ajax_save_settings - Nonce verification passed");
        } catch (Exception $e) {
            Logger::error("FrontendManagementPage::ajax_save_settings - Nonce verification failed: " . $e->getMessage());
            wp_send_json_error('Błąd weryfikacji nonce');
            return;
        }
        
        if (!current_user_can('manage_options')) {
            Logger::error("FrontendManagementPage::ajax_save_settings - User lacks manage_options capability");
            wp_send_json_error('Brak uprawnień');
            return;
        }
        Logger::info("FrontendManagementPage::ajax_save_settings - User capability check passed");
        
        try {
            Logger::info("FrontendManagementPage::ajax_save_settings - Calling SaveFrontendSettingsUseCase->execute()");
            $result = $this->save_settings_use_case->execute($_POST);
            Logger::info("FrontendManagementPage::ajax_save_settings - SaveFrontendSettingsUseCase completed, success: " . ($result->isSuccess() ? 'true' : 'false'));
            
            if ($result === null) {
                Logger::error("FrontendManagementPage::ajax_save_settings - SaveFrontendSettingsUseCase returned NULL!");
                wp_send_json_error('SaveFrontendSettingsUseCase returned null');
                return;
            }
            
            Logger::info("FrontendManagementPage::ajax_save_settings - Result object type: " . get_class($result));
            Logger::info("FrontendManagementPage::ajax_save_settings - Result success method exists: " . (method_exists($result, 'isSuccess') ? 'true' : 'false'));
            
            if ($result->isSuccess()) {
                Logger::info("FrontendManagementPage::ajax_save_settings - Getting updated settings for shortcode generation");
                try {
                    // Get updated settings for shortcode generation
                    $settings = $this->get_settings_use_case->execute();
                    Logger::info("FrontendManagementPage::ajax_save_settings - Settings retrieved successfully");
                    
                    $shortcode = $settings->generateShortcode();
                    Logger::info("FrontendManagementPage::ajax_save_settings - Generated shortcode: " . $shortcode);
                    
                    Logger::info("FrontendManagementPage::ajax_save_settings - Preparing JSON success response");
                    $response_data = [
                        'message' => $result->getMessage(),
                        'shortcode' => $shortcode
                    ];
                    Logger::info("FrontendManagementPage::ajax_save_settings - Response data prepared, calling wp_send_json_success()");
                    
                    wp_send_json_success($response_data);
                } catch (Exception $e) {
                    Logger::error("FrontendManagementPage::ajax_save_settings - Exception during shortcode generation: " . $e->getMessage());
                    Logger::error("FrontendManagementPage::ajax_save_settings - Exception trace: " . $e->getTraceAsString());
                    wp_send_json_error('Błąd podczas generowania shortcode: ' . $e->getMessage());
                }
            } else {
                Logger::error("FrontendManagementPage::ajax_save_settings - SaveFrontendSettingsUseCase failed: " . $result->getMessage());
                wp_send_json_error($result->getMessage());
            }
            
        } catch (Exception $e) {
            Logger::error('FrontendManagementPage::ajax_save_settings - Exception: ' . $e->getMessage());
            Logger::error('FrontendManagementPage::ajax_save_settings - Exception trace: ' . $e->getTraceAsString());
            wp_send_json_error('Błąd systemu: ' . $e->getMessage());
        }
    }
    
    /**
     * AJAX handler for resetting settings
     */
    public function ajax_reset_settings() {
        check_ajax_referer('ujc_frontend_settings_nonce', 'nonce');
        
        if (!current_user_can('manage_options')) {
            wp_send_json_error('Brak uprawnień');
        }
        
        try {
            $result = $this->get_settings_use_case->resetToDefaults();
            
            if ($result->isSuccess()) {
                wp_send_json_success([
                    'message' => $result->getMessage(),
                    'reload' => true
                ]);
            } else {
                wp_send_json_error($result->getMessage());
            }
            
        } catch (Exception $e) {
            Logger::error('FrontendManagementPage::ajax_reset_settings - Exception: ' . $e->getMessage());
            wp_send_json_error('Błąd systemu: ' . $e->getMessage());
        }
    }
    
    /**
     * Render JavaScript and CSS
     */
    private function render_scripts_and_styles() {
        ?>
        <style>
        .property-types-checkboxes label,
        .visible-columns-checkboxes label {
            display: block;
            margin-bottom: 8px;
        }
        
        .property-types-checkboxes input,
        .visible-columns-checkboxes input {
            margin-right: 8px;
        }
        
        .shortcode-preview {
            margin-top: 20px;
            padding: 15px;
            background: #f8f9fa;
            border: 1px solid #ddd;
            border-radius: 4px;
        }
        
        .shortcode-display {
            display: flex;
            align-items: center;
            gap: 10px;
            margin-top: 10px;
        }
        
        .shortcode-display code {
            padding: 8px 12px;
            background: white;
            border: 1px solid #ddd;
            border-radius: 3px;
            font-family: Monaco, Consolas, monospace;
            flex-grow: 1;
        }
        
        .column-names-table th {
            width: 150px;
        }
        
        .submit-section {
            margin-top: 20px;
            padding: 20px 0;
            border-top: 1px solid #ddd;
        }
        
        .submit-section .button {
            margin-right: 10px;
        }
        
        .notice.inline {
            margin: 15px 0;
        }
        </style>
        
        <script>
        jQuery(document).ready(function($) {
            
            // Update shortcode preview when settings change
            function updateShortcodePreview() {
                const selectedTypes = $('input[name="selected_types[]"]:checked').map(function() {
                    return this.value;
                }).get();
                
                const primaryColor = $('#primary-color').val();
                
                let shortcode = '[resources_list';
                
                if (selectedTypes.length > 0) {
                    shortcode += ' types="' + selectedTypes.join(',') + '"';
                }
                
                if (primaryColor && primaryColor !== '#007cba') {
                    shortcode += ' color="' + primaryColor + '"';
                }
                
                shortcode += ']';
                
                $('#generated-shortcode').text(shortcode);
            }
            
            // Update preview on changes
            $('input[name="selected_types[]"], #primary-color').on('change', updateShortcodePreview);
            
            // Copy shortcode to clipboard
            $('#copy-shortcode').on('click', function() {
                const shortcode = $('#generated-shortcode').text();
                navigator.clipboard.writeText(shortcode).then(function() {
                    $(this).text('Skopiowano!').addClass('button-primary');
                    setTimeout(() => {
                        $(this).text('Kopiuj').removeClass('button-primary');
                    }, 2000);
                }.bind(this));
            });
            
            // Save settings
            $('#frontend-settings-form').on('submit', function(e) {
                e.preventDefault();
                console.log('Frontend settings form submit triggered');
                
                const $submitBtn = $('#save-settings');
                const originalText = $submitBtn.text();
                $submitBtn.text('Zapisywanie...').prop('disabled', true);
                
                const formData = $(this).serialize() + '&action=ujc_save_frontend_settings';
                console.log('Form data being sent:', formData);
                console.log('AJAX URL:', ajaxurl);
                
                $.post(ajaxurl, formData)
                    .done(function(response, textStatus, jqXHR) {
                        console.log('AJAX request successful');
                        console.log('Response status:', textStatus);
                        console.log('Response data:', response);
                        console.log('XHR object:', jqXHR);
                        
                        if (response && response.success) {
                            console.log('Server returned success');
                            alert('✅ ' + response.data.message);
                            if (response.data.shortcode) {
                                console.log('Updating shortcode display with:', response.data.shortcode);
                                $('#generated-shortcode').text(response.data.shortcode);
                            }
                        } else {
                            console.error('Server returned failure');
                            console.error('Error message:', response ? response.data : 'No response data');
                            alert('❌ ' + (response ? response.data : 'Nieznany błąd serwera'));
                        }
                    })
                    .fail(function(jqXHR, textStatus, errorThrown) {
                        console.error('AJAX request failed');
                        console.error('Status:', textStatus);
                        console.error('Error thrown:', errorThrown);
                        console.error('Response status:', jqXHR.status);
                        console.error('Response status text:', jqXHR.statusText);
                        console.error('Response text:', jqXHR.responseText);
                        console.error('XHR object:', jqXHR);
                        
                        let errorMessage = 'Błąd połączenia';
                        if (jqXHR.status) {
                            errorMessage += ' (HTTP ' + jqXHR.status + ')';
                        }
                        if (errorThrown) {
                            errorMessage += ': ' + errorThrown;
                        }
                        
                        alert('❌ ' + errorMessage);
                    })
                    .always(function() {
                        console.log('AJAX request completed (success or failure)');
                        $submitBtn.text(originalText).prop('disabled', false);
                    });
            });
            
            // Reset settings
            $('#reset-settings').on('click', function() {
                if (!confirm('Czy na pewno chcesz przywrócić domyślne ustawienia? Ta operacja jest nieodwracalna.')) {
                    return;
                }
                
                const $resetBtn = $(this);
                const originalText = $resetBtn.text();
                $resetBtn.text('Resetowanie...').prop('disabled', true);
                
                $.post(ajaxurl, {
                    action: 'ujc_reset_frontend_settings',
                    nonce: $('[name="nonce"]').val()
                }, function(response) {
                    if (response.success) {
                        alert('✅ ' + response.data.message);
                        if (response.data.reload) {
                            location.reload();
                        }
                    } else {
                        alert('❌ ' + response.data);
                    }
                }).fail(function() {
                    alert('❌ Błąd połączenia');
                }).always(function() {
                    $resetBtn.text(originalText).prop('disabled', false);
                });
            });
        });
        </script>
        <?php
    }
}