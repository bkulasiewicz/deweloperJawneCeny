<?php

if (!defined('ABSPATH')) {
    exit;
}

/**
 * Repository for frontend settings storage using WordPress options
 */
class FrontendSettingsRepository {
    
    private const OPTION_NAME = 'ujc_frontend_settings';
    
    /**
     * Save frontend settings to WordPress options
     */
    public function save(FrontendSettingsDto $settings): bool {
        Logger::info("FrontendSettingsRepository::save - Saving frontend settings");
        Logger::info("FrontendSettingsRepository::save - Starting save operation for option: " . self::OPTION_NAME);
        
        try {
            Logger::info("FrontendSettingsRepository::save - Converting settings DTO to array");
            $data = $settings->toArray();
            Logger::info("FrontendSettingsRepository::save - Settings data to save:");
            Logger::info("FrontendSettingsRepository::save - - selected_types: " . (is_array($data['selected_types']) ? implode(', ', $data['selected_types']) : 'NOT ARRAY'));
            Logger::info("FrontendSettingsRepository::save - - primary_color: " . ($data['primary_color'] ?? 'NOT SET'));
            Logger::info("FrontendSettingsRepository::save - - visible_columns count: " . (is_array($data['visible_columns']) ? count($data['visible_columns']) : 'NOT ARRAY'));
            Logger::info("FrontendSettingsRepository::save - - column_names count: " . (is_array($data['column_names']) ? count($data['column_names']) : 'NOT ARRAY'));
            
            Logger::info("FrontendSettingsRepository::save - Checking current option value before update");
            $current_value = get_option(self::OPTION_NAME, null);
            if ($current_value === null) {
                Logger::info("FrontendSettingsRepository::save - No existing option value found, this will be a new option");
            } else {
                Logger::info("FrontendSettingsRepository::save - Existing option found, this will be an update");
                Logger::info("FrontendSettingsRepository::save - Current value data type: " . gettype($current_value));
            }
            
            Logger::info("FrontendSettingsRepository::save - Calling update_option()");
            $result = update_option(self::OPTION_NAME, $data);
            Logger::info("FrontendSettingsRepository::save - update_option() returned: " . ($result ? 'true' : 'false'));
            
            if ($result) {
                Logger::info("FrontendSettingsRepository::save - Settings saved successfully");
                
                // Verify the save by reading back the option
                Logger::info("FrontendSettingsRepository::save - Verifying save by reading back option");
                $verification_data = get_option(self::OPTION_NAME, null);
                if ($verification_data !== null && is_array($verification_data)) {
                    Logger::info("FrontendSettingsRepository::save - Verification successful - option was saved correctly");
                    Logger::info("FrontendSettingsRepository::save - Verified data keys: " . implode(', ', array_keys($verification_data)));
                } else {
                    Logger::error("FrontendSettingsRepository::save - Verification FAILED - option was not saved correctly");
                    return false;
                }
                
                return true;
            } else {
                Logger::error("FrontendSettingsRepository::save - update_option() returned false");
                Logger::error("FrontendSettingsRepository::save - This could mean: no changes detected, or save failed");
                
                // Additional check to determine if this is really a failure
                $check_data = get_option(self::OPTION_NAME, null);
                if ($check_data !== null && is_array($check_data)) {
                    Logger::info("FrontendSettingsRepository::save - Despite false return, data exists in database - treating as success");
                    return true;
                } else {
                    Logger::error("FrontendSettingsRepository::save - Data not found in database - this is a real failure");
                    return false;
                }
            }
            
        } catch (Exception $e) {
            Logger::error("FrontendSettingsRepository::save - Exception caught: " . $e->getMessage());
            Logger::error("FrontendSettingsRepository::save - Exception type: " . get_class($e));
            Logger::error("FrontendSettingsRepository::save - Exception trace: " . $e->getTraceAsString());
            return false;
        } catch (Error $e) {
            Logger::error("FrontendSettingsRepository::save - Fatal error caught: " . $e->getMessage());
            Logger::error("FrontendSettingsRepository::save - Error type: " . get_class($e));
            Logger::error("FrontendSettingsRepository::save - Error trace: " . $e->getTraceAsString());
            return false;
        }
    }
    
    /**
     * Load frontend settings from WordPress options
     */
    public function load(): ?FrontendSettingsDto {
        Logger::info("FrontendSettingsRepository::load - Loading frontend settings");
        
        try {
            $data = get_option(self::OPTION_NAME, null);
            
            if ($data === null || !is_array($data)) {
                Logger::info("FrontendSettingsRepository::load - No settings found, returning default");
                return $this->getDefaultSettings();
            }
            
            Logger::info("FrontendSettingsRepository::load - Settings loaded successfully");
            return FrontendSettingsDto::fromArray($data);
            
        } catch (Exception $e) {
            Logger::error("FrontendSettingsRepository::load - Exception: " . $e->getMessage());
            return $this->getDefaultSettings();
        }
    }
    
    /**
     * Get default frontend settings
     */
    private function getDefaultSettings(): FrontendSettingsDto {
        return new FrontendSettingsDto(
            selected_types: [PropertyType::RESIDENTIAL_UNIT],
            primary_color: '#007cba',
            visible_columns: [
                ResourceDto::FIELD_NR_LOKALU,
                ResourceDto::FIELD_RODZAJ_NIERUCHOMOSCI,
                ResourceDto::FIELD_POWIERZCHNIA_UZYTKOWA,
                'cena_calkowita',
                ResourceDto::FIELD_STATUS,
                'historia_cen'
            ],
            column_names: FrontendSettingsDto::getDefaultColumnNames()
        );
    }
    
    /**
     * Reset settings to default values
     */
    public function reset(): bool {
        Logger::info("FrontendSettingsRepository::reset - Resetting to default settings");
        
        try {
            $default_settings = $this->getDefaultSettings();
            return $this->save($default_settings);
        } catch (Exception $e) {
            Logger::error("FrontendSettingsRepository::reset - Exception: " . $e->getMessage());
            return false;
        }
    }
    
    /**
     * Check if settings exist
     */
    public function exists(): bool {
        $data = get_option(self::OPTION_NAME, null);
        return $data !== null;
    }
    
    /**
     * Delete settings from database
     */
    public function delete(): bool {
        Logger::info("FrontendSettingsRepository::delete - Deleting frontend settings");
        
        try {
            $result = delete_option(self::OPTION_NAME);
            
            if ($result) {
                Logger::info("FrontendSettingsRepository::delete - Settings deleted successfully");
                return true;
            } else {
                Logger::error("FrontendSettingsRepository::delete - Failed to delete settings or option not found");
                return false;
            }
            
        } catch (Exception $e) {
            Logger::error("FrontendSettingsRepository::delete - Exception: " . $e->getMessage());
            return false;
        }
    }
    
    /**
     * Get raw option data for debugging
     */
    public function getRawData(): ?array {
        return get_option(self::OPTION_NAME, null);
    }
}