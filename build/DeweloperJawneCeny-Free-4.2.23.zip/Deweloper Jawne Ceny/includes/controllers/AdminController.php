<?php

if (!defined('ABSPATH')) {
    exit;
}

/**
 * Admin Controller - Centralized controller for WordPress admin interface
 * Manages admin pages, modals, and AJAX handlers through dependency injection
 */
class AdminController {

    private $modalFactory;

    // Admin Pages
    private $dashboardPage;
    private $supplierDataPage;
    private $resourcesPage;
    private $publicationPage;
    private $frontendManagementPage;
    private $devConsoleTile;

    public function __construct(ModalFactory $modalFactory) {
        $this->modalFactory = $modalFactory;

        // Admin pages will be created lazily when needed
        // This improves performance by not creating all pages on every admin request

        // Initialize WordPress admin hooks
        $this->initializeAdminHooks();

        Logger::info('AdminController: Initialized with lazy loading');
    }

    /**
     * Initialize WordPress admin hooks
     */
    private function initializeAdminHooks() {
        add_action('admin_menu', [$this, 'registerAdminMenu']);
        add_action('admin_enqueue_scripts', [$this, 'enqueueAdminAssets']);
    }

    /**
     * Register WordPress admin menu structure
     */
    public function registerAdminMenu() {
        // Main menu page
        add_menu_page(
            'Jawne Ceny',
            'Jawne Ceny',
            'manage_options',
            'ujc-dashboard',
            [$this, 'renderDashboardPage'],
            'dashicons-building',
            30
        );

        // Submenu pages
        add_submenu_page(
            'ujc-dashboard',
            'Pulpit',
            'Pulpit',
            'manage_options',
            'ujc-dashboard',
            [$this, 'renderDashboardPage']
        );

        add_submenu_page(
            'ujc-dashboard',
            'Dane Dostawcy',
            'Dane dostawcy',
            'manage_options',
            'ujc-developer',
            [$this, 'renderSupplierDataPage']
        );

        add_submenu_page(
            'ujc-dashboard',
            'Zasoby',
            'Zasoby',
            'manage_options',
            'ujc-resources',
            [$this, 'renderResourcesPage']
        );

        add_submenu_page(
            'ujc-dashboard',
            'Publikacja Danych',
            'Publikacja Danych',
            'manage_options',
            'ujc-publication',
            [$this, 'renderPublicationPage']
        );

        add_submenu_page(
            'ujc-dashboard',
            'Warstwa Frontendowa',
            'Warstwa Frontendowa',
            'manage_options',
            'ujc-frontend-management',
            [$this, 'renderFrontendManagementPage']
        );

        Logger::info('AdminController: Admin menu registered');
    }

    /**
     * Enqueue admin CSS and JavaScript assets
     */
    public function enqueueAdminAssets($hook) {
        wp_enqueue_script('ujc-admin-js', PLUGIN_URL . 'assets/admin.js', ['jquery'], VERSION, true);
        wp_enqueue_style('ujc-admin-css', PLUGIN_URL . 'assets/admin.css', [], VERSION);

        wp_localize_script('ujc-admin-js', 'ujc_ajax', [
            'ajax_url' => admin_url('admin-ajax.php'),
            'nonce' => wp_create_nonce('ujc_admin_nonce'),
            'strings' => [
                'confirm_delete' => 'Czy na pewno chcesz usunąć ten zasób?',
                'saving' => 'Zapisywanie...',
                'saved' => 'Zapisano pomyślnie!',
                'error' => 'Wystąpił błąd!'
            ]
        ]);

        Logger::info('AdminController: Admin assets enqueued for hook: ' . $hook);
    }

    /**
     * Page render methods - with lazy loading
     */
    public function renderDashboardPage() {
        if ($this->dashboardPage === null) {
            $this->dashboardPage = DIContainer::get(DashboardPage::class);
            Logger::info('AdminController: Lazy loaded DashboardPage from DI Container');
        }
        $this->dashboardPage->render();
    }

    public function renderSupplierDataPage() {
        if ($this->supplierDataPage === null) {
            $this->supplierDataPage = DIContainer::get(SupplierDataPage::class);
            Logger::info('AdminController: Lazy loaded SupplierDataPage from DI Container');
        }
        $this->supplierDataPage->render();
    }

    public function renderResourcesPage() {
        if ($this->resourcesPage === null) {
            $this->resourcesPage = DIContainer::get(ResourcesPage::class);
            Logger::info('AdminController: Lazy loaded ResourcesPage from DI Container');
        }
        $this->resourcesPage->render();
    }

    public function renderPublicationPage() {
        if ($this->publicationPage === null) {
            $this->publicationPage = DIContainer::get(PublicationPage::class);
            Logger::info('AdminController: Lazy loaded PublicationPage from DI Container');
        }
        $this->publicationPage->render();
    }

    public function renderFrontendManagementPage() {
        if ($this->frontendManagementPage === null) {
            $this->frontendManagementPage = DIContainer::get(FrontendManagementPage::class);
            Logger::info('AdminController: Lazy loaded FrontendManagementPage from DI Container');
        }
        $this->frontendManagementPage->render();
    }

    /**
     * Get modal instances through ModalFactory
     */
    public function getResourceModal(): ResourceModal {
        return $this->modalFactory->getResourceModal();
    }

    public function getInvestmentModal(): InvestmentModal {
        return $this->modalFactory->getInvestmentModal();
    }

    public function getHistoryModal(): HistoryModal {
        return $this->modalFactory->getHistoryModal();
    }

    /**
     * Get all modals at once
     */
    public function getAllModals(): array {
        return $this->modalFactory->createAllModals();
    }
}